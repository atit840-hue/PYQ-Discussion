# Collaborative PYQ Discussion & Answering System

A Stack Overflow–style platform focused on Previous Year Questions (PYQs), built for B.Tech final year project.

## Tech Stack

| Layer | Technologies |
|-------|-------------|
| Frontend | React, Bootstrap 5, Axios, React Hooks |
| Backend | Node.js, Express.js (MVC) |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcrypt |

## Project Structure

```
pyq-discussion-system/
├── client/                 # React frontend (scaffold)
│   └── src/
│       ├── components/
│       ├── context/
│       ├── hooks/
│       ├── pages/
│       └── services/
└── server/                 # Express backend (MVC)
    ├── config/             # DB connection
    ├── controllers/        # Business logic
    ├── middleware/         # Auth & error handling
    ├── models/             # Mongoose schemas
    ├── routes/             # API routes
    └── utils/              # Helpers
```

## Prerequisites

- Node.js 18+
- MongoDB running locally or a MongoDB Atlas URI

## Setup

```bash
cd pyq-discussion-system/server
cp .env.example .env
npm install
npm run dev
```

## User Roles

| Role | Permissions |
|------|-------------|
| `student` | Post questions/answers/comments, vote, bookmark, report |
| `moderator` | Verify/unverify answers, review reports |
| `admin` | Delete questions/answers, all moderator permissions |

---

## API Reference

### Auth

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/api/auth/register` | Public | Register (role: student) |
| POST | `/api/auth/login` | Public | Login & receive JWT |
| GET | `/api/auth/me` | Private | Current user profile |

### Questions

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/questions` | Public | List questions (filters: subject, semester, year, difficulty, search, sort, page, limit) |
| POST | `/api/questions` | Private | Create question |
| GET | `/api/questions/:id` | Public | Get question (increments views) |
| PUT | `/api/questions/:id` | Private | Update (author or admin) |
| DELETE | `/api/questions/:id` | Admin | Delete question + cascade |

**Create question body:**
```json
{
  "title": "Explain TCP 3-way handshake",
  "description": "Detailed PYQ from CN paper 2023...",
  "subject": "Computer Networks",
  "semester": 5,
  "year": 2023,
  "difficulty": "medium"
}
```

### Answers

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/questions/:questionId/answers` | Public | List answers for a question |
| POST | `/api/questions/:questionId/answers` | Private | Post answer |
| GET | `/api/answers/:id` | Public | Get single answer |
| PUT | `/api/answers/:id` | Private | Update (author or admin) |
| DELETE | `/api/answers/:id` | Admin | Delete answer + cascade |
| PATCH | `/api/answers/:id/verify` | Moderator/Admin | Verify or unverify answer |
| POST | `/api/answers/:id/upvote` | Private | Upvote (toggle) |
| POST | `/api/answers/:id/downvote` | Private | Downvote (toggle) |
| DELETE | `/api/answers/:id/vote` | Private | Remove vote |

**Verify body (optional):**
```json
{ "verified": true }
```

### Comments

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/answers/:answerId/comments` | Public | List comments |
| POST | `/api/answers/:answerId/comments` | Private | Add comment |
| DELETE | `/api/comments/:id` | Private | Delete (author or admin) |

### Bookmarks

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/bookmarks` | Private | User's bookmarked questions |
| POST | `/api/bookmarks` | Private | Bookmark via body `{ "questionId": "..." }` |
| POST | `/api/bookmarks/:questionId` | Private | Bookmark question |
| POST | `/api/bookmarks/:questionId/toggle` | Private | Toggle bookmark |
| DELETE | `/api/bookmarks/:questionId` | Private | Remove bookmark |

### Reports

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/api/reports` | Private | Report content |
| GET | `/api/reports` | Moderator/Admin | List reports (filter: status, targetType) |
| GET | `/api/reports/:id` | Moderator/Admin | Get report |
| PATCH | `/api/reports/:id` | Moderator/Admin | Update report status |

**Report body:**
```json
{
  "targetType": "answer",
  "targetId": "665abc...",
  "reason": "Incorrect solution",
  "description": "The answer has wrong time complexity."
}
```

---

## Data Models

### Question
`title`, `description`, `subject`, `semester`, `year`, `difficulty`, `author`, `answerCount`, `views`

### Answer
`answerText`, `verified`, `verifiedBy`, `verifiedAt`, `upvotes[]`, `downvotes[]`, `voteScore` (virtual)

### Comment
`answer`, `user`, `comment`

### Bookmark
`user`, `question` (unique pair)

### Report
`reportedBy`, `targetType`, `targetId`, `reason`, `status`, `reviewedBy`

## License

ISC
