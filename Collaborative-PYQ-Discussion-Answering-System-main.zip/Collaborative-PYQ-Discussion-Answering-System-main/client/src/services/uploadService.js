import api from './api';

export const uploadProfilePicture = (file) => {
  const formData = new FormData();
  formData.append('image', file);
  return api.post('/upload/profile', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

export const uploadQuestionImage = (file) => {
  const formData = new FormData();
  formData.append('image', file);
  return api.post('/upload/question', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};
