import api from './api';

export const getAnalytics = () => api.get('/analytics');
export const getAnalyticsSummary = () => api.get('/analytics/summary');
export const getMyAnalytics = () => api.get('/analytics/me');
