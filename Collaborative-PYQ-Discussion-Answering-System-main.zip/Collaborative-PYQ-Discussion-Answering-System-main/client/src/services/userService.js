import api from './api';

export const getLeaderboard = (params) => api.get('/users/leaderboard', { params });
