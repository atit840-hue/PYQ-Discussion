import api from './api';

export const getHomeFeed = () => api.get('/home/feed');
export const getMyProfile = () => api.get('/users/me/profile');
