import api from './api';

export const getSubjects = () => api.get('/subjects');
export const getSubject = (slug) => api.get(`/subjects/${slug}`);
export const getSubjectTopics = (slug) => api.get(`/subjects/${slug}/topics`);
