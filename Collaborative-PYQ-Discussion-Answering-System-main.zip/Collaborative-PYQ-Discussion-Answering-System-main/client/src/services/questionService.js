import api from './api';

export const getQuestions = (params) => api.get('/questions', { params });
export const getSubjects = () => api.get('/questions/subjects/list');
export const getAllSubjects = () => api.get('/subjects');
export const upvoteQuestion = (id) => api.post(`/questions/${id}/upvote`);
export const downvoteQuestion = (id) => api.post(`/questions/${id}/downvote`);
export const acceptAnswer = (questionId, answerId) =>
  api.patch(`/questions/${questionId}/accept/${answerId}`);
export const getQuestion = (id) => api.get(`/questions/${id}`);
export const createQuestion = (data) => api.post('/questions', data);
export const updateQuestion = (id, data) => api.put(`/questions/${id}`, data);
export const deleteQuestion = (id) => api.delete(`/questions/${id}`);

export const getAnswersByQuestion = (questionId, params) =>
  api.get(`/questions/${questionId}/answers`, { params });
export const createAnswer = (questionId, data) =>
  api.post(`/questions/${questionId}/answers`, data);
