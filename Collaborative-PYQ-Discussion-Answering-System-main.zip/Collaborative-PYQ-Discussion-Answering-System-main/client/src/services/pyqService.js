import api from './api';

export const getPyqs = (params) => api.get('/pyqs', { params });
export const getExams = () => api.get('/pyqs/exams/list');
export const getPyq = (id) => api.get(`/pyqs/${id}`);
export const createPyq = (data) => api.post('/pyqs', data);
export const updatePyq = (id, data) => api.put(`/pyqs/${id}`, data);
export const deletePyq = (id) => api.delete(`/pyqs/${id}`);
