import api from './api';

export const getAnswer = (id) => api.get(`/answers/${id}`);
export const updateAnswer = (id, data) => api.put(`/answers/${id}`, data);
export const deleteAnswer = (id) => api.delete(`/answers/${id}`);
export const verifyAnswer = (id, verified = true) =>
  api.patch(`/answers/${id}/verify`, { verified });
export const upvoteAnswer = (id) => api.post(`/answers/${id}/upvote`);
export const downvoteAnswer = (id) => api.post(`/answers/${id}/downvote`);
export const removeVote = (id) => api.delete(`/answers/${id}/vote`);

export const getComments = (answerId, params) =>
  api.get(`/answers/${answerId}/comments`, { params });
export const createComment = (answerId, data) =>
  api.post(`/answers/${answerId}/comments`, data);
export const deleteComment = (id) => api.delete(`/comments/${id}`);
