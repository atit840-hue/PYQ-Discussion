import api from './api';

export const getBookmarks = (params) => api.get('/bookmarks', { params });
export const addBookmark = (questionId) => api.post(`/bookmarks/${questionId}`);
export const toggleBookmark = (questionId) => api.post(`/bookmarks/${questionId}/toggle`);
export const removeBookmark = (questionId) => api.delete(`/bookmarks/${questionId}`);
