import api from './api';

export const explainAnswer = (data) => api.post('/ai/explain', data);
export const summarizeQuestion = (questionId) => api.get(`/ai/summarize/${questionId}`);
export const getSimilarQuestions = (questionId) => api.get(`/ai/similar/${questionId}`);
