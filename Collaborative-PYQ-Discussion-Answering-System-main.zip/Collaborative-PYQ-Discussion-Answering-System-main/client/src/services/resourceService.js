import api from './api';

export const getHomeFeed = () => api.get('/home/feed');
export const getResources = (params) => api.get('/resources', { params });
export const getResource = (id) => api.get(`/resources/${id}`);
export const uploadResource = (formData) =>
  api.post('/resources', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
export const downloadResource = (id) => api.post(`/resources/${id}/download`);
export const likeResource = (id) => api.post(`/resources/${id}/like`);
export const bookmarkResource = (id) => api.post(`/resources/${id}/bookmark`);
export const getSemesterCurriculum = (params) => api.get('/resources/curriculum', { params });
