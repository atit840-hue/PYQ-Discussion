import api from './api';

export const createReport = (data) => api.post('/reports', data);
export const getReports = (params) => api.get('/reports', { params });
export const getReport = (id) => api.get(`/reports/${id}`);
export const updateReportStatus = (id, data) => api.patch(`/reports/${id}`, data);
