import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="footer py-3 mt-auto">
      <div className="container-fluid">
        <div className="row align-items-center">
          <div className="col-md-6 text-center text-md-start">
            <span className="text-muted small">
              © {year} PYQDiscuss — Collaborative PYQ Platform
            </span>
          </div>
          <div className="col-md-6 text-center text-md-end">
            <Link to="/" className="text-muted small text-decoration-none me-3">
              Home
            </Link>
            <Link to="/ask" className="text-muted small text-decoration-none me-3">
              Ask Question
            </Link>
            <span className="text-muted small">B.Tech Final Year Project</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
