import React from 'react';
import { Link } from 'react-router-dom';
import { formatDate, DIFFICULTY_VARIANT } from '../utils/helpers';
import UserAvatar from './UserAvatar';

const QuestionCard = ({ question }) => {
  const {
    _id,
    title,
    subject,
    topic,
    subTopic,
    semester,
    year,
    difficulty,
    author,
    answerCount = 0,
    views = 0,
    voteScore,
    upvotes = [],
    downvotes = [],
    createdAt,
    images = [],
    acceptedAnswer,
  } = question;

  const score = voteScore ?? upvotes.length - downvotes.length;

  return (
    <div className="card question-card mb-3">
      <div className="card-body">
        <div className="row g-3">
          <div className="col-auto text-center vote-box">
            <div className="text-success fw-bold fs-5">{score}</div>
            <div className="text-muted small">votes</div>
            <div className="text-muted small mt-1">{answerCount} ans</div>
          </div>
          <div className="col">
            <Link to={`/questions/${_id}`} className="text-decoration-none">
              <h5 className="card-title mb-2 text-primary">{title}</h5>
            </Link>
            <div className="d-flex flex-wrap gap-2 mb-2">
              <span className="badge bg-secondary stat-badge">{subject}</span>
              {topic && <span className="badge bg-primary stat-badge">{topic}</span>}
              {subTopic && <span className="badge bg-primary-subtle text-primary-emphasis stat-badge">{subTopic}</span>}
              <span className="badge bg-info stat-badge">Sem {semester}</span>
              <span className="badge bg-dark stat-badge">{year}</span>
              <span className={`badge bg-${DIFFICULTY_VARIANT[difficulty] || 'secondary'} stat-badge`}>
                {difficulty}
              </span>
              {acceptedAnswer && (
                <span className="badge bg-success stat-badge">
                  <i className="bi bi-check-circle me-1" />Answered
                </span>
              )}
            </div>
            <div className="text-muted small d-flex align-items-center gap-2">
              <UserAvatar user={author} size={22} />
              <span>
                Asked by <strong>{author?.name || 'Unknown'}</strong> · {formatDate(createdAt)} · {views} views
              </span>
              {images.length > 0 && (
                <span className="badge bg-light text-dark border">
                  <i className="bi bi-image me-1" />{images.length}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;
