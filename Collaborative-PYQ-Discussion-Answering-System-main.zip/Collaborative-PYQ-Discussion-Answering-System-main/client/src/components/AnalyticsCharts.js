import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import { useTheme } from '../context/ThemeContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const chartOptions = (darkMode, title) => ({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { labels: { color: darkMode ? '#dee2e6' : '#212529' } },
    title: { display: !!title, text: title, color: darkMode ? '#dee2e6' : '#212529' },
  },
  scales: {
    x: { ticks: { color: darkMode ? '#adb5bd' : '#495057' }, grid: { color: darkMode ? '#343a40' : '#e9ecef' } },
    y: { ticks: { color: darkMode ? '#adb5bd' : '#495057' }, grid: { color: darkMode ? '#343a40' : '#e9ecef' } },
  },
});

export const SubjectChart = ({ data }) => {
  const { darkMode } = useTheme();
  const chartData = {
    labels: data.map((d) => d.subject),
    datasets: [{
      label: 'Questions',
      data: data.map((d) => d.count),
      backgroundColor: ['#0d6efd', '#6610f2', '#6f42c1', '#d63384', '#fd7e14', '#198754', '#20c997', '#0dcaf0'],
    }],
  };

  return (
    <div style={{ height: 280 }}>
      <Doughnut data={chartData} options={{ ...chartOptions(darkMode, 'Subject Distribution'), scales: undefined }} />
    </div>
  );
};

export const ActivityChart = ({ data, label = 'Activity' }) => {
  const { darkMode } = useTheme();
  const chartData = {
    labels: data.map((d) => d._id),
    datasets: [{
      label,
      data: data.map((d) => d.count),
      borderColor: '#0d6efd',
      backgroundColor: 'rgba(13,110,253,0.15)',
      fill: true,
      tension: 0.3,
    }],
  };

  return (
    <div style={{ height: 260 }}>
      <Line data={chartData} options={chartOptions(darkMode, label)} />
    </div>
  );
};

export const StatsBarChart = ({ labels, values, title }) => {
  const { darkMode } = useTheme();
  const chartData = {
    labels,
    datasets: [{ label: title, data: values, backgroundColor: '#198754' }],
  };

  return (
    <div style={{ height: 260 }}>
      <Bar data={chartData} options={chartOptions(darkMode, title)} />
    </div>
  );
};

export const UserActivityChart = ({ userActivity }) => {
  const { darkMode } = useTheme();
  const labels = userActivity?.questions?.map((d) => d._id) || [];
  const chartData = {
    labels,
    datasets: [
      { label: 'Questions', data: userActivity?.questions?.map((d) => d.count) || [], borderColor: '#0d6efd', tension: 0.3 },
      { label: 'Answers', data: userActivity?.answers?.map((d) => d.count) || [], borderColor: '#198754', tension: 0.3 },
      { label: 'New Users', data: userActivity?.users?.map((d) => d.count) || [], borderColor: '#fd7e14', tension: 0.3 },
    ],
  };

  return (
    <div style={{ height: 300 }}>
      <Line data={chartData} options={chartOptions(darkMode, 'Platform Activity (30 days)')} />
    </div>
  );
};
