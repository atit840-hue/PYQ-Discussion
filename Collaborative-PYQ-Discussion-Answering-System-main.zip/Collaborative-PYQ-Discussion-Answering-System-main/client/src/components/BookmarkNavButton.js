import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getBookmarks } from '../services/bookmarkService';

const BookmarkNavButton = () => {
  const { user } = useAuth();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    getBookmarks({ limit: 1 })
      .then(({ data }) => setCount(data.pagination?.total || data.data?.length || 0))
      .catch(() => {});
  }, [user]);

  if (!user) return null;

  return (
    <Link
      to="/bookmarks"
      className="btn btn-outline-secondary btn-sm nav-icon-btn position-relative"
      title="Bookmarks"
    >
      <i className="bi bi-bookmark" />
      {count > 0 && (
        <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary nav-badge">
          {count > 99 ? '99+' : count}
        </span>
      )}
    </Link>
  );
};

export default BookmarkNavButton;
