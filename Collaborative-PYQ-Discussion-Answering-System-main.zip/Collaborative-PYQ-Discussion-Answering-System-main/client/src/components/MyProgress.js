import React, { useEffect, useState } from 'react';
import { getAnalyticsSummary, getMyAnalytics } from '../services/analyticsService';
import { getQuestions } from '../services/questionService';
import { getErrorMessage } from '../utils/helpers';
import { SubjectChart, ActivityChart } from '../components/AnalyticsCharts';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';
import { Link } from 'react-router-dom';

const MyProgress = () => {
  const [summary, setSummary] = useState(null);
  const [myStats, setMyStats] = useState(null);
  const [recentQuestions, setRecentQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      getAnalyticsSummary(),
      getMyAnalytics(),
      getQuestions({ limit: 5 }),
    ])
      .then(([summaryRes, myRes, questionsRes]) => {
        setSummary(summaryRes.data.data);
        setMyStats(myRes.data.data);
        setRecentQuestions(questionsRes.data.data);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner text="Loading your progress..." />;

  return (
    <div>
      <div className="row g-3 mb-4">
        <div className="col-md-3 col-6">
          <div className="stat-tile">
            <div className="stat-tile-value">{myStats?.myQuestions || 0}</div>
            <div className="stat-tile-label">My Questions</div>
          </div>
        </div>
        <div className="col-md-3 col-6">
          <div className="stat-tile">
            <div className="stat-tile-value">{myStats?.myAnswers || 0}</div>
            <div className="stat-tile-label">My Answers</div>
          </div>
        </div>
        <div className="col-md-3 col-6">
          <div className="stat-tile">
            <div className="stat-tile-value">{summary?.totals?.questions || 0}</div>
            <div className="stat-tile-label">Platform Questions</div>
          </div>
        </div>
        <div className="col-md-3 col-6">
          <div className="stat-tile">
            <div className="stat-tile-value">{myStats?.unreadNotifications || 0}</div>
            <div className="stat-tile-label">Unread Alerts</div>
          </div>
        </div>
      </div>

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="row g-4 mb-4">
        <div className="col-lg-6">
          <div className="glass-card p-3 h-100">
            <h6 className="fw-semibold mb-3">Subject Distribution</h6>
            {summary?.subjectDistribution?.length ? (
              <SubjectChart data={summary.subjectDistribution} />
            ) : (
              <p className="text-muted mb-0">No data yet.</p>
            )}
          </div>
        </div>
        <div className="col-lg-6">
          <div className="glass-card p-3 h-100">
            <h6 className="fw-semibold mb-3">My Activity</h6>
            {myStats?.activity?.length ? (
              <ActivityChart data={myStats.activity} label="Questions Posted" />
            ) : (
              <p className="text-muted mb-0">Post questions to see your chart.</p>
            )}
          </div>
        </div>
      </div>

      <h6 className="fw-semibold mb-3">Recent Questions</h6>
      {recentQuestions.length === 0 ? (
        <p className="text-muted">No questions yet. <Link to="/?tab=ask">Ask one!</Link></p>
      ) : (
        <ul className="list-group glass-card">
          {recentQuestions.map((q) => (
            <li key={q._id} className="list-group-item d-flex justify-content-between">
              <Link to={`/questions/${q._id}`}>{q.title}</Link>
              <span className="badge bg-secondary">{q.answerCount} ans</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MyProgress;
