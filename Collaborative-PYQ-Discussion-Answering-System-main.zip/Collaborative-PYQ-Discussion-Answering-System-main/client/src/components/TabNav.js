import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';

const TabNav = ({ tabs, paramKey = 'tab', className = '' }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const active = searchParams.get(paramKey) || tabs[0]?.id;

  const setTab = (id) => {
    const next = new URLSearchParams(searchParams);
    next.set(paramKey, id);
    setSearchParams(next, { replace: true });
  };

  return (
    <nav className={`tab-nav ${className}`}>
      {tabs.map((tab) => (
        <button
          key={tab.id}
          type="button"
          className={`tab-nav-item${active === tab.id ? ' active' : ''}`}
          onClick={() => setTab(tab.id)}
        >
          {tab.icon && <i className={`bi ${tab.icon} me-1`} />}
          {tab.label}
        </button>
      ))}
    </nav>
  );
};

export const TabLink = ({ to, children, icon }) => (
  <Link to={to} className="tab-nav-item text-decoration-none">
    {icon && <i className={`bi ${icon} me-1`} />}
    {children}
  </Link>
);

export default TabNav;
