import React from 'react';

const UserAvatar = ({ user, size = 40 }) => {
  const initial = user?.name?.charAt(0)?.toUpperCase() || '?';
  const url = user?.profilePicture?.url;

  if (url) {
    return (
      <img
        src={url}
        alt={user.name}
        className="rounded-circle object-fit-cover"
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <div
      className="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center fw-semibold"
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initial}
    </div>
  );
};

export default UserAvatar;
