import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getHomeFeed } from '../services/homeService';
import UserAvatar from './UserAvatar';
import ReputationBadge from './ReputationBadge';

const HomeFeedPanel = () => {
  const [feed, setFeed] = useState(null);

  useEffect(() => {
    getHomeFeed()
      .then(({ data }) => setFeed(data.data))
      .catch(() => {});
  }, []);

  if (!feed) return null;

  return (
    <div className="row g-3 mb-4">
      <div className="col-lg-8">
        <div className="glass-card p-3 mb-3">
          <h6 className="fw-semibold mb-3"><i className="bi bi-fire text-danger me-2" />Trending Discussions</h6>
          {feed.trendingDiscussions?.length ? (
            <ul className="list-unstyled mb-0">
              {feed.trendingDiscussions.slice(0, 4).map((q) => (
                <li key={q._id} className="feed-list-item">
                  <Link to={`/questions/${q._id}`} className="text-decoration-none fw-medium">
                    {q.title}
                  </Link>
                  <span className="text-muted small ms-2">{q.answerCount} ans · {q.views} views</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted small mb-0">No discussions yet.</p>
          )}
        </div>
        <div className="row g-3">
          <div className="col-md-6">
            <div className="glass-card p-3 h-100">
              <h6 className="fw-semibold mb-3"><i className="bi bi-journal-text me-2 text-info" />Recent Notes</h6>
              {feed.recentNotes?.length ? feed.recentNotes.map((n) => (
                <div key={n._id} className="small mb-2">
                  <span className="fw-medium">{n.title}</span>
                  <div className="text-muted">{n.subject} · {n.branch}</div>
                </div>
              )) : <p className="text-muted small mb-0">No notes uploaded yet.</p>}
            </div>
          </div>
          <div className="col-md-6">
            <div className="glass-card p-3 h-100">
              <h6 className="fw-semibold mb-3"><i className="bi bi-journal-bookmark me-2 text-primary" />Recent PYQs</h6>
              {feed.recentPyqs?.length ? feed.recentPyqs.map((p) => (
                <div key={p._id} className="small mb-2">
                  <Link to={`/pyqs/${p._id}`} className="text-decoration-none fw-medium">{p.title}</Link>
                  <div className="text-muted">{p.exam} · {p.year}</div>
                </div>
              )) : <p className="text-muted small mb-0">No PYQs in repository yet.</p>}
            </div>
          </div>
        </div>
      </div>
      <div className="col-lg-4">
        <div className="glass-card p-3 mb-3">
          <h6 className="fw-semibold mb-3"><i className="bi bi-trophy text-warning me-2" />Top Contributors</h6>
          {feed.topContributors?.map((u, i) => (
            <div key={u._id} className="d-flex align-items-center gap-2 mb-2">
              <span className="text-muted small">{i + 1}.</span>
              <UserAvatar user={u} size={28} />
              <div className="flex-grow-1 min-width-0">
                <div className="fw-medium small truncate">{u.name}</div>
                <ReputationBadge reputation={u.reputation} size="sm" />
              </div>
            </div>
          ))}
        </div>
        <div className="glass-card p-3 mb-3">
          <h6 className="fw-semibold mb-3"><i className="bi bi-book me-2" />Popular Subjects</h6>
          <div className="d-flex flex-wrap gap-2">
            {feed.popularSubjects?.slice(0, 6).map((s) => (
              <Link
                key={s._id}
                to={`/subjects/${s.slug}`}
                className="badge bg-primary-subtle text-primary-emphasis text-decoration-none"
              >
                {s.name}
              </Link>
            ))}
          </div>
        </div>
        <div className="glass-card p-3 streak-card text-center">
          <div className="streak-flame">🔥</div>
          <div className="fw-bold">Study Streak</div>
          <div className="text-muted small">Coming soon — track daily learning</div>
        </div>
      </div>
    </div>
  );
};

export default HomeFeedPanel;
