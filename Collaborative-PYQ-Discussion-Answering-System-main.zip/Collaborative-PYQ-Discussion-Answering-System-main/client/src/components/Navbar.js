import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import NotificationBell from './NotificationBell';
import BookmarkNavButton from './BookmarkNavButton';
import UserAvatar from './UserAvatar';

const Navbar = ({ onToggleSidebar }) => {
  const { user, logout } = useAuth();
  const { darkMode, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg border-bottom sticky-top app-navbar">
      <div className="container-fluid">
        <button
          className="btn btn-outline-secondary d-lg-none me-2 nav-icon-btn"
          onClick={onToggleSidebar}
          aria-label="Toggle sidebar"
        >
          <i className="bi bi-list" />
        </button>

        <Link className="navbar-brand fw-bold brand-logo" to="/">
          PYQ<span className="brand-logo-accent">Discuss</span>
        </Link>

        <div className="d-flex align-items-center gap-2 ms-auto">
          {user && (
            <Link to="/?tab=ask" className="btn btn-primary btn-sm d-none d-md-inline-flex align-items-center">
              <i className="bi bi-plus-lg me-1" /> Ask
            </Link>
          )}

          <button
            className="btn btn-outline-secondary btn-sm nav-icon-btn"
            onClick={toggleTheme}
            title={darkMode ? 'Light mode' : 'Dark mode'}
          >
            {darkMode ? <i className="bi bi-sun" /> : <i className="bi bi-moon" />}
          </button>

          {user ? (
            <>
              <NotificationBell />
              <BookmarkNavButton />
              <div className="dropdown">
                <button
                  className="btn btn-outline-secondary btn-sm dropdown-toggle d-flex align-items-center gap-2 nav-profile-btn"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <UserAvatar user={user} size={28} />
                  <span className="d-none d-md-inline">{user.name}</span>
                </button>
                <ul className="dropdown-menu dropdown-menu-end shadow">
                  <li>
                    <Link className="dropdown-item" to="/profile">
                      <i className="bi bi-person me-2" />Profile
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/leaderboard?tab=progress">
                      <i className="bi bi-graph-up me-2" />My Progress
                    </Link>
                  </li>
                  {user.role === 'admin' || user.role === 'moderator' ? (
                    <li>
                      <Link className="dropdown-item" to="/admin">
                        <i className="bi bi-shield-check me-2" />
                        {user.role === 'admin' ? 'Admin' : 'Moderation'}
                      </Link>
                    </li>
                  ) : null}
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button className="dropdown-item text-danger" onClick={handleLogout}>
                      <i className="bi bi-box-arrow-right me-2" />Logout
                    </button>
                  </li>
                </ul>
              </div>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn-outline-primary btn-sm">Login</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Register</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
