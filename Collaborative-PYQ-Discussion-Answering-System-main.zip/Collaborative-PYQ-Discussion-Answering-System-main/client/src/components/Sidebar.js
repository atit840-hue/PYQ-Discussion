import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Sidebar = ({ show, onClose }) => {
  const { user, isAdmin } = useAuth();

  const linkClass = ({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`;

  const links = [
    { to: '/', label: 'Discussions', icon: 'bi-chat-dots', public: true, end: true },
    { to: '/semester-pyqs', label: 'Semester PYQs', icon: 'bi-mortarboard', public: true },
    { to: '/leaderboard', label: 'Leaderboard', icon: 'bi-trophy', public: true },
    { to: '/profile', label: 'Profile', icon: 'bi-person', auth: true },
  ];

  if (isAdmin || user?.role === 'moderator') {
    links.push({
      to: '/admin',
      label: isAdmin ? 'Admin' : 'Moderation',
      icon: 'bi-shield-check',
      auth: true,
    });
  }

  return (
    <>
      {show && <div className="sidebar-backdrop d-lg-none" onClick={onClose} />}
      <aside className={`sidebar p-3 ${show ? 'show' : ''}`}>
        <nav>
          {links.map((link) => {
            if (link.auth && !user) return null;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.end}
                className={linkClass}
                onClick={onClose}
              >
                <i className={`bi ${link.icon}`} />
                <span>{link.label}</span>
              </NavLink>
            );
          })}
        </nav>

        <div className="sidebar-footer mt-4 px-2">
          <small className="text-muted d-block mb-2">Quick actions</small>
          {user ? (
            <>
              <NavLink to="/?tab=ask" className="btn btn-primary btn-sm w-100 mb-2" onClick={onClose}>
                <i className="bi bi-plus-lg me-1" /> Ask Question
              </NavLink>
              <NavLink to="/?tab=upload" className="btn btn-outline-primary btn-sm w-100" onClick={onClose}>
                <i className="bi bi-cloud-upload me-1" /> Upload PYQ
              </NavLink>
            </>
          ) : (
            <NavLink to="/login" className="btn btn-outline-primary btn-sm w-100" onClick={onClose}>
              Login to contribute
            </NavLink>
          )}
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
