import React from 'react';

const VoteBox = ({
  voteScore,
  userVote,
  onUpvote,
  onDownvote,
  disabled,
  size = 'md',
}) => {
  const btnClass = size === 'sm' ? 'btn-sm' : '';

  return (
    <div className="vote-box d-flex flex-column align-items-center">
      <button
        type="button"
        className={`btn ${btnClass} btn-outline-success ${userVote === 'upvote' ? 'active' : ''}`}
        onClick={onUpvote}
        disabled={disabled}
        title="Upvote"
      >
        <i className="bi bi-chevron-up" />
      </button>
      <div className={`fw-bold my-1 ${voteScore > 0 ? 'text-success' : voteScore < 0 ? 'text-danger' : ''}`}>
        {voteScore}
      </div>
      <button
        type="button"
        className={`btn ${btnClass} btn-outline-danger ${userVote === 'downvote' ? 'active' : ''}`}
        onClick={onDownvote}
        disabled={disabled}
        title="Downvote"
      >
        <i className="bi bi-chevron-down" />
      </button>
    </div>
  );
};

export default VoteBox;
