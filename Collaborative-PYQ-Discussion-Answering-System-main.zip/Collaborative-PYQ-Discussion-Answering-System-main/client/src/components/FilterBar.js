import React, { useEffect, useState } from 'react';
import { DIFFICULTIES, SEMESTERS } from '../utils/helpers';
import { getAllSubjects } from '../services/questionService';
import { getSubjectTopics } from '../services/subjectService';

const FilterBar = ({
  filters,
  onChange,
  onClear,
  loading = false,
}) => {
  const [subjects, setSubjects] = useState([]);
  const [topics, setTopics] = useState([]);
  const [subTopics, setSubTopics] = useState([]);

  useEffect(() => {
    getAllSubjects()
      .then(({ data }) => setSubjects(data.data.subjects || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!filters.subject) {
      setTopics([]);
      setSubTopics([]);
      return;
    }
    const sub = subjects.find((s) => s.name === filters.subject);
    if (sub?.slug) {
      getSubjectTopics(sub.slug)
        .then(({ data }) => setTopics(data.data.topics || []))
        .catch(() => setTopics([]));
    }
  }, [filters.subject, subjects]);

  useEffect(() => {
    if (!filters.topic) {
      setSubTopics([]);
      return;
    }
    const topic = topics.find((t) => t.name === filters.topic);
    setSubTopics(topic?.subTopics || []);
  }, [filters.topic, topics]);

  const activeFilters = [
    filters.subject && { key: 'subject', label: filters.subject },
    filters.topic && { key: 'topic', label: filters.topic },
    filters.subTopic && { key: 'subTopic', label: filters.subTopic },
    filters.semester && { key: 'semester', label: `Sem ${filters.semester}` },
    filters.year && { key: 'year', label: `Year: ${filters.year}` },
    filters.difficulty && { key: 'difficulty', label: filters.difficulty },
    filters.search && { key: 'search', label: `"${filters.search}"` },
  ].filter(Boolean);

  return (
    <div className="card mb-4">
      <div className="card-body">
        <div className="row g-2">
          <div className="col-lg-3">
            <div className="input-group">
              <span className="input-group-text"><i className="bi bi-search" /></span>
              <input
                type="text"
                name="search"
                className="form-control"
                placeholder="Search PYQs..."
                value={filters.search}
                onChange={onChange}
              />
            </div>
          </div>
          <div className="col-lg-2">
            <select name="subject" className="form-select" value={filters.subject} onChange={onChange}>
              <option value="">All Subjects</option>
              {subjects.map((s) => (
                <option key={s._id || s.slug} value={s.name}>{s.name}</option>
              ))}
            </select>
          </div>
          <div className="col-lg-2">
            <select name="topic" className="form-select" value={filters.topic || ''} onChange={onChange} disabled={!filters.subject}>
              <option value="">All Topics</option>
              {topics.map((t) => (
                <option key={t.name} value={t.name}>{t.name}</option>
              ))}
            </select>
          </div>
          <div className="col-lg-2">
            <select name="subTopic" className="form-select" value={filters.subTopic || ''} onChange={onChange} disabled={!filters.topic}>
              <option value="">Sub-topic</option>
              {subTopics.map((st) => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>
          <div className="col-lg-1">
            <select name="semester" className="form-select" value={filters.semester} onChange={onChange}>
              <option value="">Sem</option>
              {SEMESTERS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div className="col-lg-1">
            <select name="difficulty" className="form-select" value={filters.difficulty} onChange={onChange}>
              <option value="">Diff</option>
              {DIFFICULTIES.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
          <div className="col-lg-1">
            <button type="button" className="btn btn-outline-secondary w-100" onClick={onClear} title="Clear filters">
              <i className="bi bi-x-lg" />
            </button>
          </div>
        </div>

        <div className="row g-2 mt-2">
          <div className="col-lg-2">
            <input type="number" name="year" className="form-control form-control-sm" placeholder="Year" value={filters.year} onChange={onChange} />
          </div>
          <div className="col-lg-3">
            <select name="sort" className="form-select form-select-sm" value={filters.sort} onChange={onChange}>
              <option value="">Sort: Newest</option>
              <option value="oldest">Oldest</option>
              <option value="most-answered">Most Answered</option>
              <option value="most-viewed">Most Viewed</option>
              <option value="most-voted">Most Upvoted</option>
            </select>
          </div>
        </div>

        {activeFilters.length > 0 && (
          <div className="d-flex flex-wrap gap-2 mt-3 align-items-center">
            {activeFilters.map((f) => (
              <span key={f.key} className="badge bg-primary-subtle text-primary-emphasis border">
                {f.label}
              </span>
            ))}
            {loading && <span className="spinner-border spinner-border-sm text-primary" role="status" />}
          </div>
        )}
      </div>
    </div>
  );
};

export default FilterBar;
