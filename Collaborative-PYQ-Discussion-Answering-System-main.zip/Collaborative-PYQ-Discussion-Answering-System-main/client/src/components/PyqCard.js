import React from 'react';
import { Link } from 'react-router-dom';
import { formatDate, DIFFICULTY_VARIANT } from '../utils/helpers';
import UserAvatar from './UserAvatar';

const PyqCard = ({ pyq }) => {
  const {
    _id,
    title,
    exam,
    subject,
    topic,
    subTopic,
    year,
    marks,
    difficulty,
    author,
    views = 0,
    createdAt,
    questionImage,
    images = [],
  } = pyq;

  const imageCount = images?.length || (questionImage?.url ? 1 : 0);

  return (
    <div className="card question-card mb-3">
      <div className="card-body">
        <div className="row g-3">
          <div className="col-auto text-center vote-box">
            <div className="text-primary fw-bold fs-5">{marks}</div>
            <div className="text-muted small">marks</div>
            <div className="text-muted small mt-1">{views} views</div>
          </div>
          <div className="col">
            <Link to={`/pyqs/${_id}`} className="text-decoration-none">
              <h5 className="card-title mb-2 text-primary">{title}</h5>
            </Link>
            <div className="d-flex flex-wrap gap-2 mb-2">
              <span className="badge bg-dark stat-badge">{exam}</span>
              <span className="badge bg-secondary stat-badge">{subject}</span>
              {topic && <span className="badge bg-primary stat-badge">{topic}</span>}
              {subTopic && (
                <span className="badge bg-primary-subtle text-primary-emphasis stat-badge">
                  {subTopic}
                </span>
              )}
              <span className="badge bg-info stat-badge">{year}</span>
              <span className={`badge bg-${DIFFICULTY_VARIANT[difficulty] || 'secondary'} stat-badge`}>
                {difficulty}
              </span>
            </div>
            <div className="text-muted small d-flex align-items-center gap-2">
              <UserAvatar user={author} size={22} />
              <span>
                Added by <strong>{author?.name || 'Unknown'}</strong> · {formatDate(createdAt)}
              </span>
              {imageCount > 0 && (
                <span className="badge bg-light text-dark border">
                  <i className="bi bi-image me-1" />{imageCount}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PyqCard;
