import React from 'react';
import { Link } from 'react-router-dom';
import { getBadgeInfo } from '../utils/helpers';

const ReputationBadge = ({ reputation, showScore = true, size = 'sm' }) => {
  const badge = getBadgeInfo(reputation);

  return (
    <span className={`badge bg-${badge.variant} text-${badge.variant === 'light' ? 'dark' : 'white'} ${size === 'lg' ? 'fs-6' : ''}`}>
      <i className={`bi ${badge.icon} me-1`} />
      {badge.name}
      {showScore && <span className="ms-1">({reputation || 0})</span>}
    </span>
  );
};

export default ReputationBadge;
