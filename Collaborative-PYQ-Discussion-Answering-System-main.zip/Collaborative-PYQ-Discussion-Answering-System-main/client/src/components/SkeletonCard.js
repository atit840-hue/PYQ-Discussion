import React from 'react';

const SkeletonCard = () => (
  <div className="card mb-3 placeholder-glow">
    <div className="card-body">
      <div className="row g-3">
        <div className="col-auto">
          <span className="placeholder col-6" style={{ height: 40, display: 'block' }} />
        </div>
        <div className="col">
          <span className="placeholder col-8 mb-2" />
          <span className="placeholder col-4 mb-2" />
          <span className="placeholder col-6" />
        </div>
      </div>
    </div>
  </div>
);

export const SkeletonList = ({ count = 3 }) => (
  <>
    {Array.from({ length: count }).map((_, i) => (
      <SkeletonCard key={i} />
    ))}
  </>
);

export default SkeletonCard;
