import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  explainAnswer,
  summarizeQuestion,
  getSimilarQuestions,
} from '../services/aiService';
import { getErrorMessage } from '../utils/helpers';
import LoadingSpinner from './LoadingSpinner';

const AiPanel = ({ question, answers }) => {
  const [summary, setSummary] = useState('');
  const [similar, setSimilar] = useState([]);
  const [similarNote, setSimilarNote] = useState('');
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState('');
  const [error, setError] = useState('');
  const [selectedAnswerId, setSelectedAnswerId] = useState('');

  const run = async (action, fn) => {
    setLoading(action);
    setError('');
    try {
      await fn();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading('');
    }
  };

  const handleSummarize = () =>
    run('summary', async () => {
      const { data } = await summarizeQuestion(question._id);
      setSummary(data.data.summary);
    });

  const handleSimilar = () =>
    run('similar', async () => {
      const { data } = await getSimilarQuestions(question._id);
      setSimilar(data.data.recommendations);
      setSimilarNote(data.data.aiNote);
    });

  const handleExplain = () =>
    run('explain', async () => {
      const answer = answers.find((a) => a._id === selectedAnswerId);
      if (!answer) {
        setError('Select an answer to explain');
        return;
      }
      const { data } = await explainAnswer({
        questionId: question._id,
        answerId: answer._id,
        questionTitle: question.title,
        questionDescription: question.description,
        answerText: answer.answerText,
      });
      setExplanation(data.data.explanation);
    });

  return (
    <div className="card mb-4 border-primary">
      <div className="card-header bg-primary text-white d-flex align-items-center gap-2">
        <i className="bi bi-stars" />
        <span className="fw-semibold">AI Assistant (Gemini)</span>
      </div>
      <div className="card-body">
        {error && <div className="alert alert-danger py-2 small">{error}</div>}

        <div className="d-flex flex-wrap gap-2 mb-3">
          <button
            className="btn btn-sm btn-outline-primary"
            onClick={handleSummarize}
            disabled={!!loading}
          >
            {loading === 'summary' ? 'Summarizing...' : 'Summarize Question'}
          </button>
          <button
            className="btn btn-sm btn-outline-primary"
            onClick={handleSimilar}
            disabled={!!loading}
          >
            {loading === 'similar' ? 'Finding...' : 'Similar PYQs'}
          </button>
        </div>

        {loading && loading !== 'explain' && (
          <LoadingSpinner size="sm" text="AI is thinking..." />
        )}

        {summary && (
          <div className="bg-body-secondary rounded p-3 mb-3">
            <h6 className="small text-uppercase text-muted">Summary</h6>
            <p className="mb-0 small" style={{ whiteSpace: 'pre-wrap' }}>{summary}</p>
          </div>
        )}

        {similar.length > 0 && (
          <div className="mb-3">
            <h6 className="small text-uppercase text-muted">Similar Questions</h6>
            {similarNote && <p className="small text-muted">{similarNote}</p>}
            <ul className="list-group list-group-flush">
              {similar.map((q) => (
                <li key={q._id} className="list-group-item px-0">
                  <Link to={`/questions/${q._id}`} className="text-decoration-none small">
                    {q.title}
                  </Link>
                  <span className="badge bg-secondary ms-2">{q.subject}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {answers.length > 0 && (
          <div className="border-top pt-3">
            <h6 className="small text-uppercase text-muted">Explain an Answer</h6>
            <div className="row g-2 align-items-end">
              <div className="col-md-8">
                <select
                  className="form-select form-select-sm"
                  value={selectedAnswerId}
                  onChange={(e) => setSelectedAnswerId(e.target.value)}
                >
                  <option value="">Select answer...</option>
                  {answers.map((a) => (
                    <option key={a._id} value={a._id}>
                      {a.author?.name}: {a.answerText.slice(0, 60)}...
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-4">
                <button
                  className="btn btn-sm btn-primary w-100"
                  onClick={handleExplain}
                  disabled={!!loading || !selectedAnswerId}
                >
                  {loading === 'explain' ? 'Explaining...' : 'Explain'}
                </button>
              </div>
            </div>
            {explanation && (
              <div className="bg-body-secondary rounded p-3 mt-3">
                <p className="mb-0 small" style={{ whiteSpace: 'pre-wrap' }}>{explanation}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default AiPanel;
