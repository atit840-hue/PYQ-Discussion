import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getComments, createComment, deleteComment } from '../services/answerService';
import { formatDateTime, getErrorMessage } from '../utils/helpers';
import AlertMessage from './AlertMessage';
import LoadingSpinner from './LoadingSpinner';

const CommentSection = ({ answerId, onCommentCountChange }) => {
  const { user, isAdmin } = useAuth();
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const fetchComments = async () => {
    try {
      const { data } = await getComments(answerId, { limit: 50 });
      setComments(data.data);
      onCommentCountChange?.(data.data.length);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [answerId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;

    setSubmitting(true);
    setError('');
    try {
      const { data } = await createComment(answerId, { comment: text });
      setComments((prev) => [...prev, data.data.comment]);
      setText('');
      onCommentCountChange?.(comments.length + 1);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (commentId) => {
    if (!window.confirm('Delete this comment?')) return;
    try {
      await deleteComment(commentId);
      setComments((prev) => prev.filter((c) => c._id !== commentId));
      onCommentCountChange?.(comments.length - 1);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div className="mt-3 pt-3 border-top">
      <h6 className="mb-3">Comments ({comments.length})</h6>
      <AlertMessage message={error} onClose={() => setError('')} />

      {loading ? (
        <LoadingSpinner size="sm" />
      ) : (
        <div className="mb-3">
          {comments.length === 0 ? (
            <p className="text-muted small mb-0">No comments yet.</p>
          ) : (
            comments.map((c) => (
              <div key={c._id} className="bg-body-secondary rounded p-2 mb-2">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <strong className="small">{c.user?.name}</strong>
                    <span className="text-muted small ms-2">{formatDateTime(c.createdAt)}</span>
                    <p className="mb-0 small mt-1">{c.comment}</p>
                  </div>
                  {user && (isAdmin || c.user?._id === user._id) && (
                    <button
                      className="btn btn-sm btn-outline-danger"
                      onClick={() => handleDelete(c._id)}
                    >
                      ×
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {user ? (
        <form onSubmit={handleSubmit}>
          <div className="input-group input-group-sm">
            <input
              type="text"
              className="form-control"
              placeholder="Add a comment..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={2000}
            />
            <button className="btn btn-primary" type="submit" disabled={submitting || !text.trim()}>
              {submitting ? '...' : 'Post'}
            </button>
          </div>
        </form>
      ) : (
        <p className="text-muted small mb-0">Login to comment.</p>
      )}
    </div>
  );
};

export default CommentSection;
