import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getNotifications, markAsRead, markAllAsRead } from '../services/notificationService';
import { formatDateTime, getErrorMessage } from '../utils/helpers';

const NotificationBell = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await getNotifications({ limit: 10 });
      setNotifications(data.data);
      setUnreadCount(data.unreadCount || 0);
    } catch {
      /* silent */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  const handleRead = async (id) => {
    try {
      await markAsRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n._id === id ? { ...n, isRead: true } : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
    } catch (err) {
      console.error(getErrorMessage(err));
    }
  };

  const handleReadAll = async () => {
    try {
      await markAllAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error(getErrorMessage(err));
    }
  };

  return (
    <div className={`dropdown ${open ? 'show' : ''}`}>
      <button
        className="btn btn-outline-secondary btn-sm position-relative"
        onClick={() => { setOpen((p) => !p); if (!open) fetchNotifications(); }}
        aria-expanded={open}
      >
        <i className="bi bi-bell" />
        {unreadCount > 0 && (
          <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>
      <ul className={`dropdown-menu dropdown-menu-end p-0 shadow ${open ? 'show' : ''}`} style={{ width: 320 }}>
        <li className="dropdown-header d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
          <span className="fw-semibold">Notifications</span>
          {unreadCount > 0 && (
            <button className="btn btn-link btn-sm p-0" onClick={handleReadAll}>
              Mark all read
            </button>
          )}
        </li>
        {loading ? (
          <li className="px-3 py-4 text-center text-muted small">Loading...</li>
        ) : notifications.length === 0 ? (
          <li className="px-3 py-4 text-center text-muted small">No notifications</li>
        ) : (
          notifications.map((n) => (
            <li key={n._id}>
              <Link
                to={n.link || '#'}
                className={`dropdown-item py-2 px-3 border-bottom ${!n.isRead ? 'bg-primary-subtle' : ''}`}
                onClick={() => !n.isRead && handleRead(n._id)}
              >
                <div className="fw-semibold small">{n.title}</div>
                <div className="text-muted small">{n.message}</div>
                <div className="text-muted" style={{ fontSize: '0.7rem' }}>
                  {formatDateTime(n.createdAt)}
                </div>
              </Link>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};

export default NotificationBell;
