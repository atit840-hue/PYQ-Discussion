import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import {
  upvoteAnswer,
  downvoteAnswer,
  verifyAnswer,
  deleteAnswer,
} from '../services/answerService';
import { acceptAnswer } from '../services/questionService';
import { createReport } from '../services/reportService';
import { formatDateTime, getErrorMessage } from '../utils/helpers';
import VoteBox from './VoteBox';
import ReputationBadge from './ReputationBadge';
import UserAvatar from './UserAvatar';
import CommentSection from './CommentSection';
import AlertMessage from './AlertMessage';

const AnswerCard = ({
  answer: initialAnswer,
  question,
  acceptedAnswerId,
  onDelete,
  onUpdate,
  onAccept,
}) => {
  const { user, isAdmin, isModerator } = useAuth();
  const { showToast } = useToast();
  const [answer, setAnswer] = useState(initialAnswer);
  const [showComments, setShowComments] = useState(false);
  const [error, setError] = useState('');
  const [voting, setVoting] = useState(false);
  const [accepting, setAccepting] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('');

  const isAccepted = acceptedAnswerId === answer._id;

  const [userVote, setUserVote] = useState(() => {
    if (!user) return null;
    const uid = user._id;
    if (initialAnswer.upvotes?.some((id) => (id._id || id) === uid)) return 'upvote';
    if (initialAnswer.downvotes?.some((id) => (id._id || id) === uid)) return 'downvote';
    return null;
  });
  const [voteScore, setVoteScore] = useState(
    initialAnswer.voteScore ??
      (initialAnswer.upvotes?.length || 0) - (initialAnswer.downvotes?.length || 0)
  );

  const isQuestionOwner =
    user && question && (question.author?._id === user._id || question.author === user._id);

  const handleVote = async (type) => {
    if (!user) return;
    setVoting(true);
    setError('');
    try {
      const fn = type === 'upvote' ? upvoteAnswer : downvoteAnswer;
      const { data } = await fn(answer._id);
      setVoteScore(data.data.voteScore);
      setUserVote(data.data.userVote);
      onUpdate?.();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setVoting(false);
    }
  };

  const handleAccept = async () => {
    setAccepting(true);
    try {
      await acceptAnswer(question._id, answer._id);
      showToast(isAccepted ? 'Acceptance removed' : 'Answer accepted! (+15 rep)', 'success');
      onAccept?.();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setAccepting(false);
    }
  };

  const handleVerify = async () => {
    try {
      const { data } = await verifyAnswer(answer._id, !answer.verified);
      setAnswer(data.data.answer);
      showToast(answer.verified ? 'Verification removed' : 'Answer verified (+20 rep)', 'success');
      onUpdate?.();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this answer permanently?')) return;
    try {
      await deleteAnswer(answer._id);
      onDelete?.(answer._id);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleReport = async (e) => {
    e.preventDefault();
    if (!reportReason.trim()) return;
    try {
      await createReport({ targetType: 'answer', targetId: answer._id, reason: reportReason });
      setShowReport(false);
      setReportReason('');
      showToast('Report submitted', 'success');
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div className={`card answer-card mb-3 ${answer.verified ? 'verified' : ''} ${isAccepted ? 'accepted' : ''}`}>
      <div className="card-body">
        <AlertMessage message={error} onClose={() => setError('')} />

        <div className="d-flex gap-3">
          <VoteBox
            voteScore={voteScore}
            userVote={userVote}
            onUpvote={() => handleVote('upvote')}
            onDownvote={() => handleVote('downvote')}
            disabled={!user || voting}
          />

          <div className="flex-grow-1">
            <div className="d-flex flex-wrap gap-2 mb-2">
              {isAccepted && (
                <span className="badge bg-success">
                  <i className="bi bi-check-circle-fill me-1" />Accepted Answer
                </span>
              )}
              {answer.verified && (
                <span className="badge bg-primary">
                  <i className="bi bi-patch-check-fill me-1" />Verified
                </span>
              )}
            </div>

            <p className="mb-2" style={{ whiteSpace: 'pre-wrap' }}>{answer.answerText}</p>

            <div className="d-flex flex-wrap gap-2 align-items-center text-muted small">
              <UserAvatar user={answer.author} size={22} />
              <span>
                <strong>{answer.author?.name}</strong>
                {answer.author?.reputation !== undefined && (
                  <span className="ms-1">
                    <ReputationBadge reputation={answer.author.reputation} showScore={false} />
                  </span>
                )}
              </span>
              <span>· {formatDateTime(answer.createdAt)}</span>
              {answer.verifiedBy && <span>· Verified by {answer.verifiedBy?.name}</span>}
            </div>

            <div className="d-flex flex-wrap gap-2 mt-2">
              <button className="btn btn-sm btn-outline-secondary" onClick={() => setShowComments((p) => !p)}>
                <i className="bi bi-chat me-1" />Comments
              </button>
              {isQuestionOwner && (
                <button
                  className={`btn btn-sm ${isAccepted ? 'btn-success' : 'btn-outline-success'}`}
                  onClick={handleAccept}
                  disabled={accepting}
                >
                  <i className="bi bi-check2-circle me-1" />
                  {accepting ? '...' : isAccepted ? 'Unaccept' : 'Accept'}
                </button>
              )}
              {user && (
                <button className="btn btn-sm btn-outline-warning" onClick={() => setShowReport((p) => !p)}>
                  <i className="bi bi-flag me-1" />Report
                </button>
              )}
              {isModerator && (
                <button className="btn btn-sm btn-outline-primary" onClick={handleVerify}>
                  {answer.verified ? 'Unverify' : 'Verify'}
                </button>
              )}
              {isAdmin && (
                <button className="btn btn-sm btn-outline-danger" onClick={handleDelete}>Delete</button>
              )}
            </div>

            {showReport && (
              <form className="mt-2" onSubmit={handleReport}>
                <input className="form-control form-control-sm mb-1" placeholder="Reason" value={reportReason} onChange={(e) => setReportReason(e.target.value)} required />
                <button type="submit" className="btn btn-sm btn-warning">Submit</button>
              </form>
            )}

            {showComments && <CommentSection answerId={answer._id} />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnswerCard;
