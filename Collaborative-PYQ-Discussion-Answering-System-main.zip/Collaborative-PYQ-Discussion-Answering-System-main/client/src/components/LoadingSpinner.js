import React from 'react';

const LoadingSpinner = ({ size = 'md', text }) => {
  const sizeClass = size === 'sm' ? 'spinner-border-sm' : '';

  return (
    <div className="text-center">
      <div className={`spinner-border text-primary ${sizeClass}`} role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
      {text && <p className="text-muted mt-2 mb-0 small">{text}</p>}
    </div>
  );
};

export default LoadingSpinner;
