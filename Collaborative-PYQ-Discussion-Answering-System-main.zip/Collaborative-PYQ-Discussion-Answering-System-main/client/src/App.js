import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './context/ToastContext';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import DiscussionsHub from './pages/DiscussionsHub';
import Login from './pages/Login';
import Register from './pages/Register';
import QuestionDetails from './pages/QuestionDetails';
import Profile from './pages/Profile';
import Bookmarks from './pages/Bookmarks';
import SubjectDetail from './pages/SubjectDetail';
import Leaderboard from './pages/Leaderboard';
import PyqDetail from './pages/PyqDetail';
import SemesterPyqs from './pages/SemesterPyqs';
import AdminDashboard from './pages/AdminDashboard';

function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <BrowserRouter
            future={{
              v7_startTransition: true,
              v7_relativeSplatPath: true,
            }}
          >
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<DiscussionsHub />} />
              <Route path="login" element={<Login />} />
              <Route path="register" element={<Register />} />
              <Route path="questions/:id" element={<QuestionDetails />} />
              <Route path="subjects/:slug" element={<SubjectDetail />} />
              <Route path="leaderboard" element={<Leaderboard />} />
              <Route path="semester-pyqs" element={<SemesterPyqs />} />
              <Route path="pyqs/:id" element={<PyqDetail />} />

              <Route
                path="profile"
                element={
                  <ProtectedRoute>
                    <Profile />
                  </ProtectedRoute>
                }
              />
              <Route
                path="bookmarks"
                element={
                  <ProtectedRoute>
                    <Bookmarks />
                  </ProtectedRoute>
                }
              />
              <Route
                path="admin"
                element={
                  <ProtectedRoute roles={['admin', 'moderator']}>
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Legacy redirects */}
              <Route path="dashboard" element={<Navigate to="/leaderboard?tab=progress" replace />} />
              <Route path="subjects" element={<Navigate to="/?tab=subjects" replace />} />
              <Route path="pyqs" element={<Navigate to="/?tab=pyqs" replace />} />
              <Route path="ask" element={<Navigate to="/?tab=ask" replace />} />
              <Route path="pyqs/add" element={<Navigate to="/?tab=upload" replace />} />

              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Routes>
          </BrowserRouter>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}

export default App;
