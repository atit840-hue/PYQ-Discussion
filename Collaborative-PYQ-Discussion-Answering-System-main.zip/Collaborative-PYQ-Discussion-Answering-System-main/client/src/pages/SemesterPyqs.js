import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getSemesterCurriculum, getResources } from '../services/resourceService';
import { BRANCHES, getErrorMessage } from '../utils/helpers';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

const SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8];

const SemesterPyqs = () => {
  const [branch, setBranch] = useState('');
  const [semester, setSemester] = useState('');
  const [subjects, setSubjects] = useState([]);
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!branch || !semester) {
      setSubjects([]);
      return;
    }
    setLoading(true);
    setError('');
    Promise.all([
      getSemesterCurriculum({ branch, semester }),
      getResources({ branch, semester, limit: 50 }),
    ])
      .then(([curRes, resRes]) => {
        setSubjects(curRes.data.data.subjects || []);
        setResources(resRes.data.data || []);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [branch, semester]);

  const resourcesForSubject = (subjectName) =>
    resources.filter((r) => r.subject.toLowerCase() === subjectName.toLowerCase());

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title mb-1">Semester PYQs</h1>
        <p className="page-subtitle mb-0">
          Branch-wise semester study material — notes, PYQs, and resources.
        </p>
      </div>

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="glass-card p-4 mb-4">
        <div className="row g-3">
          <div className="col-md-6">
            <label className="form-label fw-semibold">Select Branch</label>
            <div className="d-flex flex-wrap gap-2">
              {BRANCHES.map((b) => (
                <button
                  key={b}
                  type="button"
                  className={`btn btn-sm ${branch === b ? 'btn-primary' : 'btn-outline-primary'}`}
                  onClick={() => { setBranch(b); setSemester(''); }}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>
          {branch && (
            <div className="col-md-6">
              <label className="form-label fw-semibold">Select Semester</label>
              <div className="d-flex flex-wrap gap-2">
                {SEMESTERS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    className={`btn btn-sm ${semester === String(s) ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => setSemester(String(s))}
                  >
                    Sem {s}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {loading && <LoadingSpinner text="Loading subjects..." />}

      {!loading && branch && semester && (
        <>
          <div className="d-flex align-items-center justify-content-between mb-3">
            <h5 className="fw-semibold mb-0">{branch} · Semester {semester}</h5>
            <Link
              to={`/?tab=notes&branch=${branch}&semester=${semester}`}
              className="btn btn-primary btn-sm"
            >
              <i className="bi bi-upload me-1" /> Upload Notes
            </Link>
          </div>
          <div className="row g-4">
            {subjects.map((subject) => {
              const subjectResources = resourcesForSubject(subject);
              return (
                <div key={subject} className="col-md-6 col-lg-4">
                  <div className="glass-card subject-hub-card h-100 p-4">
                    <h5 className="fw-bold text-primary mb-3">{subject}</h5>
                    <div className="d-flex flex-wrap gap-2 mb-3">
                      <Link
                        to={`/?tab=pyqs&subject=${encodeURIComponent(subject)}`}
                        className="btn btn-outline-primary btn-sm"
                      >
                        <i className="bi bi-journal-bookmark me-1" /> PYQs
                      </Link>
                      <Link
                        to={`/?tab=discussions&subject=${encodeURIComponent(subject)}`}
                        className="btn btn-outline-secondary btn-sm"
                      >
                        <i className="bi bi-chat-dots me-1" /> Discussions
                      </Link>
                    </div>
                    <div className="small">
                      <div className="fw-semibold mb-1">Uploaded Resources ({subjectResources.length})</div>
                      {subjectResources.length === 0 ? (
                        <p className="text-muted mb-0">No notes yet.</p>
                      ) : (
                        subjectResources.slice(0, 3).map((r) => (
                          <div key={r._id} className="mb-1">
                            <a href={r.fileUrl} target="_blank" rel="noopener noreferrer" className="text-decoration-none">
                              <i className="bi bi-file-earmark me-1" />{r.title}
                            </a>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {!branch && (
        <div className="text-center py-5 text-muted glass-card">
          <i className="bi bi-mortarboard display-4 d-block mb-3" />
          <p>Select a branch to browse semester-wise material.</p>
        </div>
      )}
    </div>
  );
};

export default SemesterPyqs;
