import React, { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getPyqs } from '../services/pyqService';
import { getErrorMessage } from '../utils/helpers';
import useDebounce from '../hooks/useDebounce';
import PyqCard from '../components/PyqCard';
import PyqFilterBar from '../components/PyqFilterBar';
import Pagination from '../components/Pagination';
import AlertMessage from '../components/AlertMessage';
import { SkeletonList } from '../components/SkeletonCard';

const defaultFilters = {
  search: '',
  exam: '',
  subject: '',
  topic: '',
  subTopic: '',
  year: '',
  difficulty: '',
  sort: '',
  page: 1,
};

const Pyqs = ({ embedded = false }) => {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [pyqs, setPyqs] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState(() => ({
    ...defaultFilters,
    search: searchParams.get('search') || '',
    exam: searchParams.get('exam') || '',
    subject: searchParams.get('subject') || '',
    topic: searchParams.get('topic') || '',
    subTopic: searchParams.get('subTopic') || '',
    year: searchParams.get('year') || '',
    difficulty: searchParams.get('difficulty') || '',
    sort: searchParams.get('sort') || '',
    page: parseInt(searchParams.get('page') || '1', 10),
  }));

  const debouncedSearch = useDebounce(filters.search);

  const fetchPyqs = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = { page: filters.page, limit: 10 };
      if (debouncedSearch) params.search = debouncedSearch;
      if (filters.exam) params.exam = filters.exam;
      if (filters.subject) params.subject = filters.subject;
      if (filters.topic) params.topic = filters.topic;
      if (filters.subTopic) params.subTopic = filters.subTopic;
      if (filters.year) params.year = filters.year;
      if (filters.difficulty) params.difficulty = filters.difficulty;
      if (filters.sort) params.sort = filters.sort;

      const { data } = await getPyqs(params);
      setPyqs(data.data);
      setPagination(data.pagination);

      const sp = new URLSearchParams();
      sp.set('tab', 'pyqs');
      Object.entries({ ...filters, search: debouncedSearch }).forEach(([k, v]) => {
        if (v && k !== 'page') sp.set(k, v);
      });
      if (filters.page > 1) sp.set('page', filters.page);
      setSearchParams(sp, { replace: true });
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [filters, debouncedSearch, setSearchParams]);

  useEffect(() => {
    fetchPyqs();
  }, [fetchPyqs]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    if (name === 'subject') {
      setFilters((prev) => ({ ...prev, subject: value, topic: '', subTopic: '', page: 1 }));
      return;
    }
    if (name === 'topic') {
      setFilters((prev) => ({ ...prev, topic: value, subTopic: '', page: 1 }));
      return;
    }
    setFilters((prev) => ({ ...prev, [name]: value, page: 1 }));
  };

  const handleClear = () => setFilters(defaultFilters);

  return (
    <div>
      {!embedded && (
        <div className="page-header d-flex flex-wrap justify-content-between align-items-start gap-2">
          <div>
            <h2 className="fw-bold mb-1">PYQ Repository</h2>
            <p className="text-muted mb-0">
              Official previous year questions with solutions — GATE, semester exams, and more.
            </p>
          </div>
          {user && (
            <Link to="/?tab=upload" className="btn btn-primary">
              <i className="bi bi-plus-lg me-1" /> Add PYQ
            </Link>
          )}
        </div>
      )}

      <PyqFilterBar
        filters={filters}
        onChange={handleFilterChange}
        onClear={handleClear}
        loading={loading}
      />

      <AlertMessage message={error} onClose={() => setError('')} />

      {loading ? (
        <SkeletonList count={4} />
      ) : pyqs.length === 0 ? (
        <div className="text-center py-5 text-muted">
          <i className="bi bi-journal-bookmark display-4 d-block mb-3" />
          <p className="fs-5">No PYQs found.</p>
          <p>Try adjusting filters or add the first entry to the repository.</p>
          {user && (
            <Link to="/pyqs/add" className="btn btn-primary mt-2">Add PYQ</Link>
          )}
        </div>
      ) : (
        <>
          {pyqs.map((pyq) => (
            <PyqCard key={pyq._id} pyq={pyq} />
          ))}
          <Pagination
            pagination={pagination}
            onPageChange={(page) => setFilters((prev) => ({ ...prev, page }))}
          />
        </>
      )}
    </div>
  );
};

export default Pyqs;
