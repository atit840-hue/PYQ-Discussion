import React, { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getQuestions } from '../services/questionService';
import { getErrorMessage } from '../utils/helpers';
import useDebounce from '../hooks/useDebounce';
import QuestionCard from '../components/QuestionCard';
import FilterBar from '../components/FilterBar';
import Pagination from '../components/Pagination';
import AlertMessage from '../components/AlertMessage';
import HomeFeedPanel from '../components/HomeFeedPanel';
import { SkeletonList } from '../components/SkeletonCard';

const defaultFilters = {
  search: '',
  subject: '',
  topic: '',
  subTopic: '',
  semester: '',
  year: '',
  difficulty: '',
  sort: '',
  page: 1,
};

const Home = ({ embedded = false }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [questions, setQuestions] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState(() => ({
    ...defaultFilters,
    search: searchParams.get('search') || '',
    subject: searchParams.get('subject') || '',
    topic: searchParams.get('topic') || '',
    subTopic: searchParams.get('subTopic') || '',
    semester: searchParams.get('semester') || '',
    year: searchParams.get('year') || '',
    difficulty: searchParams.get('difficulty') || '',
    sort: searchParams.get('sort') || '',
    page: parseInt(searchParams.get('page') || '1', 10),
  }));

  const debouncedSearch = useDebounce(filters.search);

  const fetchQuestions = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = { page: filters.page, limit: 10 };
      if (debouncedSearch) params.search = debouncedSearch;
      if (filters.subject) params.subject = filters.subject;
      if (filters.topic) params.topic = filters.topic;
      if (filters.subTopic) params.subTopic = filters.subTopic;
      if (filters.semester) params.semester = filters.semester;
      if (filters.year) params.year = filters.year;
      if (filters.difficulty) params.difficulty = filters.difficulty;
      if (filters.sort) params.sort = filters.sort;

      const { data } = await getQuestions(params);
      setQuestions(data.data);
      setPagination(data.pagination);

      const sp = new URLSearchParams();
      sp.set('tab', 'discussions');
      Object.entries({ ...filters, search: debouncedSearch }).forEach(([k, v]) => {
        if (v && k !== 'page') sp.set(k, v);
      });
      if (filters.page > 1) sp.set('page', filters.page);
      setSearchParams(sp, { replace: true });
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [filters, debouncedSearch, setSearchParams]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value, page: 1 }));
  };

  const handleClear = () => setFilters(defaultFilters);

  return (
    <div>
      {!embedded && (
        <div className="page-header">
          <h2 className="fw-bold mb-1">Discussions</h2>
          <p className="text-muted mb-0">Browse and discuss previous year questions collaboratively.</p>
        </div>
      )}

      <HomeFeedPanel />

      <FilterBar
        filters={filters}
        onChange={handleFilterChange}
        onClear={handleClear}
        loading={loading}
      />

      <AlertMessage message={error} onClose={() => setError('')} />

      {loading ? (
        <SkeletonList count={4} />
      ) : questions.length === 0 ? (
        <div className="text-center py-5 text-muted">
          <i className="bi bi-inbox display-4 d-block mb-3" />
          <p className="fs-5">No questions found.</p>
          <p>Try adjusting filters or ask the first PYQ!</p>
        </div>
      ) : (
        <>
          {questions.map((q) => (
            <QuestionCard key={q._id} question={q} />
          ))}
          <Pagination
            pagination={pagination}
            onPageChange={(page) => setFilters((prev) => ({ ...prev, page }))}
          />
        </>
      )}
    </div>
  );
};

export default Home;
