import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { uploadProfilePicture } from '../services/uploadService';
import { getMyProfile } from '../services/homeService';
import { formatDateTime, ROLE_VARIANT, getErrorMessage } from '../utils/helpers';
import UserAvatar from '../components/UserAvatar';
import ReputationBadge from '../components/ReputationBadge';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const { showToast } = useToast();
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [profileData, setProfileData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyProfile()
      .then(({ data }) => setProfileData(data.data))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (!user) return null;
  if (loading) return <LoadingSpinner text="Loading profile..." />;

  const stats = profileData?.stats || {};
  const activity = profileData?.activity || [];
  const streak = profileData?.streak || { current: 0, longest: 0 };

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      const { data } = await uploadProfilePicture(file);
      updateUser(data.data.user);
      showToast('Profile picture updated!', 'success');
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <div className="col-lg-10 mx-auto">
      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="profile-hero glass-card p-4 mb-4">
        <div className="row align-items-center g-4">
          <div className="col-auto">
            <div className="position-relative">
              <UserAvatar user={user} size={110} />
              <button
                className="btn btn-sm btn-primary position-absolute bottom-0 end-0 rounded-circle profile-camera-btn"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
              >
                {uploading ? <span className="spinner-border spinner-border-sm" /> : <i className="bi bi-camera" />}
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="d-none" onChange={handleUpload} />
            </div>
          </div>
          <div className="col">
            <h1 className="page-title mb-2">{user.name}</h1>
            <div className="d-flex flex-wrap gap-2 mb-2">
              <span className={`badge bg-${ROLE_VARIANT[user.role] || 'secondary'}`}>{user.role}</span>
              <ReputationBadge reputation={user.reputation} />
              <span className="badge bg-dark">Rank #{stats.rank || '—'}</span>
            </div>
            <p className="text-muted mb-0">{user.email}</p>
          </div>
          <div className="col-md-auto text-center">
            <div className="streak-flame mb-1">🔥</div>
            <div className="fw-bold">{streak.current} day streak</div>
            <div className="text-muted small">Best: {streak.longest} days</div>
          </div>
        </div>
      </div>

      <div className="row g-3 mb-4">
        {[
          { label: 'Questions', value: stats.questionsAsked, icon: 'bi-chat-dots', color: 'primary' },
          { label: 'Answers', value: stats.answersPosted, icon: 'bi-pencil', color: 'success' },
          { label: 'Notes', value: stats.notesUploaded, icon: 'bi-file-earmark', color: 'info' },
          { label: 'Reputation', value: stats.reputation, icon: 'bi-star', color: 'warning' },
          { label: 'Accepted', value: stats.acceptedAnswers, icon: 'bi-check-circle', color: 'success' },
        ].map((s) => (
          <div key={s.label} className="col-6 col-md">
            <div className="stat-tile">
              <i className={`bi ${s.icon} text-${s.color} mb-2`} />
              <div className="stat-tile-value">{s.value || 0}</div>
              <div className="stat-tile-label">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-4">
        <div className="col-lg-7">
          <div className="glass-card p-4">
            <h5 className="fw-semibold mb-3">Recent Activity</h5>
            {activity.length === 0 ? (
              <p className="text-muted mb-0">No activity yet. Start by asking a question!</p>
            ) : (
              <ul className="activity-timeline list-unstyled mb-0">
                {activity.map((item, i) => (
                  <li key={i} className="activity-item">
                    <div className="activity-dot" />
                    <div>
                      <span className="badge bg-secondary-subtle text-secondary me-2">{item.type}</span>
                      {item.link ? (
                        <Link to={item.link} className="text-decoration-none">{item.text}</Link>
                      ) : (
                        <span>{item.text}</span>
                      )}
                      <div className="text-muted small">{formatDateTime(item.date)}</div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <div className="col-lg-5">
          <div className="glass-card p-4 h-100">
            <h5 className="fw-semibold mb-3">Account</h5>
            <dl className="row small mb-0">
              <dt className="col-5 text-muted">Member since</dt>
              <dd className="col-7">{formatDateTime(user.createdAt)}</dd>
              <dt className="col-5 text-muted">Status</dt>
              <dd className="col-7">
                <span className={`badge bg-${user.isActive ? 'success' : 'danger'}`}>
                  {user.isActive ? 'Active' : 'Inactive'}
                </span>
              </dd>
            </dl>
            <hr />
            <Link to="/leaderboard" className="btn btn-outline-primary btn-sm w-100">
              <i className="bi bi-trophy me-1" /> View Leaderboard
            </Link>
            <Link to="/leaderboard?tab=progress" className="btn btn-outline-secondary btn-sm w-100 mt-2">
              <i className="bi bi-graph-up me-1" /> My Progress
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
