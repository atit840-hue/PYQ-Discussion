import React, { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import TabNav from '../components/TabNav';
import MyProgress from '../components/MyProgress';
import { getLeaderboard } from '../services/userService';
import { getErrorMessage } from '../utils/helpers';
import UserAvatar from '../components/UserAvatar';
import ReputationBadge from '../components/ReputationBadge';
import Pagination from '../components/Pagination';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';

const PERIOD_TABS = [
  { id: 'all', label: 'All Time', icon: 'bi-infinity' },
  { id: 'month', label: 'Monthly', icon: 'bi-calendar3' },
  { id: 'week', label: 'Weekly', icon: 'bi-calendar-week' },
];

const SORT_TABS = [
  { id: 'reputation', label: 'Reputation' },
  { id: 'answers', label: 'Answers' },
  { id: 'notes', label: 'Notes' },
  { id: 'accepted', label: 'Accepted' },
];

const Leaderboard = () => {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const mainTab = searchParams.get('tab') || 'rankings';
  const period = searchParams.get('period') || 'all';
  const sortBy = searchParams.get('sortBy') || 'reputation';

  const [users, setUsers] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const mainTabs = [
    { id: 'rankings', label: 'Rankings', icon: 'bi-trophy' },
    ...(user ? [{ id: 'progress', label: 'My Progress', icon: 'bi-graph-up' }] : []),
  ];

  useEffect(() => {
    if (mainTab !== 'rankings') return;
    setLoading(true);
    getLeaderboard({ page, limit: 20, period, sortBy })
      .then(({ data }) => {
        setUsers(data.data);
        setPagination(data.pagination);
      })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [page, period, sortBy, mainTab]);

  const setParam = (key, value) => {
    const next = new URLSearchParams(searchParams);
    next.set(key, value);
    setSearchParams(next, { replace: true });
    setPage(1);
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title mb-1"><i className="bi bi-trophy text-warning me-2" />Leaderboard</h1>
        <p className="page-subtitle mb-0">See who&apos;s helping the community learn</p>
      </div>

      <TabNav tabs={mainTabs} paramKey="tab" className="mb-4" />

      {mainTab === 'progress' ? (
        <MyProgress />
      ) : (
        <>
          <div className="d-flex flex-wrap gap-2 mb-3">
            {PERIOD_TABS.map((p) => (
              <button
                key={p.id}
                type="button"
                className={`btn btn-sm ${period === p.id ? 'btn-primary' : 'btn-outline-secondary'}`}
                onClick={() => setParam('period', p.id)}
              >
                <i className={`bi ${p.icon} me-1`} />{p.label}
              </button>
            ))}
          </div>
          <div className="d-flex flex-wrap gap-2 mb-4">
            {SORT_TABS.map((s) => (
              <button
                key={s.id}
                type="button"
                className={`btn btn-sm ${sortBy === s.id ? 'btn-dark' : 'btn-outline-dark'}`}
                onClick={() => setParam('sortBy', s.id)}
              >
                {s.label}
              </button>
            ))}
          </div>

          <AlertMessage message={error} onClose={() => setError('')} />

          {loading ? (
            <LoadingSpinner text="Loading leaderboard..." />
          ) : (
            <>
              <div className="table-responsive glass-card">
                <table className="table table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th style={{ width: 60 }}>Rank</th>
                      <th>User</th>
                      <th>Badge</th>
                      <th className="text-end">Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u._id}>
                        <td>
                          {u.rank <= 3 ? (
                            <span className="fs-5">
                              {u.rank === 1 ? '🥇' : u.rank === 2 ? '🥈' : '🥉'}
                            </span>
                          ) : (
                            <span className="text-muted">#{u.rank}</span>
                          )}
                        </td>
                        <td>
                          <div className="d-flex align-items-center gap-2">
                            <UserAvatar user={u} size={36} />
                            <div>
                              <div className="fw-semibold">{u.name}</div>
                              <div className="text-muted small text-capitalize">{u.role}</div>
                            </div>
                          </div>
                        </td>
                        <td>
                          <ReputationBadge reputation={u.reputation} showScore={false} />
                        </td>
                        <td className="text-end fw-bold text-primary">{u.score ?? u.reputation ?? 0}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination pagination={pagination} onPageChange={setPage} />
            </>
          )}
        </>
      )}
    </div>
  );
};

export default Leaderboard;
