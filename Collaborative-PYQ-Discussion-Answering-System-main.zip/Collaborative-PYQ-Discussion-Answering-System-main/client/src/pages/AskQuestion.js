import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createQuestion, getAllSubjects } from '../services/questionService';
import { getSubjectTopics } from '../services/subjectService';
import { uploadQuestionImage } from '../services/uploadService';
import { useToast } from '../context/ToastContext';
import { DIFFICULTIES, SEMESTERS, getErrorMessage } from '../utils/helpers';
import AlertMessage from '../components/AlertMessage';

const AskQuestion = ({ embedded = false }) => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [form, setForm] = useState({
    title: '',
    description: '',
    subject: '',
    semester: '',
    year: new Date().getFullYear(),
    difficulty: 'medium',
    topic: '',
    subTopic: '',
  });
  const [subjects, setSubjects] = useState([]);
  const [topics, setTopics] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState([]);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    getAllSubjects()
      .then(({ data }) => setSubjects(data.data.subjects || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!form.subject) {
      setTopics([]);
      return;
    }
    const sub = subjects.find((s) => s.name === form.subject);
    if (sub?.slug) {
      getSubjectTopics(sub.slug)
        .then(({ data }) => setTopics(data.data.topics || []))
        .catch(() => setTopics([]));
    }
  }, [form.subject, subjects]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'subject') {
      setForm((prev) => ({ ...prev, subject: value, topic: '', subTopic: '' }));
      return;
    }
    if (name === 'topic') {
      setForm((prev) => ({ ...prev, topic: value, subTopic: '' }));
      return;
    }
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (images.length >= 3) {
      showToast('Maximum 3 images allowed', 'warning');
      return;
    }
    setUploadingImage(true);
    try {
      const { data } = await uploadQuestionImage(file);
      setImages((prev) => [...prev, data.data.image]);
      showToast('Image uploaded', 'success');
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setUploadingImage(false);
      e.target.value = '';
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const { data } = await createQuestion({
        ...form,
        semester: Number(form.semester),
        year: Number(form.year),
        images,
      });
      navigate(`/questions/${data.data.question._id}`);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={embedded ? '' : 'col-lg-8 mx-auto'}>
      {!embedded && (
        <div className="page-header">
          <h2 className="fw-bold mb-1">Ask a Question</h2>
          <p className="text-muted mb-0">Share a previous year question with the community</p>
        </div>
      )}

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="card">
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Title</label>
              <input
                type="text"
                name="title"
                className="form-control"
                placeholder="e.g. Explain paging in Operating Systems"
                value={form.title}
                onChange={handleChange}
                required
                maxLength={200}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea
                name="description"
                className="form-control"
                rows={6}
                placeholder="Include full question details, marks, and any context..."
                value={form.description}
                onChange={handleChange}
                required
              />
            </div>
            <div className="row g-3 mb-3">
              <div className="col-md-4">
                <label className="form-label">Subject</label>
                <select name="subject" className="form-select" value={form.subject} onChange={handleChange} required>
                  <option value="">Select Subject</option>
                  {subjects.map((s) => (
                    <option key={s._id || s.slug} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-4">
                <label className="form-label">Topic</label>
                <select name="topic" className="form-select" value={form.topic} onChange={handleChange} disabled={!form.subject}>
                  <option value="">Select Topic</option>
                  {topics.map((t) => (
                    <option key={t.name} value={t.name}>{t.name}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-4">
                <label className="form-label">Sub-topic</label>
                <select name="subTopic" className="form-select" value={form.subTopic} onChange={handleChange} disabled={!form.topic}>
                  <option value="">Optional</option>
                  {(topics.find((t) => t.name === form.topic)?.subTopics || []).map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label">Semester</label>
                <select
                  name="semester"
                  className="form-select"
                  value={form.semester}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select</option>
                  {SEMESTERS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label">Year</label>
                <input
                  type="number"
                  name="year"
                  className="form-control"
                  value={form.year}
                  onChange={handleChange}
                  required
                  min={1990}
                  max={2100}
                />
              </div>
              <div className="col-md-2">
                <label className="form-label">Difficulty</label>
                <select
                  name="difficulty"
                  className="form-select"
                  value={form.difficulty}
                  onChange={handleChange}
                  required
                >
                  {DIFFICULTIES.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Question Images (optional, max 3)</label>
              <input
                type="file"
                className="form-control"
                accept="image/*"
                onChange={handleImageUpload}
                disabled={uploadingImage || images.length >= 3}
              />
              {uploadingImage && (
                <div className="small text-muted mt-1">
                  <span className="spinner-border spinner-border-sm me-1" /> Uploading...
                </div>
              )}
              {images.length > 0 && (
                <div className="d-flex flex-wrap gap-2 mt-2">
                  {images.map((img, i) => (
                    <div key={i} className="position-relative">
                      <img src={img.url} alt="" className="rounded" style={{ height: 80, objectFit: 'cover' }} />
                      <button
                        type="button"
                        className="btn btn-sm btn-danger position-absolute top-0 end-0"
                        onClick={() => setImages((prev) => prev.filter((_, idx) => idx !== i))}
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="d-flex gap-2">
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Posting...' : 'Post Question'}
              </button>
              <button
                type="button"
                className="btn btn-outline-secondary"
                onClick={() => navigate(-1)}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AskQuestion;
