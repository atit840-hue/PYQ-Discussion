import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { uploadResource } from '../services/resourceService';
import { useToast } from '../context/ToastContext';
import { BRANCHES, SEMESTERS, getErrorMessage } from '../utils/helpers';
import AlertMessage from '../components/AlertMessage';

const UploadResource = ({ embedded = false }) => {
  const [searchParams] = useSearchParams();
  const { showToast } = useToast();
  const [form, setForm] = useState({
    title: '',
    description: '',
    branch: searchParams.get('branch') || 'CSE',
    semester: searchParams.get('semester') || '5',
    subject: '',
  });
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a file to upload');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('title', form.title);
      fd.append('description', form.description);
      fd.append('branch', form.branch);
      fd.append('semester', form.semester);
      fd.append('subject', form.subject);
      await uploadResource(fd);
      showToast('Notes uploaded successfully!', 'success');
      setForm((prev) => ({ ...prev, title: '', description: '', subject: '' }));
      setFile(null);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={embedded ? '' : 'col-lg-8 mx-auto'}>
      {!embedded && (
        <div className="page-header">
          <h2 className="fw-bold mb-1">Upload Notes</h2>
          <p className="text-muted mb-0">Share PDF, DOCX, PPT, or images with classmates</p>
        </div>
      )}

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="glass-card p-4">
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Title</label>
            <input name="title" className="form-control" value={form.title} onChange={handleChange} required />
          </div>
          <div className="mb-3">
            <label className="form-label">Description</label>
            <textarea name="description" className="form-control" rows={3} value={form.description} onChange={handleChange} />
          </div>
          <div className="row g-3 mb-3">
            <div className="col-md-4">
              <label className="form-label">Branch</label>
              <select name="branch" className="form-select" value={form.branch} onChange={handleChange}>
                {BRANCHES.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">Semester</label>
              <select name="semester" className="form-select" value={form.semester} onChange={handleChange}>
                {SEMESTERS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">Subject</label>
              <input name="subject" className="form-control" value={form.subject} onChange={handleChange} required placeholder="e.g. DBMS" />
            </div>
          </div>
          <div className="mb-3">
            <label className="form-label">File (PDF, DOCX, PPT, Image — max 15MB)</label>
            <input type="file" className="form-control" onChange={(e) => setFile(e.target.files?.[0])} accept=".pdf,.doc,.docx,.ppt,.pptx,image/*" />
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Uploading...' : 'Upload Notes'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default UploadResource;
