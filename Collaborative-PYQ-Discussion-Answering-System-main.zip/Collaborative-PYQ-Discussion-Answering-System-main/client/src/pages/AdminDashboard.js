import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getQuestions, deleteQuestion } from '../services/questionService';
import { getReports, updateReportStatus } from '../services/reportService';
import { getAnalytics } from '../services/analyticsService';
import { formatDateTime, getErrorMessage } from '../utils/helpers';
import { SubjectChart, UserActivityChart, StatsBarChart } from '../components/AnalyticsCharts';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';
import Pagination from '../components/Pagination';

const AdminDashboard = () => {
  const { isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState(isAdmin ? 'questions' : 'analytics');
  const [questions, setQuestions] = useState([]);
  const [reports, setReports] = useState([]);
  const [qPagination, setQPagination] = useState(null);
  const [rPagination, setRPagination] = useState(null);
  const [qPage, setQPage] = useState(1);
  const [rPage, setRPage] = useState(1);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchQuestions = useCallback(async () => {
    try {
      const { data } = await getQuestions({ page: qPage, limit: 10 });
      setQuestions(data.data);
      setQPagination(data.pagination);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }, [qPage]);

  const fetchReports = useCallback(async () => {
    try {
      const { data } = await getReports({ page: rPage, limit: 10, status: 'pending' });
      setReports(data.data);
      setRPagination(data.pagination);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }, [rPage]);

  const fetchAnalytics = useCallback(async () => {
    try {
      const { data } = await getAnalytics();
      setAnalytics(data.data);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }, []);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      setError('');
      const tasks = [fetchReports(), fetchAnalytics()];
      if (isAdmin) tasks.push(fetchQuestions());
      await Promise.all(tasks);
      setLoading(false);
    };
    load();
  }, [fetchQuestions, fetchReports, fetchAnalytics, isAdmin]);

  useEffect(() => {
    if (!isAdmin && activeTab === 'questions') setActiveTab('reports');
  }, [isAdmin, activeTab]);

  const handleDeleteQuestion = async (id) => {
    if (!window.confirm('Delete this question permanently?')) return;
    try {
      await deleteQuestion(id);
      setQuestions((prev) => prev.filter((q) => q._id !== id));
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleReviewReport = async (id, status) => {
    try {
      await updateReportStatus(id, { status, reviewNote: `Marked as ${status}` });
      setReports((prev) => prev.filter((r) => r._id !== id));
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  if (loading) return <LoadingSpinner text="Loading admin dashboard..." />;

  return (
    <div>
      <div className="page-header">
        <h2 className="fw-bold mb-1">{isAdmin ? 'Admin Dashboard' : 'Moderation Dashboard'}</h2>
        <p className="text-muted mb-0">
          {isAdmin ? 'Manage content and review reports' : 'Review reported content'}
        </p>
      </div>

      <AlertMessage message={error} onClose={() => setError('')} />

      <ul className="nav nav-tabs mb-4">
        {isAdmin && (
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'questions' ? 'active' : ''}`}
              onClick={() => setActiveTab('questions')}
            >
              Questions ({qPagination?.total || 0})
            </button>
          </li>
        )}
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'analytics' ? 'active' : ''}`}
            onClick={() => setActiveTab('analytics')}
          >
            Analytics
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'reports' ? 'active' : ''}`}
            onClick={() => setActiveTab('reports')}
          >
            Pending Reports ({rPagination?.total || 0})
          </button>
        </li>
      </ul>

      {activeTab === 'analytics' && analytics && (
        <>
          <div className="row g-3 mb-4">
            <div className="col-md-4">
              <div className="card stat-card text-center">
                <div className="card-body">
                  <h3>{analytics.totals.users}</h3>
                  <p className="text-muted mb-0">Total Users</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card stat-card text-center">
                <div className="card-body">
                  <h3>{analytics.totals.questions}</h3>
                  <p className="text-muted mb-0">Total Questions</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card stat-card text-center">
                <div className="card-body">
                  <h3>{analytics.totals.answers}</h3>
                  <p className="text-muted mb-0">Total Answers</p>
                </div>
              </div>
            </div>
          </div>
          <div className="row g-4 mb-4">
            <div className="col-lg-6">
              <div className="card h-100">
                <div className="card-header fw-semibold">Subject Distribution</div>
                <div className="card-body">
                  <SubjectChart data={analytics.subjectDistribution} />
                </div>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="card h-100">
                <div className="card-header fw-semibold">Difficulty Breakdown</div>
                <div className="card-body">
                  <StatsBarChart
                    title="Questions by Difficulty"
                    labels={analytics.difficultyDistribution.map((d) => d.difficulty)}
                    values={analytics.difficultyDistribution.map((d) => d.count)}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-header fw-semibold">User Activity (Last 30 Days)</div>
            <div className="card-body">
              <UserActivityChart userActivity={analytics.userActivity} />
            </div>
          </div>
        </>
      )}

      {activeTab === 'questions' && isAdmin && (
        <>
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Subject</th>
                  <th>Author</th>
                  <th>Answers</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {questions.map((q) => (
                  <tr key={q._id}>
                    <td>
                      <Link to={`/questions/${q._id}`} className="text-decoration-none">
                        {q.title}
                      </Link>
                    </td>
                    <td>{q.subject}</td>
                    <td>{q.author?.name}</td>
                    <td>{q.answerCount}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleDeleteQuestion(q._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination pagination={qPagination} onPageChange={setQPage} />
        </>
      )}

      {activeTab === 'reports' && (
        <>
          {reports.length === 0 ? (
            <p className="text-muted">No pending reports.</p>
          ) : (
            reports.map((r) => (
              <div key={r._id} className="card mb-3">
                <div className="card-body">
                  <div className="d-flex justify-content-between flex-wrap gap-2">
                    <div>
                      <span className="badge bg-warning text-dark me-2">{r.targetType}</span>
                      <strong>{r.reason}</strong>
                      {r.description && <p className="mb-1 mt-1 small">{r.description}</p>}
                      <p className="text-muted small mb-0">
                        Reported by {r.reportedBy?.name} · {formatDateTime(r.createdAt)}
                      </p>
                    </div>
                    <div className="d-flex gap-2">
                      <button
                        className="btn btn-sm btn-success"
                        onClick={() => handleReviewReport(r._id, 'reviewed')}
                      >
                        Reviewed
                      </button>
                      <button
                        className="btn btn-sm btn-secondary"
                        onClick={() => handleReviewReport(r._id, 'dismissed')}
                      >
                        Dismiss
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
          <Pagination pagination={rPagination} onPageChange={setRPage} />
        </>
      )}
    </div>
  );
};

export default AdminDashboard;
