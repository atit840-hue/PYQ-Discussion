import React, { useCallback, useEffect, useState } from 'react';
import { getBookmarks, removeBookmark } from '../services/bookmarkService';
import { getErrorMessage } from '../utils/helpers';
import QuestionCard from '../components/QuestionCard';
import Pagination from '../components/Pagination';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

const Bookmarks = () => {
  const [bookmarks, setBookmarks] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchBookmarks = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const { data } = await getBookmarks({ page, limit: 10 });
      setBookmarks(data.data);
      setPagination(data.pagination);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => {
    fetchBookmarks();
  }, [fetchBookmarks]);

  const handleRemove = async (questionId) => {
    try {
      await removeBookmark(questionId);
      setBookmarks((prev) => prev.filter((b) => b.question?._id !== questionId));
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2 className="fw-bold mb-1">Bookmarks</h2>
        <p className="text-muted mb-0">Your saved PYQ questions</p>
      </div>

      <AlertMessage message={error} onClose={() => setError('')} />

      {loading ? (
        <LoadingSpinner text="Loading bookmarks..." />
      ) : bookmarks.length === 0 ? (
        <div className="text-center py-5 text-muted">
          <p className="fs-5">No bookmarks yet.</p>
          <p>Bookmark questions from the detail page to save them here.</p>
        </div>
      ) : (
        <>
          {bookmarks.map((b) => (
            <div key={b._id} className="position-relative">
              <QuestionCard question={b.question} />
              <button
                className="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-3"
                onClick={() => handleRemove(b.question._id)}
              >
                Remove
              </button>
            </div>
          ))}
          <Pagination pagination={pagination} onPageChange={setPage} />
        </>
      )}
    </div>
  );
};

export default Bookmarks;
