import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import TabNav from '../components/TabNav';
import Home from './Home';
import Subjects from './Subjects';
import Pyqs from './Pyqs';
import AskQuestion from './AskQuestion';
import AddPyq from './AddPyq';
import UploadResource from './UploadResource';
import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';

const TABS = [
  { id: 'discussions', label: 'All Discussions', icon: 'bi-chat-dots' },
  { id: 'subjects', label: 'Subjects', icon: 'bi-book' },
  { id: 'pyqs', label: 'PYQ Repository', icon: 'bi-journal-bookmark' },
  { id: 'ask', label: 'Ask Question', icon: 'bi-plus-circle' },
  { id: 'upload', label: 'Upload PYQ', icon: 'bi-cloud-upload' },
  { id: 'notes', label: 'Upload Notes', icon: 'bi-file-earmark-arrow-up', auth: true },
];

const DiscussionsHub = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const tab = searchParams.get('tab') || 'discussions';

  const visibleTabs = TABS.filter((t) => !t.auth || user);

  if (tab === 'ask' && !user) return <Navigate to="/login" replace />;
  if ((tab === 'upload' || tab === 'notes') && !user) return <Navigate to="/login" replace />;

  return (
    <div>
      <div className="page-header mb-3">
        <h1 className="page-title mb-1">Discussions</h1>
        <p className="page-subtitle mb-0">
          Your hub for PYQs, subjects, notes, and community Q&amp;A.
        </p>
      </div>

      <TabNav tabs={visibleTabs} paramKey="tab" className="mb-4" />

      {tab === 'discussions' && <Home embedded />}
      {tab === 'subjects' && <Subjects embedded />}
      {tab === 'pyqs' && <Pyqs embedded />}
      {tab === 'ask' && <AskQuestion embedded />}
      {tab === 'upload' && <AddPyq embedded />}
      {tab === 'notes' && <UploadResource embedded />}
    </div>
  );
};

export default DiscussionsHub;
