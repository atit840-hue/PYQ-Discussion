import React, { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  getQuestion,
  getAnswersByQuestion,
  createAnswer,
  deleteQuestion,
  upvoteQuestion,
  downvoteQuestion,
} from '../services/questionService';
import { toggleBookmark, getBookmarks } from '../services/bookmarkService';
import { createReport } from '../services/reportService';
import { useToast } from '../context/ToastContext';
import { formatDate, DIFFICULTY_VARIANT, getErrorMessage } from '../utils/helpers';
import AnswerCard from '../components/AnswerCard';
import AiPanel from '../components/AiPanel';
import UserAvatar from '../components/UserAvatar';
import VoteBox from '../components/VoteBox';
import ReputationBadge from '../components/ReputationBadge';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

const QuestionDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const { showToast } = useToast();

  const [question, setQuestion] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [answerText, setAnswerText] = useState('');
  const [bookmarked, setBookmarked] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [qVoteScore, setQVoteScore] = useState(0);
  const [qUserVote, setQUserVote] = useState(null);
  const [qVoting, setQVoting] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [qRes, aRes] = await Promise.all([
        getQuestion(id),
        getAnswersByQuestion(id, { limit: 50 }),
      ]);
      setQuestion(qRes.data.data.question);
      setAnswers(aRes.data.data);
      const q = qRes.data.data.question;
      setQVoteScore(q.voteScore ?? (q.upvotes?.length || 0) - (q.downvotes?.length || 0));
      if (user) {
        const uid = user._id;
        if (q.upvotes?.some((id) => (id._id || id) === uid)) setQUserVote('upvote');
        else if (q.downvotes?.some((id) => (id._id || id) === uid)) setQUserVote('downvote');
        else setQUserVote(null);
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id, user?._id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    if (!user) return;
    getBookmarks({ limit: 200 })
      .then(({ data }) => {
        const found = data.data.some((b) => b.question?._id === id);
        setBookmarked(found);
      })
      .catch(() => {});
  }, [user, id]);

  const handlePostAnswer = async (e) => {
    e.preventDefault();
    if (!answerText.trim()) return;
    setSubmitting(true);
    setError('');
    try {
      const { data } = await createAnswer(id, { answerText });
      setAnswers((prev) => [...prev, data.data.answer]);
      setAnswerText('');
      setQuestion((prev) => ({ ...prev, answerCount: (prev.answerCount || 0) + 1 }));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleBookmark = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    try {
      const { data } = await toggleBookmark(id);
      setBookmarked(data.data.bookmarked);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleDeleteQuestion = async () => {
    if (!window.confirm('Delete this question and all related content?')) return;
    try {
      await deleteQuestion(id);
      navigate('/');
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleReport = async (e) => {
    e.preventDefault();
    try {
      await createReport({ targetType: 'question', targetId: id, reason: reportReason });
      setShowReport(false);
      setReportReason('');
      showToast('Report submitted successfully', 'success');
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleQuestionVote = async (type) => {
    if (!user) { navigate('/login'); return; }
    setQVoting(true);
    try {
      const fn = type === 'upvote' ? upvoteQuestion : downvoteQuestion;
      const { data } = await fn(id);
      setQVoteScore(data.data.voteScore);
      setQUserVote(data.data.userVote);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setQVoting(false);
    }
  };

  const handleAnswerDelete = (answerId) => {
    setAnswers((prev) => prev.filter((a) => a._id !== answerId));
    setQuestion((prev) => ({
      ...prev,
      answerCount: Math.max(0, (prev.answerCount || 1) - 1),
    }));
  };

  if (loading) return <LoadingSpinner text="Loading question..." />;
  if (!question) {
    return (
      <div className="text-center py-5">
        <p className="text-muted">Question not found.</p>
        <Link to="/" className="btn btn-primary">
          Back to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="col-lg-10 mx-auto">
      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="card mb-4">
        <div className="card-body">
          <div className="d-flex gap-3">
            <VoteBox
              voteScore={qVoteScore}
              userVote={qUserVote}
              onUpvote={() => handleQuestionVote('upvote')}
              onDownvote={() => handleQuestionVote('downvote')}
              disabled={!user || qVoting}
            />
            <div className="flex-grow-1">
          <div className="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
            <div>
              <h2 className="fw-bold mb-2">{question.title}</h2>
              <div className="d-flex flex-wrap gap-2">
                <Link to={`/subjects/${question.subjectRef?.slug || ''}`} className="badge bg-secondary text-decoration-none">
                  {question.subject}
                </Link>
                {question.topic && <span className="badge bg-primary">{question.topic}</span>}
                {question.subTopic && <span className="badge bg-primary-subtle text-primary-emphasis">{question.subTopic}</span>}
                <span className="badge bg-info">Sem {question.semester}</span>
                <span className="badge bg-dark">{question.year}</span>
                <span className={`badge bg-${DIFFICULTY_VARIANT[question.difficulty] || 'secondary'}`}>
                  {question.difficulty}
                </span>
              </div>
            </div>
            <div className="d-flex gap-2">
              {user && (
                <button
                  className={`btn btn-sm ${bookmarked ? 'btn-warning' : 'btn-outline-warning'}`}
                  onClick={handleBookmark}
                >
                  {bookmarked ? '★ Bookmarked' : '☆ Bookmark'}
                </button>
              )}
              {user && (
                <button
                  className="btn btn-sm btn-outline-danger"
                  onClick={() => setShowReport((p) => !p)}
                >
                  Report
                </button>
              )}
              {isAdmin && (
                <button className="btn btn-sm btn-danger" onClick={handleDeleteQuestion}>
                  Delete
                </button>
              )}
            </div>
          </div>

          {showReport && (
            <form className="mb-3" onSubmit={handleReport}>
              <input
                className="form-control form-control-sm mb-1"
                placeholder="Reason for report"
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                required
              />
              <button type="submit" className="btn btn-sm btn-warning">
                Submit Report
              </button>
            </form>
          )}

          <div className="mb-3" style={{ whiteSpace: 'pre-wrap' }}>
            {question.description}
          </div>

          {question.images?.length > 0 && (
            <div className="d-flex flex-wrap gap-2 mb-3">
              {question.images.map((img, i) => (
                <a key={i} href={img.url} target="_blank" rel="noreferrer">
                  <img
                    src={img.url}
                    alt={`Question attachment ${i + 1}`}
                    className="rounded border"
                    style={{ maxHeight: 200, objectFit: 'cover' }}
                  />
                </a>
              ))}
            </div>
          )}

          <div className="text-muted small d-flex align-items-center gap-2 flex-wrap">
            <UserAvatar user={question.author} size={24} />
            <span>
              Asked by <strong>{question.author?.name}</strong>
              {question.author?.reputation !== undefined && (
                <span className="ms-1"><ReputationBadge reputation={question.author.reputation} showScore={false} /></span>
              )}
            </span>
            <span>· {formatDate(question.createdAt)} · {question.views} views · {question.answerCount} answers</span>
          </div>
            </div>
          </div>
        </div>
      </div>

      {user && <AiPanel question={question} answers={answers} />}

      <h4 className="mb-3">{answers.length} Answer{answers.length !== 1 ? 's' : ''}</h4>

      {answers.map((answer) => (
        <AnswerCard
          key={answer._id}
          answer={answer}
          question={question}
          acceptedAnswerId={question.acceptedAnswer?._id || question.acceptedAnswer}
          onDelete={handleAnswerDelete}
          onUpdate={fetchData}
          onAccept={fetchData}
        />
      ))}

      {user ? (
        <div className="card mt-4">
          <div className="card-body">
            <h5 className="mb-3">Your Answer</h5>
            <form onSubmit={handlePostAnswer}>
              <textarea
                className="form-control mb-3"
                rows={5}
                placeholder="Write your answer here..."
                value={answerText}
                onChange={(e) => setAnswerText(e.target.value)}
                required
              />
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting ? 'Posting...' : 'Post Answer'}
              </button>
            </form>
          </div>
        </div>
      ) : (
        <div className="alert alert-info">
          <Link to="/login">Login</Link> to post an answer.
        </div>
      )}
    </div>
  );
};

export default QuestionDetails;
