import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getSubjects } from '../services/subjectService';
import { getErrorMessage } from '../utils/helpers';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';

const SUBJECT_ICONS = {
  dbms: 'bi-database',
  'operating-systems': 'bi-cpu',
  'computer-networks': 'bi-diagram-3',
  toc: 'bi-infinity',
  'compiler-design': 'bi-code-slash',
  dsa: 'bi-bricks',
  algorithms: 'bi-graph-up',
  'digital-logic': 'bi-lightning',
  coa: 'bi-motherboard',
};

const Subjects = ({ embedded = false }) => {
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getSubjects()
      .then(({ data }) => setSubjects(data.data.subjects))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner text="Loading subjects..." />;

  return (
    <div>
      {!embedded && (
        <div className="page-header">
          <h2 className="fw-bold mb-1">Subject Knowledge Base</h2>
          <p className="text-muted mb-0">
            Browse B.Tech subjects — notes, topics, formulas, and PYQs
          </p>
        </div>
      )}

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="row g-4">
        {subjects.map((s) => (
          <div key={s._id} className="col-md-6 col-lg-4">
            <Link to={`/subjects/${s.slug}`} className="text-decoration-none">
              <div className="card subject-card h-100">
                <div className="card-body">
                  <div className="d-flex align-items-start gap-3">
                    <div className="subject-icon rounded-circle bg-primary-subtle text-primary d-flex align-items-center justify-content-center">
                      <i className={`bi ${SUBJECT_ICONS[s.slug] || 'bi-book'} fs-4`} />
                    </div>
                    <div className="flex-grow-1">
                      <h5 className="card-title text-primary mb-1">{s.name}</h5>
                      <p className="text-muted small mb-2">{s.fullName}</p>
                      <div className="d-flex flex-wrap gap-1 mb-2">
                        <span className="badge bg-secondary">{s.pyqCount || 0} PYQs</span>
                        <span className="badge bg-primary-subtle text-primary-emphasis">{s.questionCount || 0} discussions</span>
                        {s.semester && <span className="badge bg-info">Sem {s.semester}</span>}
                        <span className="badge bg-dark">{s.topics?.length || 0} topics</span>
                      </div>
                      <p className="small text-muted mb-0">{s.description?.slice(0, 80)}...</p>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Subjects;
