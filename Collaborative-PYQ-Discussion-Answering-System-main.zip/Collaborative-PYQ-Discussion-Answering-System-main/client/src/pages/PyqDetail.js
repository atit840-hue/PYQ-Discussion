import React, { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getPyq, deletePyq } from '../services/pyqService';
import { formatDate, DIFFICULTY_VARIANT, getErrorMessage } from '../utils/helpers';
import UserAvatar from '../components/UserAvatar';
import ReputationBadge from '../components/ReputationBadge';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

const PyqDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [pyq, setPyq] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchPyq = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const { data } = await getPyq(id);
      setPyq(data.data.pyq);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchPyq();
  }, [fetchPyq]);

  const handleDelete = async () => {
    if (!window.confirm('Delete this PYQ permanently?')) return;
    try {
      await deletePyq(id);
      navigate('/pyqs');
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  if (loading) return <LoadingSpinner text="Loading PYQ..." />;
  if (!pyq) {
    return (
      <div className="text-center py-5">
        <p className="text-muted">PYQ not found.</p>
        <Link to="/pyqs" className="btn btn-primary">Back to Repository</Link>
      </div>
    );
  }

  const isAuthor = user && (pyq.author?._id === user._id || pyq.author === user._id);
  const images = pyq.images?.length
    ? pyq.images
    : pyq.questionImage?.url
      ? [pyq.questionImage]
      : [];

  return (
    <div className="col-lg-9 mx-auto">
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb">
          <li className="breadcrumb-item"><Link to="/pyqs">PYQ Repository</Link></li>
          <li className="breadcrumb-item active">{pyq.title}</li>
        </ol>
      </nav>

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="card mb-4">
        <div className="card-body">
          <div className="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
            <h2 className="fw-bold mb-0">{pyq.title}</h2>
            <div className="d-flex gap-2">
              {isAuthor && (
                <Link to={`/pyqs/add?edit=${id}`} className="btn btn-outline-secondary btn-sm">
                  Edit
                </Link>
              )}
              {isAdmin && (
                <button type="button" className="btn btn-outline-danger btn-sm" onClick={handleDelete}>
                  Delete
                </button>
              )}
            </div>
          </div>

          <div className="d-flex flex-wrap gap-2 mb-3">
            <span className="badge bg-dark">{pyq.exam}</span>
            <span className="badge bg-secondary">{pyq.subject}</span>
            {pyq.topic && <span className="badge bg-primary">{pyq.topic}</span>}
            {pyq.subTopic && (
              <span className="badge bg-primary-subtle text-primary-emphasis">{pyq.subTopic}</span>
            )}
            <span className="badge bg-info">{pyq.year}</span>
            <span className="badge bg-primary">{pyq.marks} marks</span>
            <span className={`badge bg-${DIFFICULTY_VARIANT[pyq.difficulty] || 'secondary'}`}>
              {pyq.difficulty}
            </span>
          </div>

          <div className="text-muted small d-flex align-items-center gap-2 mb-4">
            <UserAvatar user={pyq.author} size={28} />
            <span>
              Added by <strong>{pyq.author?.name}</strong>
              {pyq.author?.reputation !== undefined && (
                <span className="ms-1">
                  <ReputationBadge reputation={pyq.author.reputation} showScore={false} />
                </span>
              )}
              · {formatDate(pyq.createdAt)} · {pyq.views} views
            </span>
          </div>

          <h5 className="fw-semibold">Question</h5>
          <div className="mb-4" style={{ whiteSpace: 'pre-wrap' }}>{pyq.questionText}</div>

          {images.length > 0 && (
            <div className="d-flex flex-wrap gap-2 mb-4">
              {images.map((img, i) => (
                <a key={i} href={img.url} target="_blank" rel="noopener noreferrer">
                  <img
                    src={img.url}
                    alt="Question"
                    className="rounded border"
                    style={{ maxHeight: 240, objectFit: 'contain' }}
                  />
                </a>
              ))}
            </div>
          )}

          {pyq.officialAnswer && (
            <div className="mb-4">
              <h5 className="fw-semibold">
                <i className="bi bi-check-circle text-success me-2" />Official Answer
              </h5>
              <div className="card bg-success-subtle border-success">
                <div className="card-body" style={{ whiteSpace: 'pre-wrap' }}>
                  {pyq.officialAnswer}
                </div>
              </div>
            </div>
          )}

          {pyq.solution && (
            <div className="mb-4">
              <h5 className="fw-semibold">
                <i className="bi bi-lightbulb text-warning me-2" />Solution
              </h5>
              <div className="card">
                <div className="card-body" style={{ whiteSpace: 'pre-wrap' }}>
                  {pyq.solution}
                </div>
              </div>
            </div>
          )}

          <div className="d-flex flex-wrap gap-2">
            <Link
              to={`/ask?subject=${encodeURIComponent(pyq.subject)}&topic=${encodeURIComponent(pyq.topic || '')}`}
              className="btn btn-outline-primary btn-sm"
            >
              <i className="bi bi-chat-dots me-1" />Discuss this PYQ
            </Link>
            {pyq.subjectRef?.slug && (
              <Link to={`/subjects/${pyq.subjectRef.slug}`} className="btn btn-outline-secondary btn-sm">
                View Subject
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PyqDetail;
