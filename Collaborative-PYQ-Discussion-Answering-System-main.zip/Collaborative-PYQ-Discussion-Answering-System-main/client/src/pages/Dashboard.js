import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getQuestions } from '../services/questionService';
import { getAnalyticsSummary, getMyAnalytics } from '../services/analyticsService';
import { getErrorMessage } from '../utils/helpers';
import { SubjectChart, ActivityChart } from '../components/AnalyticsCharts';
import AlertMessage from '../components/AlertMessage';
import LoadingSpinner from '../components/LoadingSpinner';

const Dashboard = () => {
  const { user } = useAuth();
  const [summary, setSummary] = useState(null);
  const [myStats, setMyStats] = useState(null);
  const [recentQuestions, setRecentQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [summaryRes, myRes, questionsRes] = await Promise.all([
          getAnalyticsSummary(),
          getMyAnalytics(),
          getQuestions({ limit: 5, sort: '' }),
        ]);

        setSummary(summaryRes.data.data);
        setMyStats(myRes.data.data);
        setRecentQuestions(questionsRes.data.data);
      } catch (err) {
        setError(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [user._id]);

  if (loading) return <LoadingSpinner text="Loading analytics dashboard..." />;

  return (
    <div>
      <div className="page-header">
        <h2 className="fw-bold mb-1">Welcome, {user.name}!</h2>
        <p className="text-muted mb-0">Analytics & activity overview</p>
      </div>

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="row g-3 mb-4">
        <div className="col-md-3 col-6">
          <div className="card stat-card h-100">
            <div className="card-body text-center">
              <i className="bi bi-people fs-3 text-primary" />
              <h3 className="mt-2 mb-0">{summary?.totals?.users || 0}</h3>
              <p className="text-muted small mb-0">Total Users</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 col-6">
          <div className="card stat-card h-100">
            <div className="card-body text-center">
              <i className="bi bi-question-circle fs-3 text-success" />
              <h3 className="mt-2 mb-0">{summary?.totals?.questions || 0}</h3>
              <p className="text-muted small mb-0">Total Questions</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 col-6">
          <div className="card stat-card h-100">
            <div className="card-body text-center">
              <i className="bi bi-pencil fs-3 text-info" />
              <h3 className="mt-2 mb-0">{myStats?.myQuestions || 0}</h3>
              <p className="text-muted small mb-0">My Questions</p>
            </div>
          </div>
        </div>
        <div className="col-md-3 col-6">
          <div className="card stat-card h-100">
            <div className="card-body text-center">
              <i className="bi bi-bell fs-3 text-warning" />
              <h3 className="mt-2 mb-0">{myStats?.unreadNotifications || 0}</h3>
              <p className="text-muted small mb-0">Unread Alerts</p>
            </div>
          </div>
        </div>
      </div>

      <div className="row g-4 mb-4">
        <div className="col-lg-6">
          <div className="card h-100">
            <div className="card-header fw-semibold">Subject Distribution</div>
            <div className="card-body">
              {summary?.subjectDistribution?.length ? (
                <SubjectChart data={summary.subjectDistribution} />
              ) : (
                <p className="text-muted mb-0">No data yet.</p>
              )}
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="card h-100">
            <div className="card-header fw-semibold">My Activity</div>
            <div className="card-body">
              {myStats?.activity?.length ? (
                <ActivityChart data={myStats.activity} label="My Questions Posted" />
              ) : (
                <p className="text-muted mb-0">Post questions to see your activity chart.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <h5 className="mb-0">Recent Questions</h5>
        <Link to="/ask" className="btn btn-primary btn-sm">
          <i className="bi bi-plus-lg me-1" /> Ask Question
        </Link>
      </div>

      {recentQuestions.length === 0 ? (
        <p className="text-muted">No questions yet.</p>
      ) : (
        <ul className="list-group">
          {recentQuestions.map((q) => (
            <li key={q._id} className="list-group-item d-flex justify-content-between align-items-center">
              <Link to={`/questions/${q._id}`} className="text-decoration-none">{q.title}</Link>
              <span className="badge bg-secondary">{q.answerCount} answers</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Dashboard;
