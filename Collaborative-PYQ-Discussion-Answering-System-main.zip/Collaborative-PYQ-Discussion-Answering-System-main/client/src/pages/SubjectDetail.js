import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getSubject } from '../services/subjectService';
import { getErrorMessage } from '../utils/helpers';
import PyqCard from '../components/PyqCard';
import LoadingSpinner from '../components/LoadingSpinner';
import AlertMessage from '../components/AlertMessage';

const SubjectDetail = () => {
  const { slug } = useParams();
  const [subject, setSubject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    setLoading(true);
    getSubject(slug)
      .then(({ data }) => setSubject(data.data.subject))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) return <LoadingSpinner text="Loading subject..." />;
  if (!subject) {
    return (
      <div className="text-center py-5">
        <p className="text-muted">Subject not found.</p>
        <Link to="/?tab=subjects" className="btn btn-primary">Back to Subjects</Link>
      </div>
    );
  }

  return (
    <div>
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb">
          <li className="breadcrumb-item"><Link to="/?tab=subjects">Subjects</Link></li>
          <li className="breadcrumb-item active">{subject.name}</li>
        </ol>
      </nav>

      <div className="page-header">
        <h2 className="fw-bold mb-1">{subject.fullName}</h2>
        <p className="text-muted mb-0">{subject.description}</p>
      </div>

      <AlertMessage message={error} onClose={() => setError('')} />

      <div className="row g-3 mb-4">
        <div className="col-md-4">
          <div className="card stat-card text-center">
            <div className="card-body">
              <h3>{subject.pyqCount ?? 0}</h3>
              <p className="text-muted mb-0">Repository PYQs</p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card stat-card text-center">
            <div className="card-body">
              <h3>{subject.questionCount}</h3>
              <p className="text-muted mb-0">Discussions</p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card stat-card text-center">
            <div className="card-body">
              <h3>{subject.topics?.length || 0}</h3>
              <p className="text-muted mb-0">Topics</p>
            </div>
          </div>
        </div>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-12">
          <div className="card">
            <div className="card-body d-flex flex-wrap gap-2 justify-content-center">
              <Link
                to={`/?tab=pyqs&subject=${encodeURIComponent(subject.name)}`}
                className="btn btn-primary btn-sm"
              >
                Browse PYQ Repository
              </Link>
              <Link
                to={`/?tab=discussions&subject=${encodeURIComponent(subject.name)}`}
                className="btn btn-outline-primary btn-sm"
              >
                Browse Discussions
              </Link>
              <Link to="/?tab=upload" className="btn btn-outline-secondary btn-sm">
                Add PYQ
              </Link>
              <Link to="/?tab=ask" className="btn btn-outline-secondary btn-sm">
                Ask Question
              </Link>
            </div>
          </div>
        </div>
      </div>

      <ul className="nav tab-nav-pills mb-4 flex-wrap">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'topics', label: 'Important Topics' },
          { id: 'pyqs', label: 'PYQs' },
          { id: 'notes', label: 'Notes' },
          { id: 'discussions', label: 'Discussions' },
          { id: 'ai', label: 'AI Assistant' },
        ].map((tab) => (
          <li className="nav-item" key={tab.id}>
            <button
              type="button"
              className={`nav-link ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          </li>
        ))}
      </ul>

      {activeTab === 'overview' && (
        <div className="row g-4">
          <div className="col-lg-6">
            <div className="card h-100">
              <div className="card-header fw-semibold">Important Topics</div>
              <ul className="list-group list-group-flush">
                {subject.importantTopics?.map((t) => (
                  <li key={t} className="list-group-item">{t}</li>
                ))}
              </ul>
            </div>
          </div>
          <div className="col-lg-6">
            <div className="card h-100">
              <div className="card-header fw-semibold">Topic Stats</div>
              <ul className="list-group list-group-flush">
                {subject.topicStats?.map((t) => (
                  <li key={t.topic} className="list-group-item d-flex justify-content-between">
                    <Link
                      to={`/?tab=discussions&subject=${encodeURIComponent(subject.name)}&topic=${encodeURIComponent(t.topic)}`}
                      className="text-decoration-none"
                    >
                      {t.topic}
                    </Link>
                    <span className="badge bg-secondary">{t.count}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'topics' && (
        <div className="accordion" id="topicsAccordion">
          {subject.topics?.map((topic, i) => (
            <div className="accordion-item" key={topic.name}>
              <h2 className="accordion-header">
                <button
                  className={`accordion-button ${i > 0 ? 'collapsed' : ''}`}
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target={`#topic-${i}`}
                >
                  {topic.name}
                </button>
              </h2>
              <div id={`topic-${i}`} className={`accordion-collapse collapse ${i === 0 ? 'show' : ''}`}>
                <div className="accordion-body">
                  <div className="d-flex flex-wrap gap-2">
                    {topic.subTopics.map((st) => (
                      <Link
                        key={st}
                        to={`/?tab=discussions&subject=${encodeURIComponent(subject.name)}&topic=${encodeURIComponent(topic.name)}&subTopic=${encodeURIComponent(st)}`}
                        className="badge bg-primary-subtle text-primary-emphasis text-decoration-none"
                      >
                        {st}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'notes' && (
        <div className="row g-4">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header fw-semibold"><i className="bi bi-journal-text me-2" />Notes</div>
              <ul className="list-group list-group-flush">
                {subject.notes?.map((n) => (
                  <li key={n} className="list-group-item small">{n}</li>
                ))}
              </ul>
            </div>
          </div>
          <div className="col-md-6">
            <div className="card">
              <div className="card-header fw-semibold"><i className="bi bi-calculator me-2" />Formulas</div>
              <ul className="list-group list-group-flush">
                {subject.formulas?.length ? subject.formulas.map((f) => (
                  <li key={f} className="list-group-item small font-monospace">{f}</li>
                )) : (
                  <li className="list-group-item text-muted small">No formulas added yet.</li>
                )}
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'pyqs' && (
        <>
          {subject.recentPyqs?.length === 0 ? (
            <p className="text-muted">No PYQs in the repository for this subject yet.</p>
          ) : (
            subject.recentPyqs.map((pyq) => (
              <PyqCard key={pyq._id} pyq={{ ...pyq, subject: subject.name, author: pyq.author }} />
            ))
          )}
          {subject.pyqCount > 0 && (
            <div className="text-center mt-3">
              <Link
                to={`/?tab=pyqs&subject=${encodeURIComponent(subject.name)}`}
                className="btn btn-outline-primary btn-sm"
              >
                View all {subject.pyqCount} PYQs
              </Link>
            </div>
          )}
        </>
      )}

      {activeTab === 'discussions' && (
        <div className="glass-card p-4 text-center">
          <i className="bi bi-chat-dots display-4 text-primary mb-3 d-block" />
          <p className="mb-3">Browse community discussions for {subject.name}</p>
          <Link
            to={`/?tab=discussions&subject=${encodeURIComponent(subject.name)}`}
            className="btn btn-primary"
          >
            View Discussions
          </Link>
        </div>
      )}

      {activeTab === 'ai' && (
        <div className="glass-card p-4">
          <h5 className="fw-semibold mb-2"><i className="bi bi-stars me-2 text-warning" />AI Study Assistant</h5>
          <p className="text-muted mb-3">
            Open any discussion question to use Gemini-powered explain, summarize, and similar PYQ features.
          </p>
          <Link to={`/?tab=discussions&subject=${encodeURIComponent(subject.name)}`} className="btn btn-outline-primary btn-sm">
            Find {subject.name} discussions
          </Link>
        </div>
      )}
    </div>
  );
};

export default SubjectDetail;
