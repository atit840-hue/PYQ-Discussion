export const formatDate = (date) => {
  if (!date) return '';
  return new Date(date).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

export const formatDateTime = (date) => {
  if (!date) return '';
  return new Date(date).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const getErrorMessage = (error) =>
  error.response?.data?.message || error.message || 'Something went wrong';

export const DIFFICULTY_VARIANT = {
  easy: 'success',
  medium: 'warning',
  hard: 'danger',
};

export const ROLE_VARIANT = {
  student: 'secondary',
  moderator: 'info',
  admin: 'danger',
};

export const getBadgeInfo = (reputation) => {
  const score = reputation || 0;
  if (score >= 1000) return { name: 'Expert', variant: 'danger', icon: 'bi-gem' };
  if (score >= 500) return { name: 'Gold', variant: 'warning', icon: 'bi-award-fill' };
  if (score >= 200) return { name: 'Silver', variant: 'secondary', icon: 'bi-award' };
  if (score >= 50) return { name: 'Bronze', variant: 'info', icon: 'bi-patch-check' };
  return { name: 'Newcomer', variant: 'light', icon: 'bi-person' };
};

export const SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8];
export const DIFFICULTIES = ['easy', 'medium', 'hard'];
export const EXAMS = ['GATE', 'B.Tech End Sem', 'B.Tech Mid Sem', 'Placement', 'Other'];
export const BRANCHES = ['CSE', 'IT', 'ECE', 'ME'];
