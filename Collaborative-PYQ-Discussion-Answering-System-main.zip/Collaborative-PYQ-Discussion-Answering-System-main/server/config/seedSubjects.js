const Subject = require('../models/Subject');
const { SUBJECTS_SEED } = require('../data/subjectsSeed');

const seedSubjects = async () => {
  const count = await Subject.countDocuments();
  if (count > 0) return;

  await Subject.insertMany(SUBJECTS_SEED);
  console.log(`Seeded ${SUBJECTS_SEED.length} subjects`);
};

module.exports = seedSubjects;
