const { BADGE_THRESHOLDS, getBadge } = require('../utils/badgeUtils');

const REPUTATION_RULES = {
  ANSWER_UPVOTE: 10,
  ANSWER_UPVOTE_REMOVED: -10,
  ACCEPTED_ANSWER: 15,
  ACCEPTED_REMOVED: -15,
  VERIFIED_ANSWER: 20,
  VERIFY_REMOVED: -20,
  USEFUL_COMMENT: 5,
};

const addReputation = async (userId, points) => {
  if (!userId || !points) return null;

  const User = require('../models/User');
  const id = userId._id || userId;

  const user = await User.findByIdAndUpdate(
    id,
    { $inc: { reputation: points } },
    { new: true }
  );

  if (user && user.reputation < 0) {
    user.reputation = 0;
    await user.save({ validateBeforeSave: false });
  }

  return user;
};

module.exports = {
  REPUTATION_RULES,
  BADGE_THRESHOLDS,
  getBadge,
  addReputation,
};
