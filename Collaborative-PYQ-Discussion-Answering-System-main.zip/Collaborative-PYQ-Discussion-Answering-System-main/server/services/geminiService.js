const { GoogleGenerativeAI } = require('@google/generative-ai');
const AppError = require('../utils/AppError');

const DEFAULT_MODEL = 'gemini-2.5-flash';
const FALLBACK_MODELS = ['gemini-2.5-flash', 'gemini-2.0-flash-lite'];

let genAIClient = null;

const isPlaceholderKey = (key) =>
  !key ||
  key === 'your_gemini_api_key' ||
  key.startsWith('your_') ||
  key.length < 20;

const getClient = () => {
  if (isPlaceholderKey(process.env.GEMINI_API_KEY)) {
    throw new AppError(
      'Gemini API is not configured. Add a valid GEMINI_API_KEY to server/.env (see https://aistudio.google.com/apikey).',
      503
    );
  }
  if (!genAIClient) {
    genAIClient = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  }
  return genAIClient;
};

const handleGeminiError = (err) => {
  const message = err?.message || '';

  if (
    message.includes('API key not valid') ||
    message.includes('API_KEY_INVALID') ||
    message.includes('API key expired')
  ) {
    throw new AppError(
      'Gemini API key is invalid or expired. Create a new key at https://aistudio.google.com/apikey and update GEMINI_API_KEY in server/.env.',
      503
    );
  }

  if (message.includes('404') || message.includes('not found') || message.includes('is not supported')) {
    throw new AppError(
      `Gemini model unavailable. Set GEMINI_MODEL=gemini-2.5-flash in server/.env.`,
      503
    );
  }

  if (
    message.includes('429') ||
    message.includes('quota') ||
    message.includes('Quota exceeded') ||
    message.includes('Too Many Requests')
  ) {
    throw new AppError(
      'Gemini rate limit reached. Wait 30–60 seconds and try again. If this persists, check billing/quota at https://ai.google.dev/gemini-api/docs/rate-limits or set GEMINI_MODEL=gemini-1.5-flash in server/.env.',
      503
    );
  }

  if (message.includes('Gemini API is not configured')) {
    throw err;
  }

  throw new AppError(
    process.env.NODE_ENV === 'development' && message
      ? `Gemini error: ${message.split('\n')[0].slice(0, 200)}`
      : 'AI request failed. Try again in a moment.',
    503
  );
};

const generateWithModel = async (prompt, modelName) => {
  const genAI = getClient();
  const model = genAI.getGenerativeModel({ model: modelName });
  const result = await model.generateContent(prompt);
  return result.response.text();
};

const generateText = async (prompt) => {
  const primary = process.env.GEMINI_MODEL || DEFAULT_MODEL;
  const models = [...new Set([primary, ...FALLBACK_MODELS])];

  let lastError = null;

  for (const modelName of models) {
    try {
      return await generateWithModel(prompt, modelName);
    } catch (err) {
      lastError = err;
      const msg = err?.message || '';
      const retryable =
        msg.includes('429') ||
        msg.includes('quota') ||
        msg.includes('Quota exceeded') ||
        msg.includes('not found') ||
        msg.includes('404') ||
        msg.includes('is not supported');

      if (!retryable) {
        handleGeminiError(err);
      }
    }
  }

  handleGeminiError(lastError);
};

const explainAnswer = async ({ questionTitle, questionDescription, answerText }) => {
  const prompt = `You are a helpful tutor for B.Tech students reviewing Previous Year Questions (PYQs).

Question: ${questionTitle}
Details: ${questionDescription}

Answer to explain:
${answerText}

Provide a clear, step-by-step explanation of this answer. Use simple language, highlight key concepts, and mention common mistakes students make. Keep it under 300 words.`;

  return generateText(prompt);
};

const summarizeQuestion = async ({ title, description, subject }) => {
  const prompt = `Summarize this PYQ in 2-3 concise sentences for quick revision.

Subject: ${subject}
Title: ${title}
Description: ${description}

Return only the summary, no heading.`;

  return generateText(prompt);
};

const recommendSimilar = async ({ currentQuestion, candidates }) => {
  if (!candidates.length) {
    return { recommendations: [], aiNote: 'No similar questions found in the database.' };
  }

  const listText = candidates
    .map(
      (q, i) =>
        `${i + 1}. ID:${q._id} | ${q.title} | Subject:${q.subject} | Sem:${q.semester} | Year:${q.year} | Difficulty:${q.difficulty}`
    )
    .join('\n');

  const prompt = `Given this PYQ:
Title: ${currentQuestion.title}
Subject: ${currentQuestion.subject}
Semester: ${currentQuestion.semester}
Year: ${currentQuestion.year}
Description: ${currentQuestion.description}

Pick the top 3 most similar questions from this list (by ID number). Return ONLY valid JSON:
{"ids":["id1","id2","id3"],"reason":"one sentence why these are similar"}

Candidate list:
${listText}`;

  const raw = await generateText(prompt);
  const jsonMatch = raw.match(/\{[\s\S]*\}/);

  if (!jsonMatch) {
    return {
      recommendations: candidates.slice(0, 3),
      aiNote: 'Showing questions from the same subject.',
    };
  }

  try {
    const parsed = JSON.parse(jsonMatch[0]);
    const ids = parsed.ids || [];
    const recommendations = ids
      .map((id) => candidates.find((q) => q._id.toString() === id.toString()))
      .filter(Boolean);

    return {
      recommendations: recommendations.length ? recommendations : candidates.slice(0, 3),
      aiNote: parsed.reason || '',
    };
  } catch {
    return {
      recommendations: candidates.slice(0, 3),
      aiNote: 'Showing questions from the same subject.',
    };
  }
};

module.exports = { explainAnswer, summarizeQuestion, recommendSimilar };
