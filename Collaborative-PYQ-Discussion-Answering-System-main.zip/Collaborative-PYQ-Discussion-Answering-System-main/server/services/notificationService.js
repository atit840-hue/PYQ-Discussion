const Notification = require('../models/Notification');

const createNotification = async ({
  recipientId,
  senderId,
  type,
  title,
  message,
  link,
  relatedId,
}) => {
  if (!recipientId) return null;

  const recipientStr = recipientId.toString();
  const senderStr = senderId?.toString();

  if (senderStr && recipientStr === senderStr) return null;

  return Notification.create({
    recipient: recipientId,
    sender: senderId,
    type,
    title,
    message,
    link,
    relatedId,
  });
};

module.exports = { createNotification };
