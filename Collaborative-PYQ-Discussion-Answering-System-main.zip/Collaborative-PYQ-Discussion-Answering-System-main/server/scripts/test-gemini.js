require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

const key = process.env.GEMINI_API_KEY;
console.log('Key length:', key?.length, 'prefix:', key?.slice(0, 8));

const models = [
  'gemini-2.5-flash',
  'gemini-2.0-flash-lite',
];

async function main() {
  const genAI = new GoogleGenerativeAI(key);
  for (const model of models) {
    try {
      const result = await genAI.getGenerativeModel({ model }).generateContent('Say hello');
      console.log(`[OK] ${model}:`, result.response.text().trim().slice(0, 80));
    } catch (e) {
      console.log(`[FAIL] ${model}:`, e.message.split('\n')[0].slice(0, 300));
    }
  }
}

main();
