const NOTIFICATION_TYPES = [
  'new_answer',
  'answer_verified',
  'new_comment',
  'report_reviewed',
  'upvote',
  'system',
];

module.exports = { NOTIFICATION_TYPES };
