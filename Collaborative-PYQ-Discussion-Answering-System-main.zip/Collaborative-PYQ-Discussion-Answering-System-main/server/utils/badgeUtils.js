const BADGE_THRESHOLDS = [
  { name: 'Expert', min: 1000, variant: 'danger', icon: 'bi-gem' },
  { name: 'Gold', min: 500, variant: 'warning', icon: 'bi-award-fill' },
  { name: 'Silver', min: 200, variant: 'secondary', icon: 'bi-award' },
  { name: 'Bronze', min: 50, variant: 'info', icon: 'bi-patch-check' },
  { name: 'Newcomer', min: 0, variant: 'light', icon: 'bi-person' },
];

const getBadge = (reputation) => {
  const score = reputation || 0;
  return BADGE_THRESHOLDS.find((b) => score >= b.min) || BADGE_THRESHOLDS[BADGE_THRESHOLDS.length - 1];
};

module.exports = { BADGE_THRESHOLDS, getBadge };
