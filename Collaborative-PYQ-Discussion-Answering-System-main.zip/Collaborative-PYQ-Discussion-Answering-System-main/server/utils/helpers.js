const Question = require('../models/Question');
const Answer = require('../models/Answer');
const Comment = require('../models/Comment');
const Bookmark = require('../models/Bookmark');
const Report = require('../models/Report');
const AppError = require('./AppError');

const TARGET_MODEL_MAP = {
  question: { model: Question, ref: 'Question' },
  answer: { model: Answer, ref: 'Answer' },
  comment: { model: Comment, ref: 'Comment' },
};

const findTarget = async (targetType, targetId) => {
  const config = TARGET_MODEL_MAP[targetType];
  if (!config) {
    throw new AppError('Invalid target type', 400);
  }

  const target = await config.model.findById(targetId);
  if (!target) {
    throw new AppError(`${config.ref} not found`, 404);
  }

  return { target, ref: config.ref };
};

const deleteQuestionCascade = async (questionId) => {
  const answerIds = await Answer.find({ question: questionId }).distinct('_id');
  const commentIds = await Comment.find({ answer: { $in: answerIds } }).distinct('_id');

  await Promise.all([
    Comment.deleteMany({ answer: { $in: answerIds } }),
    Answer.deleteMany({ question: questionId }),
    Bookmark.deleteMany({ question: questionId }),
    Report.deleteMany({
      $or: [
        { targetType: 'question', targetId: questionId },
        { targetType: 'answer', targetId: { $in: answerIds } },
        { targetType: 'comment', targetId: { $in: commentIds } },
      ],
    }),
    Question.findByIdAndDelete(questionId),
  ]);
};

const deleteAnswerCascade = async (answerId) => {
  const commentIds = await Comment.find({ answer: answerId }).distinct('_id');

  await Promise.all([
    Comment.deleteMany({ answer: answerId }),
    Report.deleteMany({
      $or: [
        { targetType: 'answer', targetId: answerId },
        { targetType: 'comment', targetId: { $in: commentIds } },
      ],
    }),
    Answer.findByIdAndDelete(answerId),
  ]);
};

const isAuthorOrAdmin = (user, authorId) => {
  return user.role === 'admin' || user._id.toString() === authorId.toString();
};

module.exports = {
  TARGET_MODEL_MAP,
  findTarget,
  deleteQuestionCascade,
  deleteAnswerCascade,
  isAuthorOrAdmin,
};
