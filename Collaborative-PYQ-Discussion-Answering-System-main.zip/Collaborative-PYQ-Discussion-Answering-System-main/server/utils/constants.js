const DIFFICULTIES = ['easy', 'medium', 'hard'];

const EXAMS = ['GATE', 'B.Tech End Sem', 'B.Tech Mid Sem', 'Placement', 'Other'];

const BRANCHES = ['CSE', 'IT', 'ECE', 'ME'];

const RESOURCE_FILE_TYPES = ['pdf', 'docx', 'ppt', 'pptx', 'image', 'other'];

const REPORT_TARGET_TYPES = ['question', 'answer', 'comment'];

const REPORT_STATUSES = ['pending', 'reviewed', 'dismissed'];

const SEMESTER_MIN = 1;
const SEMESTER_MAX = 8;

module.exports = {
  DIFFICULTIES,
  EXAMS,
  BRANCHES,
  RESOURCE_FILE_TYPES,
  REPORT_TARGET_TYPES,
  REPORT_STATUSES,
  SEMESTER_MIN,
  SEMESTER_MAX,
};
