const Subject = require('../models/Subject');
const AppError = require('./AppError');

const resolveSubject = async (subjectName, topic, subTopic) => {
  const subjectDoc = await Subject.findOne({
    $or: [{ name: new RegExp(`^${subjectName}$`, 'i') }, { slug: subjectName.toLowerCase() }],
  });

  if (!subjectDoc) {
    throw new AppError('Invalid subject. Choose from the available subjects list.', 400);
  }

  if (topic) {
    const topicMatch = subjectDoc.topics.find(
      (t) => t.name.toLowerCase() === topic.toLowerCase()
    );
    if (!topicMatch) {
      throw new AppError(`Topic "${topic}" is not valid for ${subjectDoc.name}`, 400);
    }
    if (
      subTopic &&
      !topicMatch.subTopics.some((st) => st.toLowerCase() === subTopic.toLowerCase())
    ) {
      throw new AppError(`Sub-topic "${subTopic}" is not valid for ${topic}`, 400);
    }
  }

  return {
    subject: subjectDoc.name,
    subjectRef: subjectDoc._id,
    topic: topic || undefined,
    subTopic: subTopic || undefined,
  };
};

module.exports = { resolveSubject };
