const express = require('express');
const { getAnalytics, getMyAnalytics, getAnalyticsSummary } = require('../controllers/analyticsController');
const { protect, authorize } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/me', protect, asyncHandler(getMyAnalytics));
router.get('/summary', protect, asyncHandler(getAnalyticsSummary));
router.get('/', protect, authorize('admin', 'moderator'), asyncHandler(getAnalytics));

module.exports = router;
