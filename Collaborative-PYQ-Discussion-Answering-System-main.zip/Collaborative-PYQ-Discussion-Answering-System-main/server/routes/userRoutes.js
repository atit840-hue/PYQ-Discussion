const express = require('express');
const { getLeaderboard, getMyProfile } = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/leaderboard', asyncHandler(getLeaderboard));
router.get('/me/profile', protect, asyncHandler(getMyProfile));

module.exports = router;