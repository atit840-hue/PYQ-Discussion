const express = require('express');
const { deleteComment } = require('../controllers/commentController');
const { protect, authorize } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.delete('/:id', protect, asyncHandler(deleteComment));

module.exports = router;
