const express = require('express');
const { getHomeFeed } = require('../controllers/homeController');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/feed', asyncHandler(getHomeFeed));

module.exports = router;
