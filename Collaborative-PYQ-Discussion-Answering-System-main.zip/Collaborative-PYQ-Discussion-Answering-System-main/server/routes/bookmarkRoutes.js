const express = require('express');
const {
  getBookmarks,
  addBookmark,
  removeBookmark,
  toggleBookmark,
} = require('../controllers/bookmarkController');
const { protect } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.use(protect);

router.get('/', asyncHandler(getBookmarks));
router.post('/', asyncHandler(addBookmark));
router.post('/:questionId/toggle', asyncHandler(toggleBookmark));
router.post('/:questionId', asyncHandler(addBookmark));
router.delete('/:questionId', asyncHandler(removeBookmark));

module.exports = router;
