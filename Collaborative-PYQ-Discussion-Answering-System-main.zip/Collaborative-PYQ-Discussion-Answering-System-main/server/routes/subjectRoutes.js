const express = require('express');
const {
  getSubjects,
  getSubjectBySlug,
  getSubjectTopics,
} = require('../controllers/subjectController');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/', asyncHandler(getSubjects));
router.get('/:slug/topics', asyncHandler(getSubjectTopics));
router.get('/:slug', asyncHandler(getSubjectBySlug));

module.exports = router;
