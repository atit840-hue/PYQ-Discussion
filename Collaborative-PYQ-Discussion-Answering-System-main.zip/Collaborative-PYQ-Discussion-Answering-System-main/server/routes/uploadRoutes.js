const express = require('express');
const upload = require('../middleware/upload');
const { uploadProfilePicture, uploadQuestionImage } = require('../controllers/uploadController');
const { protect } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.post(
  '/profile',
  protect,
  upload.single('image'),
  asyncHandler(uploadProfilePicture)
);

router.post(
  '/question',
  protect,
  upload.single('image'),
  asyncHandler(uploadQuestionImage)
);

module.exports = router;
