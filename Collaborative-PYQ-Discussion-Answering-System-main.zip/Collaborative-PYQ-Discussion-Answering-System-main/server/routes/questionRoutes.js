const express = require('express');
const {
  getQuestions,
  getQuestion,
  createQuestion,
  updateQuestion,
  deleteQuestion,
  getSubjectsList,
  acceptAnswer,
  upvoteQuestion,
  downvoteQuestion,
} = require('../controllers/questionController');
const {
  getAnswersByQuestion,
  createAnswer,
} = require('../controllers/answerController');
const { protect, authorize } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/subjects/list', asyncHandler(getSubjectsList));
router.get('/', asyncHandler(getQuestions));
router.post('/', protect, asyncHandler(createQuestion));
router.get('/:id', asyncHandler(getQuestion));
router.put('/:id', protect, asyncHandler(updateQuestion));
router.delete('/:id', protect, authorize('admin'), asyncHandler(deleteQuestion));

router.post('/:id/upvote', protect, asyncHandler(upvoteQuestion));
router.post('/:id/downvote', protect, asyncHandler(downvoteQuestion));
router.patch('/:id/accept/:answerId', protect, asyncHandler(acceptAnswer));

router.get('/:questionId/answers', asyncHandler(getAnswersByQuestion));
router.post('/:questionId/answers', protect, asyncHandler(createAnswer));

module.exports = router;
