const express = require('express');
const { explain, summarize, similar } = require('../controllers/aiController');
const { protect } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.use(protect);

router.post('/explain', asyncHandler(explain));
router.get('/summarize/:questionId', asyncHandler(summarize));
router.get('/similar/:questionId', asyncHandler(similar));

module.exports = router;
