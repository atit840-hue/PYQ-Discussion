const express = require('express');
const {
  getPyqs,
  getPyq,
  createPyq,
  updatePyq,
  deletePyq,
  getExamsList,
} = require('../controllers/pyqController');
const { protect, authorize } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/exams/list', asyncHandler(getExamsList));
router.get('/', asyncHandler(getPyqs));
router.post('/', protect, asyncHandler(createPyq));
router.get('/:id', asyncHandler(getPyq));
router.put('/:id', protect, asyncHandler(updatePyq));
router.delete('/:id', protect, authorize('admin'), asyncHandler(deletePyq));

module.exports = router;
