const express = require('express');
const {
  getAnswer,
  updateAnswer,
  deleteAnswer,
  verifyAnswer,
  upvoteAnswer,
  downvoteAnswer,
  removeVote,
} = require('../controllers/answerController');
const {
  getCommentsByAnswer,
  createComment,
} = require('../controllers/commentController');
const { protect, authorize } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/:id', asyncHandler(getAnswer));
router.put('/:id', protect, asyncHandler(updateAnswer));
router.delete('/:id', protect, authorize('admin'), asyncHandler(deleteAnswer));

router.patch(
  '/:id/verify',
  protect,
  authorize('moderator', 'admin'),
  asyncHandler(verifyAnswer)
);

router.post('/:id/upvote', protect, asyncHandler(upvoteAnswer));
router.post('/:id/downvote', protect, asyncHandler(downvoteAnswer));
router.delete('/:id/vote', protect, asyncHandler(removeVote));

router.get('/:answerId/comments', asyncHandler(getCommentsByAnswer));
router.post('/:answerId/comments', protect, asyncHandler(createComment));

module.exports = router;
