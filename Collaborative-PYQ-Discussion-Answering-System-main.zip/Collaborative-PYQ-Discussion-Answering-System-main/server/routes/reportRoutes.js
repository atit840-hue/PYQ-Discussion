const express = require('express');
const {
  createReport,
  getReports,
  getReport,
  updateReportStatus,
} = require('../controllers/reportController');
const { protect, authorize } = require('../middleware/authMiddleware');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.post('/', protect, asyncHandler(createReport));

router.get(
  '/',
  protect,
  authorize('moderator', 'admin'),
  asyncHandler(getReports)
);

router.get(
  '/:id',
  protect,
  authorize('moderator', 'admin'),
  asyncHandler(getReport)
);

router.patch(
  '/:id',
  protect,
  authorize('moderator', 'admin'),
  asyncHandler(updateReportStatus)
);

module.exports = router;
