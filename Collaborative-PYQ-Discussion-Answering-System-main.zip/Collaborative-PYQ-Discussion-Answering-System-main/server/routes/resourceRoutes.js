const express = require('express');
const {
  getResources,
  getResource,
  createResource,
  downloadResource,
  likeResource,
  bookmarkResource,
  getSemesterCurriculum,
} = require('../controllers/resourceController');
const { protect } = require('../middleware/authMiddleware');
const resourceUpload = require('../middleware/resourceUpload');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/curriculum', asyncHandler(getSemesterCurriculum));
router.get('/', asyncHandler(getResources));
router.get('/:id', asyncHandler(getResource));
router.post('/', protect, resourceUpload.single('file'), asyncHandler(createResource));
router.post('/:id/download', asyncHandler(downloadResource));
router.post('/:id/like', protect, asyncHandler(likeResource));
router.post('/:id/bookmark', protect, asyncHandler(bookmarkResource));

module.exports = router;
