const BRANCHES = ['CSE', 'IT', 'ECE', 'ME'];

const CURRICULUM = {
  CSE: {
    1: ['Mathematics I', 'Physics', 'Programming Fundamentals', 'Digital Logic'],
    2: ['Mathematics II', 'Data Structures', 'Computer Organization', 'Discrete Mathematics'],
    3: ['DSA', 'Algorithms', 'Digital Logic', 'COA'],
    4: ['Operating Systems', 'DBMS', 'Computer Networks', 'TOC'],
    5: ['DBMS', 'Operating Systems', 'Computer Networks', 'TOC', 'Software Engineering'],
    6: ['Compiler Design', 'Machine Learning', 'Cloud Computing', 'Cyber Security'],
    7: ['Big Data', 'Distributed Systems', 'Elective I', 'Elective II'],
    8: ['Project', 'Elective III', 'Elective IV'],
  },
  IT: {
    1: ['Mathematics I', 'Physics', 'Programming Fundamentals', 'Digital Logic'],
    2: ['Mathematics II', 'Data Structures', 'Web Technologies', 'Discrete Mathematics'],
    3: ['DSA', 'Algorithms', 'Database Systems', 'Computer Networks'],
    4: ['Operating Systems', 'DBMS', 'Software Engineering', 'TOC'],
    5: ['DBMS', 'Computer Networks', 'Web Development', 'Mobile Computing'],
    6: ['Cloud Computing', 'Data Mining', 'Information Security', 'Elective'],
    7: ['Big Data', 'IoT', 'Elective I', 'Elective II'],
    8: ['Project', 'Elective III'],
  },
  ECE: {
    1: ['Mathematics I', 'Physics', 'Basic Electronics', 'Programming'],
    2: ['Mathematics II', 'Electronic Devices', 'Signals & Systems', 'Digital Logic'],
    3: ['Analog Circuits', 'Digital Electronics', 'Network Theory', 'COA'],
    4: ['Communication Systems', 'Microprocessors', 'Control Systems', 'EM Theory'],
    5: ['Digital Communication', 'VLSI', 'Embedded Systems', 'Computer Networks'],
    6: ['Wireless Communication', 'DSP', 'Elective I', 'Elective II'],
    7: ['Optical Communication', 'Elective III', 'Elective IV'],
    8: ['Project', 'Elective V'],
  },
  ME: {
    1: ['Mathematics I', 'Physics', 'Engineering Graphics', 'Workshop'],
    2: ['Mathematics II', 'Strength of Materials', 'Thermodynamics', 'Manufacturing'],
    3: ['Fluid Mechanics', 'Kinematics of Machinery', 'Material Science', 'Machine Drawing'],
    4: ['Dynamics of Machinery', 'Heat Transfer', 'Manufacturing II', 'Metrology'],
    5: ['Design of Machine Elements', 'IC Engines', 'CAD/CAM', 'Industrial Engineering'],
    6: ['Automobile Engineering', 'Refrigeration', 'Elective I', 'Elective II'],
    7: ['Finite Element Methods', 'Elective III', 'Elective IV'],
    8: ['Project', 'Elective V'],
  },
};

const getSubjectsForBranchSemester = (branch, semester) => {
  const sem = Number(semester);
  return CURRICULUM[branch]?.[sem] || [];
};

module.exports = { BRANCHES, CURRICULUM, getSubjectsForBranchSemester };
