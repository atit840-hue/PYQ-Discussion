const mongoose = require('mongoose');
const { DIFFICULTIES, EXAMS } = require('../utils/constants');

const imageSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    publicId: { type: String },
  },
  { _id: false }
);

const pyqSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    questionText: {
      type: String,
      required: [true, 'Question text is required'],
      trim: true,
      maxlength: [10000, 'Question text cannot exceed 10000 characters'],
    },
    exam: {
      type: String,
      required: [true, 'Exam is required'],
      enum: {
        values: EXAMS,
        message: `Exam must be one of: ${EXAMS.join(', ')}`,
      },
    },
    year: {
      type: Number,
      required: [true, 'Year is required'],
      min: [1990, 'Year must be 1990 or later'],
      max: [2100, 'Year cannot exceed 2100'],
    },
    subject: {
      type: String,
      required: [true, 'Subject is required'],
      trim: true,
      maxlength: [100, 'Subject cannot exceed 100 characters'],
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true,
    },
    topic: {
      type: String,
      trim: true,
      maxlength: [100, 'Topic cannot exceed 100 characters'],
    },
    subTopic: {
      type: String,
      trim: true,
      maxlength: [100, 'Sub-topic cannot exceed 100 characters'],
    },
    marks: {
      type: Number,
      required: [true, 'Marks is required'],
      min: [1, 'Marks must be at least 1'],
      max: [100, 'Marks cannot exceed 100'],
    },
    difficulty: {
      type: String,
      required: [true, 'Difficulty is required'],
      enum: {
        values: DIFFICULTIES,
        message: 'Difficulty must be easy, medium, or hard',
      },
    },
    officialAnswer: {
      type: String,
      trim: true,
      maxlength: [5000, 'Official answer cannot exceed 5000 characters'],
    },
    solution: {
      type: String,
      trim: true,
      maxlength: [10000, 'Solution cannot exceed 10000 characters'],
    },
    questionImage: imageSchema,
    images: {
      type: [imageSchema],
      validate: {
        validator: (v) => v.length <= 3,
        message: 'Maximum 3 images allowed',
      },
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    views: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

pyqSchema.index({ subjectRef: 1, exam: 1, year: 1 });
pyqSchema.index({ subjectRef: 1, topic: 1, subTopic: 1 });
pyqSchema.index({ exam: 1, year: -1 });
pyqSchema.index({ title: 'text', questionText: 'text' });
pyqSchema.index({ createdAt: -1 });

const Pyq = mongoose.model('Pyq', pyqSchema);

module.exports = Pyq;
