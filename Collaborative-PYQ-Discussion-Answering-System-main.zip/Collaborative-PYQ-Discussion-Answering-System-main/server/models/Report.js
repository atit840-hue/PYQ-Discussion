const mongoose = require('mongoose');
const { REPORT_TARGET_TYPES, REPORT_STATUSES } = require('../utils/constants');

const reportSchema = new mongoose.Schema(
  {
    reportedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    targetType: {
      type: String,
      required: [true, 'Target type is required'],
      enum: {
        values: REPORT_TARGET_TYPES,
        message: 'Target type must be question, answer, or comment',
      },
    },
    targetId: {
      type: mongoose.Schema.Types.ObjectId,
      required: [true, 'Target ID is required'],
      refPath: 'targetTypeRef',
    },
    targetTypeRef: {
      type: String,
      required: true,
      enum: ['Question', 'Answer', 'Comment'],
    },
    reason: {
      type: String,
      required: [true, 'Reason is required'],
      trim: true,
      maxlength: [200, 'Reason cannot exceed 200 characters'],
    },
    description: {
      type: String,
      trim: true,
      maxlength: [2000, 'Description cannot exceed 2000 characters'],
    },
    status: {
      type: String,
      enum: {
        values: REPORT_STATUSES,
        message: 'Status must be pending, reviewed, or dismissed',
      },
      default: 'pending',
    },
    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    reviewedAt: {
      type: Date,
    },
    reviewNote: {
      type: String,
      trim: true,
      maxlength: [1000, 'Review note cannot exceed 1000 characters'],
    },
  },
  {
    timestamps: true,
  }
);

reportSchema.index({ status: 1, createdAt: -1 });
reportSchema.index({ targetType: 1, targetId: 1 });

const Report = mongoose.model('Report', reportSchema);

module.exports = Report;
