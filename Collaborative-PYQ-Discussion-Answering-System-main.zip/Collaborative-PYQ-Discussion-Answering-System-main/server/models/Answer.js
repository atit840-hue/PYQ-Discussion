const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema(
  {
    question: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Question',
      required: true,
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    answerText: {
      type: String,
      required: [true, 'Answer text is required'],
      trim: true,
      maxlength: [10000, 'Answer cannot exceed 10000 characters'],
    },
    verified: {
      type: Boolean,
      default: false,
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    verifiedAt: {
      type: Date,
    },
    upvotes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ],
    downvotes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ],
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

answerSchema.virtual('voteScore').get(function () {
  return this.upvotes.length - this.downvotes.length;
});

answerSchema.index({ question: 1, createdAt: -1 });
answerSchema.index({ verified: -1, voteScore: -1 });

answerSchema.methods.applyVote = function (userId, voteType) {
  const uid = userId.toString();
  const upIndex = this.upvotes.findIndex((id) => id.toString() === uid);
  const downIndex = this.downvotes.findIndex((id) => id.toString() === uid);

  if (voteType === 'upvote') {
    if (upIndex !== -1) {
      this.upvotes.splice(upIndex, 1);
      return 'removed';
    }
    if (downIndex !== -1) {
      this.downvotes.splice(downIndex, 1);
    }
    this.upvotes.push(userId);
    return 'upvoted';
  }

  if (voteType === 'downvote') {
    if (downIndex !== -1) {
      this.downvotes.splice(downIndex, 1);
      return 'removed';
    }
    if (upIndex !== -1) {
      this.upvotes.splice(upIndex, 1);
    }
    this.downvotes.push(userId);
    return 'downvoted';
  }

  return null;
};

answerSchema.methods.removeVote = function (userId) {
  const uid = userId.toString();
  const upIndex = this.upvotes.findIndex((id) => id.toString() === uid);
  const downIndex = this.downvotes.findIndex((id) => id.toString() === uid);

  if (upIndex !== -1) {
    this.upvotes.splice(upIndex, 1);
    return 'upvote';
  }
  if (downIndex !== -1) {
    this.downvotes.splice(downIndex, 1);
    return 'downvote';
  }
  return null;
};

const Answer = mongoose.model('Answer', answerSchema);

module.exports = Answer;
