const mongoose = require('mongoose');
const { DIFFICULTIES, SEMESTER_MIN, SEMESTER_MAX } = require('../utils/constants');

const applyVote = (doc, userId, voteType) => {
  const uid = userId.toString();
  const upIndex = doc.upvotes.findIndex((id) => id.toString() === uid);
  const downIndex = doc.downvotes.findIndex((id) => id.toString() === uid);

  if (voteType === 'upvote') {
    if (upIndex !== -1) {
      doc.upvotes.splice(upIndex, 1);
      return 'removed';
    }
    if (downIndex !== -1) doc.downvotes.splice(downIndex, 1);
    doc.upvotes.push(userId);
    return 'upvoted';
  }

  if (voteType === 'downvote') {
    if (downIndex !== -1) {
      doc.downvotes.splice(downIndex, 1);
      return 'removed';
    }
    if (upIndex !== -1) doc.upvotes.splice(upIndex, 1);
    doc.downvotes.push(userId);
    return 'downvoted';
  }

  return null;
};

const questionSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      maxlength: [10000, 'Description cannot exceed 10000 characters'],
    },
    subject: {
      type: String,
      required: [true, 'Subject is required'],
      trim: true,
      maxlength: [100, 'Subject cannot exceed 100 characters'],
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
    },
    topic: {
      type: String,
      trim: true,
      maxlength: [100, 'Topic cannot exceed 100 characters'],
    },
    subTopic: {
      type: String,
      trim: true,
      maxlength: [100, 'Sub-topic cannot exceed 100 characters'],
    },
    semester: {
      type: Number,
      required: [true, 'Semester is required'],
      min: [SEMESTER_MIN, `Semester must be between ${SEMESTER_MIN} and ${SEMESTER_MAX}`],
      max: [SEMESTER_MAX, `Semester must be between ${SEMESTER_MIN} and ${SEMESTER_MAX}`],
    },
    year: {
      type: Number,
      required: [true, 'Year is required'],
      min: [1990, 'Year must be 1990 or later'],
      max: [2100, 'Year cannot exceed 2100'],
    },
    difficulty: {
      type: String,
      required: [true, 'Difficulty is required'],
      enum: {
        values: DIFFICULTIES,
        message: 'Difficulty must be easy, medium, or hard',
      },
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    acceptedAnswer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Answer',
    },
    answerCount: {
      type: Number,
      default: 0,
    },
    views: {
      type: Number,
      default: 0,
    },
    upvotes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    downvotes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    images: [
      {
        url: { type: String, required: true },
        publicId: { type: String },
      },
    ],
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

questionSchema.virtual('voteScore').get(function () {
  return (this.upvotes?.length || 0) - (this.downvotes?.length || 0);
});

questionSchema.methods.applyVote = function (userId, voteType) {
  return applyVote(this, userId, voteType);
};

questionSchema.index({ subject: 1, semester: 1, year: 1 });
questionSchema.index({ subjectRef: 1, topic: 1, subTopic: 1 });
questionSchema.index({ title: 'text', description: 'text' });
questionSchema.index({ createdAt: -1 });
questionSchema.index({ upvotes: -1 });

const Question = mongoose.model('Question', questionSchema);

module.exports = Question;
