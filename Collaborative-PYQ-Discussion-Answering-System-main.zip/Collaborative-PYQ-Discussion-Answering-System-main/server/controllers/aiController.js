const Question = require('../models/Question');
const AppError = require('../utils/AppError');
const {
  explainAnswer,
  summarizeQuestion,
  recommendSimilar,
} = require('../services/geminiService');

const explain = async (req, res) => {
  const { questionId, answerId, answerText } = req.body;

  let qTitle = req.body.questionTitle;
  let qDescription = req.body.questionDescription;
  let aText = answerText;

  if (questionId) {
    const question = await Question.findById(questionId);
    if (!question) throw new AppError('Question not found', 404);
    qTitle = question.title;
    qDescription = question.description;
  }

  if (answerId && !aText) {
    const Answer = require('../models/Answer');
    const answer = await Answer.findById(answerId);
    if (!answer) throw new AppError('Answer not found', 404);
    aText = answer.answerText;
  }

  if (!qTitle || !aText) {
    throw new AppError('Question and answer content required', 400);
  }

  const explanation = await explainAnswer({
    questionTitle: qTitle,
    questionDescription: qDescription || '',
    answerText: aText,
  });

  res.status(200).json({
    success: true,
    data: { explanation },
  });
};

const summarize = async (req, res) => {
  const { questionId } = req.params;

  const question = await Question.findById(questionId);
  if (!question) throw new AppError('Question not found', 404);

  const summary = await summarizeQuestion({
    title: question.title,
    description: question.description,
    subject: question.subject,
  });

  res.status(200).json({
    success: true,
    data: { summary },
  });
};

const similar = async (req, res) => {
  const question = await Question.findById(req.params.questionId);
  if (!question) throw new AppError('Question not found', 404);

  const candidates = await Question.find({
    _id: { $ne: question._id },
    subject: new RegExp(question.subject, 'i'),
  })
    .limit(15)
    .select('title subject semester year difficulty answerCount views')
    .lean();

  if (!candidates.length) {
    const fallback = await Question.find({ _id: { $ne: question._id } })
      .limit(5)
      .select('title subject semester year difficulty answerCount views')
      .lean();

    return res.status(200).json({
      success: true,
      data: {
        recommendations: fallback,
        aiNote: 'Showing recent questions from the platform.',
      },
    });
  }

  const { recommendations, aiNote } = await recommendSimilar({
    currentQuestion: question,
    candidates,
  });

  res.status(200).json({
    success: true,
    data: { recommendations, aiNote },
  });
};

module.exports = { explain, summarize, similar };
