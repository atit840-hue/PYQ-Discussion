const Resource = require('../models/Resource');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { BRANCHES } = require('../utils/constants');
const cloudinary = require('../config/cloudinary');
const { getSubjectsForBranchSemester } = require('../data/semesterCurriculum');

const inferFileType = (mimetype) => {
  if (mimetype.includes('pdf')) return 'pdf';
  if (mimetype.includes('word') || mimetype.includes('document')) return 'docx';
  if (mimetype.includes('presentation') || mimetype.includes('powerpoint')) return 'ppt';
  if (mimetype.startsWith('image/')) return 'image';
  return 'other';
};

const uploadBuffer = (buffer, folder, mimetype) =>
  new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      {
        folder: `pyq-discussion/${folder}`,
        resource_type: 'auto',
        format: mimetype.includes('pdf') ? 'pdf' : undefined,
      },
      (error, result) => {
        if (error) reject(error);
        else resolve(result);
      }
    );
    stream.end(buffer);
  });

const getResources = async (req, res) => {
  const { page, limit, skip } = getPagination(req.query);
  const { branch, semester, subject, search, sort } = req.query;
  const filter = {};

  if (branch) filter.branch = branch;
  if (semester) filter.semester = parseInt(semester, 10);
  if (subject) filter.subject = new RegExp(`^${subject}$`, 'i');
  if (search) filter.$text = { $search: search };

  let sortOption = { createdAt: -1 };
  if (sort === 'popular') sortOption = { downloads: -1, createdAt: -1 };
  if (sort === 'liked') sortOption = { likes: -1, createdAt: -1 };

  const [resources, total] = await Promise.all([
    Resource.find(filter)
      .populate('uploadedBy', 'name profilePicture reputation')
      .sort(sortOption)
      .skip(skip)
      .limit(limit),
    Resource.countDocuments(filter),
  ]);

  res.status(200).json(paginatedResponse(resources, total, page, limit));
};

const getResource = async (req, res) => {
  const resource = await Resource.findById(req.params.id)
    .populate('uploadedBy', 'name profilePicture reputation email');

  if (!resource) throw new AppError('Resource not found', 404);

  res.status(200).json({ success: true, data: { resource } });
};

const createResource = async (req, res) => {
  const { title, description, branch, semester, subject } = req.body;

  if (!title || !branch || !semester || !subject) {
    throw new AppError('Title, branch, semester, and subject are required', 400);
  }

  if (!BRANCHES.includes(branch)) {
    throw new AppError('Invalid branch', 400);
  }

  if (!req.file) {
    throw new AppError('Please upload a file', 400);
  }

  if (!process.env.CLOUDINARY_CLOUD_NAME) {
    throw new AppError('File upload is not configured', 503);
  }

  const result = await uploadBuffer(req.file.buffer, 'resources', req.file.mimetype);
  const fileType = inferFileType(req.file.mimetype);

  const resource = await Resource.create({
    title,
    description,
    fileUrl: result.secure_url,
    filePublicId: result.public_id,
    fileType,
    branch,
    semester: parseInt(semester, 10),
    subject,
    uploadedBy: req.user._id,
  });

  await resource.populate('uploadedBy', 'name profilePicture reputation');

  res.status(201).json({
    success: true,
    message: 'Resource uploaded successfully',
    data: { resource },
  });
};

const downloadResource = async (req, res) => {
  const resource = await Resource.findById(req.params.id);
  if (!resource) throw new AppError('Resource not found', 404);

  resource.downloads += 1;
  await resource.save({ validateBeforeSave: false });

  res.status(200).json({
    success: true,
    data: { url: resource.fileUrl, downloads: resource.downloads },
  });
};

const likeResource = async (req, res) => {
  const resource = await Resource.findById(req.params.id);
  if (!resource) throw new AppError('Resource not found', 404);

  const uid = req.user._id.toString();
  const idx = resource.likes.findIndex((id) => id.toString() === uid);

  if (idx !== -1) {
    resource.likes.splice(idx, 1);
  } else {
    resource.likes.push(req.user._id);
  }

  await resource.save();

  res.status(200).json({
    success: true,
    data: { liked: idx === -1, likeCount: resource.likes.length },
  });
};

const bookmarkResource = async (req, res) => {
  const resource = await Resource.findById(req.params.id);
  if (!resource) throw new AppError('Resource not found', 404);

  const uid = req.user._id.toString();
  const idx = resource.bookmarks.findIndex((id) => id.toString() === uid);

  if (idx !== -1) {
    resource.bookmarks.splice(idx, 1);
  } else {
    resource.bookmarks.push(req.user._id);
  }

  await resource.save();

  res.status(200).json({
    success: true,
    data: { bookmarked: idx === -1, bookmarkCount: resource.bookmarks.length },
  });
};

const getSemesterCurriculum = async (req, res) => {
  const { branch, semester } = req.query;

  if (!branch) {
    return res.status(200).json({ success: true, data: { branches: BRANCHES } });
  }

  if (!semester) {
    return res.status(200).json({
      success: true,
      data: { branch, semesters: [1, 2, 3, 4, 5, 6, 7, 8] },
    });
  }

  const subjects = getSubjectsForBranchSemester(branch, semester);

  res.status(200).json({
    success: true,
    data: { branch, semester: parseInt(semester, 10), subjects },
  });
};

module.exports = {
  getResources,
  getResource,
  createResource,
  downloadResource,
  likeResource,
  bookmarkResource,
  getSemesterCurriculum,
};
