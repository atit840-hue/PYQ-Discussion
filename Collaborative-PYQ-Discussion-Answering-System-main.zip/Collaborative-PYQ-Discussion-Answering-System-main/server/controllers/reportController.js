const Report = require('../models/Report');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { findTarget } = require('../utils/helpers');
const { REPORT_STATUSES } = require('../utils/constants');
const { createNotification } = require('../services/notificationService');

const createReport = async (req, res) => {
  const { targetType, targetId, reason, description } = req.body;

  if (!targetType || !targetId || !reason) {
    throw new AppError('Please provide targetType, targetId, and reason', 400);
  }

  const { ref } = await findTarget(targetType, targetId);

  const existingReport = await Report.findOne({
    reportedBy: req.user._id,
    targetType,
    targetId,
    status: 'pending',
  });

  if (existingReport) {
    throw new AppError('You already have a pending report for this content', 409);
  }

  const report = await Report.create({
    reportedBy: req.user._id,
    targetType,
    targetId,
    targetTypeRef: ref,
    reason,
    description,
  });

  await report.populate('reportedBy', 'name email role');

  res.status(201).json({
    success: true,
    message: 'Report submitted successfully',
    data: { report },
  });
};

const getReports = async (req, res) => {
  const { page, limit, skip } = getPagination(req.query);
  const filter = {};

  if (req.query.status) {
    if (!REPORT_STATUSES.includes(req.query.status)) {
      throw new AppError('Invalid status filter', 400);
    }
    filter.status = req.query.status;
  }

  if (req.query.targetType) {
    filter.targetType = req.query.targetType;
  }

  const [reports, total] = await Promise.all([
    Report.find(filter)
      .populate('reportedBy', 'name email role')
      .populate('reviewedBy', 'name email role')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
    Report.countDocuments(filter),
  ]);

  res.status(200).json(paginatedResponse(reports, total, page, limit));
};

const updateReportStatus = async (req, res) => {
  const { status, reviewNote } = req.body;

  if (!status || !REPORT_STATUSES.includes(status)) {
    throw new AppError('Valid status is required (pending, reviewed, dismissed)', 400);
  }

  const report = await Report.findById(req.params.id);

  if (!report) {
    throw new AppError('Report not found', 404);
  }

  report.status = status;
  report.reviewedBy = req.user._id;
  report.reviewedAt = new Date();

  if (reviewNote !== undefined) {
    report.reviewNote = reviewNote;
  }

  await report.save();
  await report.populate([
    { path: 'reportedBy', select: 'name email role' },
    { path: 'reviewedBy', select: 'name email role' },
  ]);

  if (status !== 'pending') {
    await createNotification({
      recipientId: report.reportedBy,
      senderId: req.user._id,
      type: 'report_reviewed',
      title: 'Your report was reviewed',
      message: `Your report has been marked as ${status}.`,
      link: '/admin',
      relatedId: report._id,
    });
  }

  res.status(200).json({
    success: true,
    message: 'Report status updated successfully',
    data: { report },
  });
};

const getReport = async (req, res) => {
  const report = await Report.findById(req.params.id)
    .populate('reportedBy', 'name email role')
    .populate('reviewedBy', 'name email role');

  if (!report) {
    throw new AppError('Report not found', 404);
  }

  res.status(200).json({
    success: true,
    data: { report },
  });
};

module.exports = {
  createReport,
  getReports,
  updateReportStatus,
  getReport,
};
