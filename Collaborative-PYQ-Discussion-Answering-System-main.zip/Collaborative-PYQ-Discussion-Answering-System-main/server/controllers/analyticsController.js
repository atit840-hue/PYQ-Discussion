const User = require('../models/User');
const Question = require('../models/Question');
const Answer = require('../models/Answer');
const Comment = require('../models/Comment');
const Notification = require('../models/Notification');
const AppError = require('../utils/AppError');

const getMyAnalytics = async (req, res) => {
  const userId = req.user._id;

  const [myQuestions, myAnswers, myComments, unreadNotifications] = await Promise.all([
    Question.countDocuments({ author: userId }),
    Answer.countDocuments({ author: userId }),
    Comment.countDocuments({ user: userId }),
    Notification.countDocuments({ recipient: userId, isRead: false }),
  ]);

  const myQuestionsOverTime = await Question.aggregate([
    { $match: { author: userId } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        count: { $sum: 1 },
      },
    },
    { $sort: { _id: 1 } },
    { $limit: 30 },
  ]);

  res.status(200).json({
    success: true,
    data: {
      myQuestions,
      myAnswers,
      myComments,
      unreadNotifications,
      activity: myQuestionsOverTime,
    },
  });
};

const getAnalytics = async (req, res) => {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const [
    totalUsers,
    totalQuestions,
    totalAnswers,
    subjectDistribution,
    questionsOverTime,
    answersOverTime,
    usersOverTime,
    difficultyDistribution,
    recentActivity,
  ] = await Promise.all([
    User.countDocuments({ isActive: true }),
    Question.countDocuments(),
    Answer.countDocuments(),
    Question.aggregate([
      { $group: { _id: '$subject', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 },
    ]),
    Question.aggregate([
      { $match: { createdAt: { $gte: thirtyDaysAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]),
    Answer.aggregate([
      { $match: { createdAt: { $gte: thirtyDaysAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]),
    User.aggregate([
      { $match: { createdAt: { $gte: thirtyDaysAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]),
    Question.aggregate([{ $group: { _id: '$difficulty', count: { $sum: 1 } } }]),
    Promise.all([
      Question.find().sort({ createdAt: -1 }).limit(5).select('title createdAt').lean(),
      Answer.find().sort({ createdAt: -1 }).limit(5).populate('author', 'name').lean(),
    ]),
  ]);

  res.status(200).json({
    success: true,
    data: {
      totals: { users: totalUsers, questions: totalQuestions, answers: totalAnswers },
      subjectDistribution: subjectDistribution.map((s) => ({ subject: s._id, count: s.count })),
      difficultyDistribution: difficultyDistribution.map((d) => ({
        difficulty: d._id,
        count: d.count,
      })),
      userActivity: { questions: questionsOverTime, answers: answersOverTime, users: usersOverTime },
      recentActivity: { questions: recentActivity[0], answers: recentActivity[1] },
    },
  });
};

const getAnalyticsSummary = async (req, res) => {
  const [totalUsers, totalQuestions, subjectDistribution] = await Promise.all([
    User.countDocuments({ isActive: true }),
    Question.countDocuments(),
    Question.aggregate([
      { $group: { _id: '$subject', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 8 },
    ]),
  ]);

  res.status(200).json({
    success: true,
    data: {
      totals: { users: totalUsers, questions: totalQuestions },
      subjectDistribution: subjectDistribution.map((s) => ({ subject: s._id, count: s.count })),
    },
  });
};

module.exports = { getAnalytics, getMyAnalytics, getAnalyticsSummary };
