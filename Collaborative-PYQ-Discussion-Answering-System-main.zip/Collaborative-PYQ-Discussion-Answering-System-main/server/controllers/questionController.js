const Question = require('../models/Question');
const Answer = require('../models/Answer');
const Subject = require('../models/Subject');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { deleteQuestionCascade, isAuthorOrAdmin } = require('../utils/helpers');
const { DIFFICULTIES } = require('../utils/constants');
const { createNotification } = require('../services/notificationService');
const { addReputation, REPUTATION_RULES } = require('../services/reputationService');
const { resolveSubject } = require('../utils/subjectResolver');

const getQuestions = async (req, res) => {
  const { page, limit, skip } = getPagination(req.query);
  const { subject, semester, year, difficulty, search, sort, topic, subTopic, subjectSlug } =
    req.query;

  const filter = {};

  if (subjectSlug) {
    const sub = await Subject.findOne({ slug: subjectSlug });
    if (sub) filter.subjectRef = sub._id;
  } else if (subject) {
    filter.subject = new RegExp(`^${subject}$`, 'i');
  }

  if (topic) filter.topic = new RegExp(`^${topic}$`, 'i');
  if (subTopic) filter.subTopic = new RegExp(`^${subTopic}$`, 'i');
  if (semester) filter.semester = parseInt(semester, 10);
  if (year) filter.year = parseInt(year, 10);
  if (difficulty) {
    if (!DIFFICULTIES.includes(difficulty)) {
      throw new AppError('Invalid difficulty filter', 400);
    }
    filter.difficulty = difficulty;
  }
  if (search) filter.$text = { $search: search };

  let sortOption = { createdAt: -1 };
  if (sort === 'oldest') sortOption = { createdAt: 1 };
  if (sort === 'most-answered') sortOption = { answerCount: -1 };
  if (sort === 'most-viewed') sortOption = { views: -1 };
  if (sort === 'most-voted') sortOption = { upvotes: -1, createdAt: -1 };

  const [questions, total] = await Promise.all([
    Question.find(filter)
      .populate('author', 'name email role profilePicture reputation')
      .populate('subjectRef', 'name slug fullName')
      .populate('acceptedAnswer')
      .sort(sortOption)
      .skip(skip)
      .limit(limit),
    Question.countDocuments(filter),
  ]);

  res.status(200).json(paginatedResponse(questions, total, page, limit));
};

const getQuestion = async (req, res) => {
  const question = await Question.findById(req.params.id)
    .populate('author', 'name email role profilePicture reputation')
    .populate('subjectRef', 'name slug fullName topics')
    .populate({
      path: 'acceptedAnswer',
      populate: { path: 'author', select: 'name profilePicture reputation' },
    });

  if (!question) {
    throw new AppError('Question not found', 404);
  }

  question.views += 1;
  await question.save({ validateBeforeSave: false });

  res.status(200).json({
    success: true,
    data: { question },
  });
};

const createQuestion = async (req, res) => {
  const { title, description, subject, semester, year, difficulty, images, topic, subTopic } =
    req.body;

  if (!title || !description || !subject || !semester || !year || !difficulty) {
    throw new AppError(
      'Please provide title, description, subject, semester, year, and difficulty',
      400
    );
  }

  const subjectData = await resolveSubject(subject, topic, subTopic);

  const question = await Question.create({
    title,
    description,
    ...subjectData,
    semester,
    year,
    difficulty,
    author: req.user._id,
    images: images || [],
  });

  await question.populate([
    { path: 'author', select: 'name email role profilePicture reputation' },
    { path: 'subjectRef', select: 'name slug fullName' },
  ]);

  res.status(201).json({
    success: true,
    message: 'Question created successfully',
    data: { question },
  });
};

const updateQuestion = async (req, res) => {
  const question = await Question.findById(req.params.id);

  if (!question) {
    throw new AppError('Question not found', 404);
  }

  if (!isAuthorOrAdmin(req.user, question.author)) {
    throw new AppError('Not authorized to update this question', 403);
  }

  const allowedFields = [
    'title',
    'description',
    'semester',
    'year',
    'difficulty',
    'images',
  ];

  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) question[field] = req.body[field];
  });

  if (req.body.subject || req.body.topic !== undefined || req.body.subTopic !== undefined) {
    const subjectData = await resolveSubject(
      req.body.subject || question.subject,
      req.body.topic !== undefined ? req.body.topic : question.topic,
      req.body.subTopic !== undefined ? req.body.subTopic : question.subTopic
    );
    Object.assign(question, subjectData);
  }

  await question.save();
  await question.populate([
    { path: 'author', select: 'name email role profilePicture reputation' },
    { path: 'subjectRef', select: 'name slug fullName' },
  ]);

  res.status(200).json({
    success: true,
    message: 'Question updated successfully',
    data: { question },
  });
};

const deleteQuestion = async (req, res) => {
  const question = await Question.findById(req.params.id);

  if (!question) {
    throw new AppError('Question not found', 404);
  }

  const answerCount = await Answer.countDocuments({ question: question._id });
  await deleteQuestionCascade(question._id);

  res.status(200).json({
    success: true,
    message: 'Question and related content deleted successfully',
    data: { deletedAnswers: answerCount },
  });
};

const getSubjectsList = async (req, res) => {
  const subjects = await Subject.find({ isActive: true }).sort({ name: 1 }).select('name slug');
  res.status(200).json({
    success: true,
    data: { subjects },
  });
};

const acceptAnswer = async (req, res) => {
  const question = await Question.findById(req.params.id);
  if (!question) throw new AppError('Question not found', 404);

  if (question.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    throw new AppError('Only the question owner can accept an answer', 403);
  }

  const answer = await Answer.findById(req.params.answerId);
  if (!answer || answer.question.toString() !== question._id.toString()) {
    throw new AppError('Answer not found for this question', 404);
  }

  const previousAccepted = question.acceptedAnswer?.toString();

  if (previousAccepted === answer._id.toString()) {
    question.acceptedAnswer = undefined;
    await question.save({ validateBeforeSave: false });
    await addReputation(answer.author, REPUTATION_RULES.ACCEPTED_REMOVED);
    return res.status(200).json({
      success: true,
      message: 'Accepted answer removed',
      data: { question },
    });
  }

  if (previousAccepted) {
    const prevAnswer = await Answer.findById(previousAccepted);
    if (prevAnswer) await addReputation(prevAnswer.author, REPUTATION_RULES.ACCEPTED_REMOVED);
  }

  question.acceptedAnswer = answer._id;
  await question.save({ validateBeforeSave: false });
  await addReputation(answer.author, REPUTATION_RULES.ACCEPTED_ANSWER);

  await createNotification({
    recipientId: answer.author,
    senderId: req.user._id,
    type: 'system',
    title: 'Your answer was accepted!',
    message: `Your answer on "${question.title}" was marked as accepted (+${REPUTATION_RULES.ACCEPTED_ANSWER} rep)`,
    link: `/questions/${question._id}`,
    relatedId: answer._id,
  });

  await question.populate([
    { path: 'acceptedAnswer', populate: { path: 'author', select: 'name profilePicture reputation' } },
  ]);

  res.status(200).json({
    success: true,
    message: 'Answer accepted successfully',
    data: { question },
  });
};

const voteQuestion = async (req, res, voteType) => {
  const question = await Question.findById(req.params.id);
  if (!question) throw new AppError('Question not found', 404);

  const result = question.applyVote(req.user._id, voteType);
  await question.save();

  res.status(200).json({
    success: true,
    message: `Vote ${result}`,
    data: {
      questionId: question._id,
      voteScore: question.voteScore,
      upvoteCount: question.upvotes.length,
      downvoteCount: question.downvotes.length,
      userVote:
        result === 'removed' ? null : result === 'upvoted' ? 'upvote' : 'downvote',
    },
  });
};

const upvoteQuestion = (req, res) => voteQuestion(req, res, 'upvote');
const downvoteQuestion = (req, res) => voteQuestion(req, res, 'downvote');

module.exports = {
  getQuestions,
  getQuestion,
  createQuestion,
  updateQuestion,
  deleteQuestion,
  getSubjectsList,
  acceptAnswer,
  upvoteQuestion,
  downvoteQuestion,
};
