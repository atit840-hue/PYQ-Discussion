const Bookmark = require('../models/Bookmark');
const Question = require('../models/Question');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');

const getBookmarks = async (req, res) => {
  const { page, limit, skip } = getPagination(req.query);

  const [bookmarks, total] = await Promise.all([
    Bookmark.find({ user: req.user._id })
      .populate({
        path: 'question',
        populate: { path: 'author', select: 'name email role' },
      })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
    Bookmark.countDocuments({ user: req.user._id }),
  ]);

  res.status(200).json(paginatedResponse(bookmarks, total, page, limit));
};

const addBookmark = async (req, res) => {
  const questionId = req.params.questionId || req.body.questionId;

  if (!questionId) {
    throw new AppError('Question ID is required', 400);
  }

  const question = await Question.findById(questionId);
  if (!question) {
    throw new AppError('Question not found', 404);
  }

  const existing = await Bookmark.findOne({
    user: req.user._id,
    question: questionId,
  });

  if (existing) {
    throw new AppError('Question is already bookmarked', 409);
  }

  const bookmark = await Bookmark.create({
    user: req.user._id,
    question: questionId,
  });

  await bookmark.populate({
    path: 'question',
    populate: { path: 'author', select: 'name email role' },
  });

  res.status(201).json({
    success: true,
    message: 'Question bookmarked successfully',
    data: { bookmark },
  });
};

const removeBookmark = async (req, res) => {
  const questionId = req.params.questionId;

  const bookmark = await Bookmark.findOneAndDelete({
    user: req.user._id,
    question: questionId,
  });

  if (!bookmark) {
    throw new AppError('Bookmark not found', 404);
  }

  res.status(200).json({
    success: true,
    message: 'Bookmark removed successfully',
  });
};

const toggleBookmark = async (req, res) => {
  const questionId = req.params.questionId;

  const question = await Question.findById(questionId);
  if (!question) {
    throw new AppError('Question not found', 404);
  }

  const existing = await Bookmark.findOne({
    user: req.user._id,
    question: questionId,
  });

  if (existing) {
    await existing.deleteOne();
    return res.status(200).json({
      success: true,
      message: 'Bookmark removed',
      data: { bookmarked: false },
    });
  }

  const bookmark = await Bookmark.create({
    user: req.user._id,
    question: questionId,
  });

  await bookmark.populate({
    path: 'question',
    populate: { path: 'author', select: 'name email role' },
  });

  res.status(200).json({
    success: true,
    message: 'Question bookmarked',
    data: { bookmarked: true, bookmark },
  });
};

module.exports = {
  getBookmarks,
  addBookmark,
  removeBookmark,
  toggleBookmark,
};
