const cloudinary = require('../config/cloudinary');
const User = require('../models/User');
const AppError = require('../utils/AppError');

const uploadBuffer = (buffer, folder) =>
  new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      { folder: `pyq-discussion/${folder}`, resource_type: 'image' },
      (error, result) => {
        if (error) reject(error);
        else resolve(result);
      }
    );
    stream.end(buffer);
  });

const isCloudinaryConfigured = () => {
  const { CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET } = process.env;
  return (
    CLOUDINARY_CLOUD_NAME &&
    CLOUDINARY_API_KEY &&
    CLOUDINARY_API_SECRET &&
    !CLOUDINARY_CLOUD_NAME.startsWith('your_') &&
    !CLOUDINARY_API_KEY.startsWith('your_')
  );
};

const uploadProfilePicture = async (req, res) => {
  if (!req.file) {
    throw new AppError('Please upload an image file', 400);
  }

  if (!isCloudinaryConfigured()) {
    throw new AppError(
      'Image upload is not configured. Set CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, and CLOUDINARY_API_SECRET in server/.env.',
      503
    );
  }

  let result;
  try {
    result = await uploadBuffer(req.file.buffer, 'profiles');
  } catch (err) {
    throw new AppError(
      `Cloudinary upload failed: ${err.message || 'check your Cloudinary credentials'}`,
      503
    );
  }

  const user = await User.findById(req.user._id);
  if (user.profilePicture?.publicId) {
    await cloudinary.uploader.destroy(user.profilePicture.publicId).catch(() => {});
  }

  user.profilePicture = { url: result.secure_url, publicId: result.public_id };
  await user.save();

  const userObj = user.toJSON();

  res.status(200).json({
    success: true,
    message: 'Profile picture updated',
    data: { profilePicture: user.profilePicture, user: userObj },
  });
};

const uploadQuestionImage = async (req, res) => {
  if (!req.file) {
    throw new AppError('Please upload an image file', 400);
  }

  if (!isCloudinaryConfigured()) {
    throw new AppError(
      'Image upload is not configured. Set CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, and CLOUDINARY_API_SECRET in server/.env.',
      503
    );
  }

  let result;
  try {
    result = await uploadBuffer(req.file.buffer, 'questions');
  } catch (err) {
    throw new AppError(
      `Cloudinary upload failed: ${err.message || 'check your Cloudinary credentials'}`,
      503
    );
  }

  res.status(200).json({
    success: true,
    message: 'Image uploaded successfully',
    data: {
      image: { url: result.secure_url, publicId: result.public_id },
    },
  });
};

module.exports = { uploadProfilePicture, uploadQuestionImage };
