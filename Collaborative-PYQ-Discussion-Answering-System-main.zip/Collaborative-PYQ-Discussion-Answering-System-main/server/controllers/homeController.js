const Question = require('../models/Question');
const Answer = require('../models/Answer');
const User = require('../models/User');
const Resource = require('../models/Resource');
const Subject = require('../models/Subject');
const Pyq = require('../models/Pyq');

const getHomeFeed = async (req, res) => {
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);

  const [
    trendingDiscussions,
    topContributors,
    recentNotes,
    popularSubjects,
    weeklyLeaders,
    recentPyqs,
  ] = await Promise.all([
    Question.find()
      .sort({ views: -1, answerCount: -1 })
      .limit(6)
      .select('title subject answerCount views upvotes difficulty createdAt')
      .populate('author', 'name profilePicture reputation')
      .lean(),
    User.find({ isActive: true })
      .sort({ reputation: -1 })
      .limit(5)
      .select('name reputation profilePicture')
      .lean(),
    Resource.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select('title subject branch semester fileType downloads likes createdAt')
      .populate('uploadedBy', 'name profilePicture')
      .lean(),
    Subject.find({ isActive: true })
      .sort({ name: 1 })
      .limit(8)
      .select('name slug fullName semester description')
      .lean(),
    User.find({ isActive: true })
      .sort({ reputation: -1 })
      .limit(5)
      .select('name reputation profilePicture')
      .lean(),
    Pyq.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select('title exam subject year marks difficulty views')
      .populate('author', 'name profilePicture')
      .lean(),
  ]);

  res.status(200).json({
    success: true,
    data: {
      trendingDiscussions,
      topContributors,
      recentNotes,
      popularSubjects,
      weeklyLeaders,
      recentPyqs,
      studyStreak: { current: 0, longest: 0 },
    },
  });
};

module.exports = { getHomeFeed };
