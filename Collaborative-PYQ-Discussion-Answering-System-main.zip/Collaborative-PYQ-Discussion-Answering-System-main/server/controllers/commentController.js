const Comment = require('../models/Comment');
const Answer = require('../models/Answer');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { isAuthorOrAdmin } = require('../utils/helpers');
const { createNotification } = require('../services/notificationService');
const { addReputation, REPUTATION_RULES } = require('../services/reputationService');

const getCommentsByAnswer = async (req, res) => {
  const answer = await Answer.findById(req.params.answerId);
  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  const { page, limit, skip } = getPagination(req.query);

  const [comments, total] = await Promise.all([
    Comment.find({ answer: req.params.answerId })
      .populate('user', 'name email role')
      .sort({ createdAt: 1 })
      .skip(skip)
      .limit(limit),
    Comment.countDocuments({ answer: req.params.answerId }),
  ]);

  res.status(200).json(paginatedResponse(comments, total, page, limit));
};

const createComment = async (req, res) => {
  const { comment } = req.body;

  if (!comment || !comment.trim()) {
    throw new AppError('Comment is required', 400);
  }

  const answer = await Answer.findById(req.params.answerId);
  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  const newComment = await Comment.create({
    answer: answer._id,
    user: req.user._id,
    comment,
  });

  await newComment.populate('user', 'name email role profilePicture reputation');

  if (answer.author.toString() !== req.user._id.toString()) {
    await addReputation(req.user._id, REPUTATION_RULES.USEFUL_COMMENT);
  }

  await createNotification({
    recipientId: answer.author,
    senderId: req.user._id,
    type: 'new_comment',
    title: 'New comment on your answer',
    message: `${req.user.name} commented on your answer`,
    link: `/questions/${answer.question}`,
    relatedId: newComment._id,
  });

  res.status(201).json({
    success: true,
    message: 'Comment added successfully',
    data: { comment: newComment },
  });
};

const deleteComment = async (req, res) => {
  const comment = await Comment.findById(req.params.id);

  if (!comment) {
    throw new AppError('Comment not found', 404);
  }

  if (!isAuthorOrAdmin(req.user, comment.user)) {
    throw new AppError('Not authorized to delete this comment', 403);
  }

  await comment.deleteOne();

  res.status(200).json({
    success: true,
    message: 'Comment deleted successfully',
  });
};

module.exports = {
  getCommentsByAnswer,
  createComment,
  deleteComment,
};
