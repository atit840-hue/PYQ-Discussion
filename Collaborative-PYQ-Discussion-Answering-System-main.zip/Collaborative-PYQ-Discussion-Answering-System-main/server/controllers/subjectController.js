const Subject = require('../models/Subject');
const Question = require('../models/Question');
const Pyq = require('../models/Pyq');
const AppError = require('../utils/AppError');

const getSubjects = async (req, res) => {
  const subjects = await Subject.find({ isActive: true }).sort({ name: 1 }).lean();

  const [questionStats, pyqStats] = await Promise.all([
    Question.aggregate([{ $group: { _id: '$subjectRef', count: { $sum: 1 } } }]),
    Pyq.aggregate([{ $group: { _id: '$subjectRef', count: { $sum: 1 } } }]),
  ]);

  const questionCountMap = questionStats.reduce((acc, s) => {
    acc[s._id?.toString()] = s.count;
    return acc;
  }, {});

  const pyqCountMap = pyqStats.reduce((acc, s) => {
    acc[s._id?.toString()] = s.count;
    return acc;
  }, {});

  const enriched = subjects.map((s) => ({
    ...s,
    questionCount: questionCountMap[s._id.toString()] || 0,
    pyqCount: pyqCountMap[s._id.toString()] || 0,
  }));

  res.status(200).json({
    success: true,
    data: { subjects: enriched },
  });
};

const getSubjectBySlug = async (req, res) => {
  const subject = await Subject.findOne({ slug: req.params.slug, isActive: true }).lean();

  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  const [questionCount, pyqCount, recentQuestions, recentPyqs, topicStats] = await Promise.all([
    Question.countDocuments({ subjectRef: subject._id }),
    Pyq.countDocuments({ subjectRef: subject._id }),
    Question.find({ subjectRef: subject._id })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('title topic subTopic year difficulty answerCount upvotes')
      .populate('author', 'name profilePicture reputation')
      .lean(),
    Pyq.find({ subjectRef: subject._id })
      .sort({ createdAt: -1 })
      .limit(10)
      .select('title exam topic subTopic year marks difficulty views')
      .populate('author', 'name profilePicture reputation')
      .lean(),
    Question.aggregate([
      { $match: { subjectRef: subject._id } },
      { $group: { _id: '$topic', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]),
  ]);

  res.status(200).json({
    success: true,
    data: {
      subject: {
        ...subject,
        questionCount,
        pyqCount,
        recentQuestions,
        recentPyqs,
        topicStats: topicStats.map((t) => ({ topic: t._id || 'General', count: t.count })),
      },
    },
  });
};

const getSubjectTopics = async (req, res) => {
  const subject = await Subject.findOne({ slug: req.params.slug }).select('topics name slug');

  if (!subject) {
    throw new AppError('Subject not found', 404);
  }

  res.status(200).json({
    success: true,
    data: { topics: subject.topics, subjectName: subject.name, slug: subject.slug },
  });
};

module.exports = { getSubjects, getSubjectBySlug, getSubjectTopics };
