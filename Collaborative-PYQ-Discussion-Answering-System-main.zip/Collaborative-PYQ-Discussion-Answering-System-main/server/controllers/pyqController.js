const Pyq = require('../models/Pyq');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { isAuthorOrAdmin } = require('../utils/helpers');
const { DIFFICULTIES, EXAMS } = require('../utils/constants');
const { resolveSubject } = require('../utils/subjectResolver');
const Subject = require('../models/Subject');

const buildImageList = (questionImage, images = []) => {
  const list = [...images];
  if (questionImage?.url) {
    const exists = list.some((img) => img.url === questionImage.url);
    if (!exists) list.unshift(questionImage);
  }
  return list.slice(0, 3);
};

const getPyqs = async (req, res) => {
  const { page, limit, skip } = getPagination(req.query);
  const {
    exam,
    year,
    subject,
    subjectSlug,
    topic,
    subTopic,
    difficulty,
    search,
    sort,
  } = req.query;

  const filter = {};

  if (subjectSlug) {
    const sub = await Subject.findOne({ slug: subjectSlug });
    if (sub) filter.subjectRef = sub._id;
  } else if (subject) {
    filter.subject = new RegExp(`^${subject}$`, 'i');
  }

  if (exam) {
    if (!EXAMS.includes(exam)) {
      throw new AppError('Invalid exam filter', 400);
    }
    filter.exam = exam;
  }
  if (year) filter.year = parseInt(year, 10);
  if (topic) filter.topic = new RegExp(`^${topic}$`, 'i');
  if (subTopic) filter.subTopic = new RegExp(`^${subTopic}$`, 'i');
  if (difficulty) {
    if (!DIFFICULTIES.includes(difficulty)) {
      throw new AppError('Invalid difficulty filter', 400);
    }
    filter.difficulty = difficulty;
  }
  if (search) filter.$text = { $search: search };

  let sortOption = { createdAt: -1 };
  if (sort === 'oldest') sortOption = { createdAt: 1 };
  if (sort === 'most-viewed') sortOption = { views: -1, createdAt: -1 };
  if (sort === 'marks-high') sortOption = { marks: -1, createdAt: -1 };
  if (sort === 'marks-low') sortOption = { marks: 1, createdAt: -1 };

  const [pyqs, total] = await Promise.all([
    Pyq.find(filter)
      .populate('author', 'name profilePicture reputation')
      .populate('subjectRef', 'name slug fullName')
      .sort(sortOption)
      .skip(skip)
      .limit(limit),
    Pyq.countDocuments(filter),
  ]);

  res.status(200).json(paginatedResponse(pyqs, total, page, limit));
};

const getPyq = async (req, res) => {
  const pyq = await Pyq.findById(req.params.id)
    .populate('author', 'name email role profilePicture reputation')
    .populate('subjectRef', 'name slug fullName topics');

  if (!pyq) {
    throw new AppError('PYQ not found', 404);
  }

  pyq.views += 1;
  await pyq.save({ validateBeforeSave: false });

  res.status(200).json({
    success: true,
    data: { pyq },
  });
};

const createPyq = async (req, res) => {
  const {
    title,
    questionText,
    exam,
    year,
    subject,
    topic,
    subTopic,
    marks,
    difficulty,
    officialAnswer,
    solution,
    questionImage,
    images,
  } = req.body;

  if (!title || !questionText || !exam || !year || !subject || !marks || !difficulty) {
    throw new AppError(
      'Please provide title, questionText, exam, year, subject, marks, and difficulty',
      400
    );
  }

  if (!EXAMS.includes(exam)) {
    throw new AppError('Invalid exam', 400);
  }

  const subjectData = await resolveSubject(subject, topic, subTopic);
  const imageList = buildImageList(questionImage, images || []);

  const pyq = await Pyq.create({
    title,
    questionText,
    exam,
    year,
    ...subjectData,
    marks,
    difficulty,
    officialAnswer,
    solution,
    questionImage: imageList[0] || questionImage,
    images: imageList,
    author: req.user._id,
  });

  await pyq.populate([
    { path: 'author', select: 'name email role profilePicture reputation' },
    { path: 'subjectRef', select: 'name slug fullName' },
  ]);

  res.status(201).json({
    success: true,
    message: 'PYQ created successfully',
    data: { pyq },
  });
};

const updatePyq = async (req, res) => {
  const pyq = await Pyq.findById(req.params.id);

  if (!pyq) {
    throw new AppError('PYQ not found', 404);
  }

  if (!isAuthorOrAdmin(req.user, pyq.author)) {
    throw new AppError('Not authorized to update this PYQ', 403);
  }

  const allowedFields = [
    'title',
    'questionText',
    'exam',
    'year',
    'marks',
    'difficulty',
    'officialAnswer',
    'solution',
    'questionImage',
    'images',
  ];

  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) pyq[field] = req.body[field];
  });

  if (req.body.exam && !EXAMS.includes(req.body.exam)) {
    throw new AppError('Invalid exam', 400);
  }

  if (
    req.body.subject ||
    req.body.topic !== undefined ||
    req.body.subTopic !== undefined
  ) {
    const subjectData = await resolveSubject(
      req.body.subject || pyq.subject,
      req.body.topic !== undefined ? req.body.topic : pyq.topic,
      req.body.subTopic !== undefined ? req.body.subTopic : pyq.subTopic
    );
    Object.assign(pyq, subjectData);
  }

  if (req.body.questionImage !== undefined || req.body.images !== undefined) {
    const imageList = buildImageList(
      req.body.questionImage !== undefined ? req.body.questionImage : pyq.questionImage,
      req.body.images !== undefined ? req.body.images : pyq.images
    );
    pyq.questionImage = imageList[0];
    pyq.images = imageList;
  }

  await pyq.save();
  await pyq.populate([
    { path: 'author', select: 'name email role profilePicture reputation' },
    { path: 'subjectRef', select: 'name slug fullName' },
  ]);

  res.status(200).json({
    success: true,
    message: 'PYQ updated successfully',
    data: { pyq },
  });
};

const deletePyq = async (req, res) => {
  const pyq = await Pyq.findById(req.params.id);

  if (!pyq) {
    throw new AppError('PYQ not found', 404);
  }

  await pyq.deleteOne();

  res.status(200).json({
    success: true,
    message: 'PYQ deleted successfully',
  });
};

const getExamsList = async (req, res) => {
  res.status(200).json({
    success: true,
    data: { exams: EXAMS },
  });
};

module.exports = {
  getPyqs,
  getPyq,
  createPyq,
  updatePyq,
  deletePyq,
  getExamsList,
};
