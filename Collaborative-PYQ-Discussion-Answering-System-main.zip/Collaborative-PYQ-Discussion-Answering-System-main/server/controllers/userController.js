const User = require('../models/User');
const Question = require('../models/Question');
const Answer = require('../models/Answer');
const Resource = require('../models/Resource');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { getBadge } = require('../utils/badgeUtils');

const periodStart = (period) => {
  const d = new Date();
  if (period === 'week') d.setDate(d.getDate() - 7);
  else if (period === 'month') d.setDate(d.getDate() - 30);
  else return null;
  return d;
};

const getLeaderboard = async (req, res) => {
  const { page, limit, skip } = getPagination(req.query);
  const period = req.query.period || 'all';
  const sortBy = req.query.sortBy || 'reputation';
  const since = periodStart(period);

  if (sortBy === 'reputation' && !since) {
    const [users, total] = await Promise.all([
      User.find({ isActive: true })
        .select('name email reputation profilePicture role createdAt')
        .sort({ reputation: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      User.countDocuments({ isActive: true }),
    ]);

    const ranked = users.map((u, i) => ({
      ...u,
      rank: skip + i + 1,
      badge: getBadge(u.reputation),
      score: u.reputation,
    }));

    return res.status(200).json(paginatedResponse(ranked, total, page, limit));
  }

  let aggregation;
  if (sortBy === 'answers') {
    const match = since ? { createdAt: { $gte: since } } : {};
    aggregation = [
      { $match: match },
      { $group: { _id: '$author', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ];
  } else if (sortBy === 'notes') {
    const match = since ? { createdAt: { $gte: since } } : {};
    aggregation = [
      { $match: match },
      { $group: { _id: '$uploadedBy', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ];
  } else if (sortBy === 'accepted') {
    const qMatch = since ? { acceptedAnswer: { $exists: true, $ne: null }, updatedAt: { $gte: since } } : { acceptedAnswer: { $exists: true, $ne: null } };
    const questions = await Question.find(qMatch).select('acceptedAnswer').lean();
    const answerIds = questions.map((q) => q.acceptedAnswer).filter(Boolean);
    aggregation = [
      { $match: { _id: { $in: answerIds } } },
      { $group: { _id: '$author', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ];
  } else {
    const match = since ? { createdAt: { $gte: since } } : {};
    aggregation = [
      { $match: match },
      { $group: { _id: '$author', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ];
  }

  const model = sortBy === 'notes' ? Resource : sortBy === 'accepted' ? Answer : Answer;
  const aggResult = await model.aggregate(aggregation);
  const total = aggResult.length;
  const slice = aggResult.slice(skip, skip + limit);
  const userIds = slice.map((r) => r._id);

  const users = await User.find({ _id: { $in: userIds }, isActive: true })
    .select('name email reputation profilePicture role createdAt')
    .lean();

  const userMap = users.reduce((acc, u) => {
    acc[u._id.toString()] = u;
    return acc;
  }, {});

  const ranked = slice
    .map((row, i) => {
      const u = userMap[row._id?.toString()];
      if (!u) return null;
      return {
        ...u,
        rank: skip + i + 1,
        badge: getBadge(u.reputation),
        score: row.count,
      };
    })
    .filter(Boolean);

  res.status(200).json(paginatedResponse(ranked, total, page, limit));
};

const getMyProfile = async (req, res) => {
  const userId = req.user._id;

  const [
    user,
    questionsAsked,
    answersPosted,
    notesUploaded,
    acceptedAnswerIds,
    recentQuestions,
    recentAnswers,
    recentResources,
  ] = await Promise.all([
    User.findById(userId).select('-password'),
    Question.countDocuments({ author: userId }),
    Answer.countDocuments({ author: userId }),
    Resource.countDocuments({ uploadedBy: userId }),
    Question.find({ acceptedAnswer: { $ne: null } }).distinct('acceptedAnswer'),
    Question.find({ author: userId }).sort({ createdAt: -1 }).limit(5).select('title createdAt').lean(),
    Answer.find({ author: userId }).sort({ createdAt: -1 }).limit(5).select('answerText question createdAt').lean(),
    Resource.find({ uploadedBy: userId }).sort({ createdAt: -1 }).limit(5).select('title createdAt').lean(),
  ]);

  const acceptedAnswers = await Answer.countDocuments({
    author: userId,
    _id: { $in: acceptedAnswerIds },
  });

  const me = await User.findById(userId);
  const rank =
    (await User.countDocuments({ isActive: true, reputation: { $gt: me.reputation } })) + 1;

  const activity = [
    ...recentQuestions.map((q) => ({
      type: 'question',
      text: q.title,
      date: q.createdAt,
      link: `/questions/${q._id}`,
    })),
    ...recentAnswers.map((a) => ({
      type: 'answer',
      text: a.answerText?.slice(0, 80),
      date: a.createdAt,
      link: `/questions/${a.question}`,
    })),
    ...recentResources.map((r) => ({
      type: 'resource',
      text: r.title,
      date: r.createdAt,
      link: null,
    })),
  ]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 10);

  res.status(200).json({
    success: true,
    data: {
      user: user.toJSON(),
      stats: {
        questionsAsked,
        answersPosted,
        notesUploaded,
        reputation: me.reputation,
        acceptedAnswers,
        rank,
      },
      streak: { current: 0, longest: 0 },
      activity,
    },
  });
};

module.exports = { getLeaderboard, getMyProfile };
