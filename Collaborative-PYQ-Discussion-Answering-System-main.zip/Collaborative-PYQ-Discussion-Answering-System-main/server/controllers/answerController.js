const Answer = require('../models/Answer');
const Question = require('../models/Question');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { deleteAnswerCascade, isAuthorOrAdmin } = require('../utils/helpers');
const { createNotification } = require('../services/notificationService');
const { addReputation, REPUTATION_RULES } = require('../services/reputationService');

const getAnswersByQuestion = async (req, res) => {
  const question = await Question.findById(req.params.questionId);
  if (!question) {
    throw new AppError('Question not found', 404);
  }

  const { page, limit, skip } = getPagination(req.query);

  const answers = await Answer.find({ question: req.params.questionId })
    .populate('author', 'name email role profilePicture reputation')
    .populate('verifiedBy', 'name email role profilePicture');

  answers.sort((a, b) => {
    const aAccepted = question.acceptedAnswer?.toString() === a._id.toString();
    const bAccepted = question.acceptedAnswer?.toString() === b._id.toString();
    if (aAccepted && !bAccepted) return -1;
    if (!aAccepted && bAccepted) return 1;
    if (a.verified !== b.verified) return b.verified - a.verified;
    const aScore = a.upvotes.length - a.downvotes.length;
    const bScore = b.upvotes.length - b.downvotes.length;
    if (aScore !== bScore) return bScore - aScore;
    return new Date(b.createdAt) - new Date(a.createdAt);
  });

  const total = answers.length;
  const paginated = answers.slice(skip, skip + limit);

  res.status(200).json(paginatedResponse(paginated, total, page, limit));
};

const createAnswer = async (req, res) => {
  const { answerText } = req.body;

  if (!answerText) {
    throw new AppError('Answer text is required', 400);
  }

  const question = await Question.findById(req.params.questionId);
  if (!question) {
    throw new AppError('Question not found', 404);
  }

  const answer = await Answer.create({
    question: question._id,
    author: req.user._id,
    answerText,
  });

  question.answerCount += 1;
  await question.save({ validateBeforeSave: false });

  await answer.populate('author', 'name email role profilePicture');

  await createNotification({
    recipientId: question.author,
    senderId: req.user._id,
    type: 'new_answer',
    title: 'New answer on your question',
    message: `${req.user.name} answered "${question.title}"`,
    link: `/questions/${question._id}`,
    relatedId: answer._id,
  });

  res.status(201).json({
    success: true,
    message: 'Answer posted successfully',
    data: { answer },
  });
};

const updateAnswer = async (req, res) => {
  const answer = await Answer.findById(req.params.id);

  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  if (!isAuthorOrAdmin(req.user, answer.author)) {
    throw new AppError('Not authorized to update this answer', 403);
  }

  if (req.body.answerText !== undefined) {
    if (!req.body.answerText.trim()) {
      throw new AppError('Answer text cannot be empty', 400);
    }
    answer.answerText = req.body.answerText;

    if (answer.verified && req.user.role !== 'admin' && req.user.role !== 'moderator') {
      answer.verified = false;
      answer.verifiedBy = undefined;
      answer.verifiedAt = undefined;
    }
  }

  await answer.save();
  await answer.populate('author', 'name email role');

  res.status(200).json({
    success: true,
    message: 'Answer updated successfully',
    data: { answer },
  });
};

const deleteAnswer = async (req, res) => {
  const answer = await Answer.findById(req.params.id);

  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  const question = await Question.findById(answer.question);
  await deleteAnswerCascade(answer._id);

  if (question) {
    question.answerCount = Math.max(0, question.answerCount - 1);
    await question.save({ validateBeforeSave: false });
  }

  res.status(200).json({
    success: true,
    message: 'Answer and related comments deleted successfully',
  });
};

const verifyAnswer = async (req, res) => {
  const answer = await Answer.findById(req.params.id);

  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  const { verified } = req.body;
  const shouldVerify = verified !== undefined ? Boolean(verified) : true;

  const wasVerified = answer.verified;
  answer.verified = shouldVerify;

  if (shouldVerify) {
    answer.verifiedBy = req.user._id;
    answer.verifiedAt = new Date();
    if (!wasVerified) await addReputation(answer.author, REPUTATION_RULES.VERIFIED_ANSWER);
  } else {
    answer.verifiedBy = undefined;
    answer.verifiedAt = undefined;
    if (wasVerified) await addReputation(answer.author, REPUTATION_RULES.VERIFY_REMOVED);
  }

  await answer.save();
  await answer.populate([
    { path: 'author', select: 'name email role profilePicture' },
    { path: 'verifiedBy', select: 'name email role profilePicture' },
  ]);

  if (shouldVerify) {
    await createNotification({
      recipientId: answer.author,
      senderId: req.user._id,
      type: 'answer_verified',
      title: 'Your answer was verified',
      message: `A moderator verified your answer on a PYQ question.`,
      link: `/questions/${answer.question}`,
      relatedId: answer._id,
    });
  }

  res.status(200).json({
    success: true,
    message: shouldVerify ? 'Answer verified successfully' : 'Answer verification removed',
    data: { answer },
  });
};

const voteAnswer = async (req, res, voteType) => {
  const answer = await Answer.findById(req.params.id);

  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  if (!['upvote', 'downvote'].includes(voteType)) {
    throw new AppError('Vote type must be upvote or downvote', 400);
  }

  const hadUpvote = answer.upvotes.some((id) => id.toString() === req.user._id.toString());
  const result = answer.applyVote(req.user._id, voteType);
  await answer.save();

  if (result === 'upvoted') {
    await addReputation(answer.author, REPUTATION_RULES.ANSWER_UPVOTE);
    await createNotification({
      recipientId: answer.author,
      senderId: req.user._id,
      type: 'upvote',
      title: 'Your answer received an upvote',
      message: `${req.user.name} upvoted your answer (+${REPUTATION_RULES.ANSWER_UPVOTE} rep)`,
      link: `/questions/${answer.question}`,
      relatedId: answer._id,
    });
  } else if (result === 'removed' && voteType === 'upvote' && hadUpvote) {
    await addReputation(answer.author, REPUTATION_RULES.ANSWER_UPVOTE_REMOVED);
  }

  res.status(200).json({
    success: true,
    message: `Vote ${result}`,
    data: {
      answerId: answer._id,
      voteScore: answer.voteScore,
      upvoteCount: answer.upvotes.length,
      downvoteCount: answer.downvotes.length,
      userVote:
        result === 'removed'
          ? null
          : result === 'upvoted'
            ? 'upvote'
            : 'downvote',
    },
  });
};

const upvoteAnswer = (req, res) => voteAnswer(req, res, 'upvote');
const downvoteAnswer = (req, res) => voteAnswer(req, res, 'downvote');

const removeVote = async (req, res) => {
  const answer = await Answer.findById(req.params.id);

  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  const removed = answer.removeVote(req.user._id);
  if (!removed) {
    throw new AppError('You have not voted on this answer', 400);
  }

  await answer.save();

  res.status(200).json({
    success: true,
    message: 'Vote removed successfully',
    data: {
      answerId: answer._id,
      voteScore: answer.voteScore,
      upvoteCount: answer.upvotes.length,
      downvoteCount: answer.downvotes.length,
    },
  });
};

const getAnswer = async (req, res) => {
  const answer = await Answer.findById(req.params.id)
    .populate('author', 'name email role')
    .populate('verifiedBy', 'name email role')
    .populate('question', 'title subject semester year');

  if (!answer) {
    throw new AppError('Answer not found', 404);
  }

  res.status(200).json({
    success: true,
    data: { answer },
  });
};

module.exports = {
  getAnswersByQuestion,
  createAnswer,
  updateAnswer,
  deleteAnswer,
  verifyAnswer,
  upvoteAnswer,
  downvoteAnswer,
  removeVote,
  getAnswer,
};
